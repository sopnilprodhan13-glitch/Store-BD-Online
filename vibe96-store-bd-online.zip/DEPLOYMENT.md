# Production Deployment Guide (`DEPLOYMENT.md`)

**Store BD Online** includes ready-to-use deployment configurations for two production hosting environments:
1. **Google Cloud Run** (`cloudbuild.yaml` + `Dockerfile`)
2. **Docker on a VPS** (`Dockerfile` + `docker-compose.yml`)

---

## Method 1: Deploy to Google Cloud Run

### Prerequisites
- Google Cloud SDK (`gcloud`) installed and authenticated.
- Project set to your Google Cloud / Firebase project:
  ```bash
  gcloud config set project gen-lang-client-0128050017
  ```

### Step 1: Build & Deploy via Cloud Build (`cloudbuild.yaml`)
```bash
gcloud builds submit --config cloudbuild.yaml .
```

### Step 2: Set Production Environment Variables on Cloud Run
```bash
gcloud run services update store-bd-online \
  --region asia-south1 \
  --set-env-vars="NODE_ENV=production,ADMIN_OWNER_EMAIL=sopnilprodhan13@gmail.com,FIREBASE_PROJECT_ID=gen-lang-client-0128050017,OTP_HASH_SECRET=YOUR_64_CHAR_HEX_SECRET,RESEND_API_KEY=YOUR_RESEND_API_KEY,MAIL_FROM=Store BD Online <no-reply@yourdomain.com>"
```

### Step 3: Verify Health Endpoint
```bash
curl -s https://YOUR-CLOUD-RUN-URL/api/health
```

---

## Method 2: Deploy with Docker on a Linux VPS (Ubuntu / Debian)

### Prerequisites
- Docker Engine (`24+`) and Docker Compose plugin (`docker compose`) installed on your VPS.

### Step 1: Configure `.env`
Copy `.env.example` to `.env` on your VPS and set your production variables:
```bash
cp .env.example .env
nano .env
```

### Step 2: Build and Start the Container
```bash
docker compose up -d --build
```

The container builds the production bundle (`npm run build`), starts the Express + static bundle server on port `3000`, and configures an automatic container healthcheck against `http://127.0.0.1:3000/api/health`.

### Step 3: Check Container Logs & Health
```bash
docker compose ps
docker compose logs -f store-bd-online
curl -s http://127.0.0.1:3000/api/health
```

---

## Deploying Firebase Rules & Indexes

Whenever `firestore.rules`, `storage.rules`, or `firestore.indexes.json` are updated, deploy them with:

```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
```
