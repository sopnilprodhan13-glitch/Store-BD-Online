import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword,
  updateProfile,
  signOut
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  initializeFirestore,
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  writeBatch,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js';

import {
  DEFAULT_SETTINGS,
  DEFAULT_CATEGORIES,
  DEFAULT_BANNERS,
  DEFAULT_PRODUCTS,
  DEFAULT_COUPONS,
  BD_DIVISIONS
} from "./seedData.js";
import {
  formatBrandHtml,
  getWhatsAppUrl,
  applySettingsToUI,
  updateCountersUI,
  renderHeroSlider,
  updateActiveHeroSlide,
  renderPromoBanner,
  renderCategoriesUI,
  createProductCardHTML,
  renderAllProductGrids,
  renderFeaturedCollectionTabGrid,
  renderShopGrid,
  renderWishlistGrid,
  openProductDetail,
  renderProductDetailView,
  toggleWishlist,
  openReviewModal
} from "./storefrontUI.js";
import {
  saveCart,
  addToCart,
  updateCartQty,
  calculateCartTotals,
  renderCartDrawer,
  applyCouponCode,
  renderCheckoutView,
  handleCheckoutSubmit,
  renderOrderConfirmation,
  ORDER_STATUS_STEPS,
  handleOrderTrackingSubmit
} from "./cartCheckout.js";
import {
  clearOtpTimer,
  openForgotPasswordOtpFlow,
  activateServerCustomerSession,
  openAuthModal,
  ensureUserProfileDoc,
  renderAccountView
} from "./authOtp.js";
import {
  validateAdminImageFile,
  uploadImageAsset,
  renderAdminView,
  renderAdminOverview,
  renderAdminProducts,
  openProductFormModal,
  renderAdminCategories,
  renderAdminOrders,
  renderAdminCustomers
} from "./adminDashboard.js";
import {
  renderAdminBanners,
  renderAdminCoupons,
  renderAdminReviews,
  renderAdminSettings,
  renderAdminReports,
  downloadCsv
} from "./adminSettingsReports.js";

// =========================================================================
// 1. RUNTIME FIREBASE CONFIGURATION (Fetched dynamically from /api/config/firebase)
// =========================================================================
let firebaseConfig = {
  apiKey: "",
  authDomain: "gen-lang-client-0128050017.firebaseapp.com",
  projectId: "gen-lang-client-0128050017",
  storageBucket: "gen-lang-client-0128050017.firebasestorage.app",
  firestoreDatabaseId: "ai-studio-2a331384-50d8-42fd-9a43-f88f719935a8"
};

try {
  const configResp = await fetch("/api/config/firebase", { cache: "no-store" });
  if (configResp.ok) {
    firebaseConfig = await configResp.json();
  }
} catch (err) {
  console.warn(
    "[firebase-config] /api/config/firebase not reached. Running with fallback config.",
    err
  );
}

const ADMIN_EMAIL = "sopnilprodhan13@gmail.com";

let app, db, auth, storage;
try {
  app = initializeApp(firebaseConfig);
  try {
    db = initializeFirestore(
      app,
      { experimentalAutoDetectLongPolling: true },
      firebaseConfig.firestoreDatabaseId
    );
  } catch (_) {
    db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
  }
  auth = getAuth(app);
  storage = getStorage(app);
} catch (fbInitErr) {
  console.warn("[firebase-config] Firebase initializeApp note:", fbInitErr);
}

// =========================================================================
// 2. FIRESTORE CONNECTION TEST & STRUCTURED ERROR HANDLER
// =========================================================================
const OperationType = {
  CREATE: 'create',
  UPDATE: 'update',
  DELETE: 'delete',
  LIST: 'list',
  GET: 'get',
  WRITE: 'write'
};

function handleFirestoreError(error, operationType, path) {
  const msg = error instanceof Error ? error.message : String(error);
  if (
    msg.includes('the client is offline') ||
    msg.includes('client is offline') ||
    msg.includes('Failed to get document') ||
    msg.includes('unavailable')
  ) {
    return;
  }
  const errInfo = {
    error: msg,
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || false,
      isAnonymous: auth.currentUser?.isAnonymous || false,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: (auth.currentUser?.providerData || []).map(p => ({
        providerId: p.providerId,
        email: p.email
      }))
    },
    operationType,
    path
  };
  if (msg.includes('Quota exceeded')) {
    showToast('Daily Firestore quota reached. Operating with cached store state.');
    return;
  }
  if (msg.includes('Missing or insufficient permissions')) {
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    throw new Error(JSON.stringify(errInfo));
  }
}

async function testConnection() {
  if (!db) return;
  try {
    await getDoc(doc(db, 'settings', 'store'));
  } catch (_) {
    // Graceful fallback to local seed data while Firestore transport initializes
  }
}
testConnection();


// =========================================================================
// 4. APPLICATION STATE
// =========================================================================
const state = {
  currentView: 'home',
  settings: { ...DEFAULT_SETTINGS },
  categories: [...DEFAULT_CATEGORIES],
  banners: [...DEFAULT_BANNERS],
  products: [...DEFAULT_PRODUCTS],
  coupons: [...DEFAULT_COUPONS],
  orders: [],
  reviews: [],
  notifications: [],
  customers: [],
  currentUser: null,
  userProfile: null,
  isAdmin: false,
  heroIndex: 0,
  heroTimer: null,
  selectedCategory: 'all',
  selectedCollectionTab: 'bestseller',
  searchQuery: '',
  sortBy: 'newest',
  activeProductId: null,
  cart: JSON.parse(localStorage.getItem('sbd_cart') || '[]'),
  appliedCoupon: null,
  wishlist: JSON.parse(localStorage.getItem('sbd_wishlist') || '[]'),
  recentlyViewed: JSON.parse(localStorage.getItem('sbd_recent') || '[]'),
  adminTab: 'overview',
  isSubmittingOrder: false,
  transparentLogoDataUrl: null
};

// =========================================================================
// 5. UTILITY & TRANSPARENT LOGO GENERATOR
// =========================================================================
function formatPrice(amount) {
  const num = Math.round(Number(amount) || 0);
  return `${state.settings.currency || '৳'}${num.toLocaleString('en-IN')}`;
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function showToast(message) {
  const stack = document.getElementById('toastStack');
  if (!stack) return;
  const el = document.createElement('div');
  el.className = 'toast-item';
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 220);
  }, 3200);
}

function refreshIcons() {
  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }
}

/**
 * Removes the solid black background from the official Store BD Online logo
 * using an HTML5 Canvas alpha-key filter while preserving red, yellow, and white elements.
 */
function prepareTransparentLogo() {
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const maxC = Math.max(r, g, b);
        if (r > 240 && g > 240 && b > 240) {
          data[i + 3] = 0;
        } else if (maxC < 18) {
          data[i + 3] = 0;
        } else if (maxC < 44) {
          data[i + 3] = Math.round(((maxC - 18) / 26) * 255);
        }
      }
      ctx.putImageData(imageData, 0, 0);
      const dataUrl = canvas.toDataURL('image/png');
      state.transparentLogoDataUrl = dataUrl;
      document.querySelectorAll('.brand-logo-img').forEach(el => {
        el.src = dataUrl;
      });
      document.querySelectorAll('.brand-logo-wrap').forEach(wrap => {
        wrap.classList.add('transparent-ready');
      });
    } catch (err) {
      console.warn('Logo canvas fallback active:', err);
    }
  };
  img.src = state.settings.logoUrl || '/assets/aistudio/image_cd2fbd85.png';
}

// =========================================================================
// 6. REAL-TIME FIRESTORE LISTENERS & SEEDING
// =========================================================================
let unsubAuthedListeners = [];

function setupPublicListeners() {
  if (!db) return;
  // Settings listener
  onSnapshot(doc(db, 'settings', 'store'), (snap) => {
    if (snap.exists()) {
      state.settings = { ...DEFAULT_SETTINGS, ...snap.data() };
      applySettingsToUI();
    }
  }, (err) => handleFirestoreError(err, OperationType.GET, 'settings/store'));

  // Categories listener
  onSnapshot(query(collection(db, 'categories'), where('active', '==', true)), (snap) => {
    if (!snap.empty) {
      state.categories = snap.docs
        .map(d => d.data())
        .sort((a, b) => (a.order || 0) - (b.order || 0));
      renderCategoriesUI();
    }
  }, (err) => handleFirestoreError(err, OperationType.LIST, 'categories'));

  // Banners listener
  onSnapshot(query(collection(db, 'banners'), where('active', '==', true)), (snap) => {
    if (!snap.empty) {
      state.banners = snap.docs
        .map(d => d.data())
        .sort((a, b) => (a.order || 0) - (b.order || 0));
      renderHeroSlider();
      renderPromoBanner();
    }
  }, (err) => handleFirestoreError(err, OperationType.LIST, 'banners'));

  // Products listener
  onSnapshot(query(collection(db, 'products'), where('active', '==', true)), (snap) => {
    if (!snap.empty) {
      state.products = snap.docs.map(d => d.data());
      renderAllProductGrids();
    }
  }, (err) => handleFirestoreError(err, OperationType.LIST, 'products'));

  // Coupons listener
  onSnapshot(query(collection(db, 'coupons'), where('active', '==', true)), (snap) => {
    if (!snap.empty) {
      state.coupons = snap.docs.map(d => d.data());
    }
  }, (err) => handleFirestoreError(err, OperationType.LIST, 'coupons'));

  // Approved Reviews listener
  onSnapshot(query(collection(db, 'reviews'), where('status', '==', 'approved')), (snap) => {
    state.reviews = snap.docs.map(d => d.data());
    if (state.currentView === 'product' && state.activeProductId) {
      renderProductDetailView(state.activeProductId);
    }
  }, (err) => handleFirestoreError(err, OperationType.LIST, 'reviews'));
}

function setupAuthenticatedListeners(user, isAdmin) {
  unsubAuthedListeners.forEach(fn => fn());
  unsubAuthedListeners = [];
  if (!user || !db) return;

  // User profile listener
  const unsubProfile = onSnapshot(doc(db, 'users', user.uid), (snap) => {
    if (snap.exists()) {
      state.userProfile = snap.data();
      if (Array.isArray(state.userProfile.wishlist) && state.userProfile.wishlist.length > 0) {
        state.wishlist = Array.from(new Set([...state.wishlist, ...state.userProfile.wishlist]));
        localStorage.setItem('sbd_wishlist', JSON.stringify(state.wishlist));
        updateCountersUI();
      }
      if (state.currentView === 'account') renderAccountView();
    }
  }, (err) => handleFirestoreError(err, OperationType.GET, `users/${user.uid}`));
  unsubAuthedListeners.push(unsubProfile);

  // Orders listener (Admin gets all orders; customer gets own orders)
  const ordersQuery = isAdmin
    ? collection(db, 'orders')
    : query(collection(db, 'orders'), where('userId', '==', user.uid));
  const unsubOrders = onSnapshot(ordersQuery, (snap) => {
    state.orders = snap.docs
      .map(d => d.data())
      .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    if (state.currentView === 'account') renderAccountView();
    if (state.currentView === 'admin') renderAdminView();
  }, (err) => handleFirestoreError(err, OperationType.LIST, 'orders'));
  unsubAuthedListeners.push(unsubOrders);

  // Notifications listener
  const notifQuery = isAdmin
    ? collection(db, 'notifications')
    : query(collection(db, 'notifications'), where('targetUserId', '==', user.uid));
  const unsubNotifs = onSnapshot(notifQuery, (snap) => {
    state.notifications = snap.docs
      .map(d => d.data())
      .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    updateCountersUI();
  }, (err) => handleFirestoreError(err, OperationType.LIST, 'notifications'));
  unsubAuthedListeners.push(unsubNotifs);

  if (isAdmin) {
    // Admin also listens to all products, categories, banners, coupons, users, reviews
    const unsubAllProducts = onSnapshot(collection(db, 'products'), (snap) => {
      if (!snap.empty) {
        state.products = snap.docs.map(d => d.data());
        renderAllProductGrids();
        if (state.currentView === 'admin') renderAdminView();
      }
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'products'));

    const unsubAllUsers = onSnapshot(collection(db, 'users'), (snap) => {
      state.customers = snap.docs.map(d => d.data());
      if (state.currentView === 'admin') renderAdminView();
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'users'));

    const unsubAllReviews = onSnapshot(collection(db, 'reviews'), (snap) => {
      state.reviews = snap.docs.map(d => d.data());
      if (state.currentView === 'admin') renderAdminView();
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'reviews'));

    unsubAuthedListeners.push(unsubAllProducts, unsubAllUsers, unsubAllReviews);
  }
}

async function seedInitialDatabaseIfEmpty() {
  if (!state.isAdmin) return;
  try {
    const prodSnap = await getDocs(collection(db, 'products'));
    if (!prodSnap.empty) return;

    const batch = writeBatch(db);
    batch.set(doc(db, 'settings', 'store'), {
      ...DEFAULT_SETTINGS,
      updatedAt: serverTimestamp()
    });
    for (const cat of DEFAULT_CATEGORIES) {
      batch.set(doc(db, 'categories', cat.id), {
        ...cat,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }
    for (const ban of DEFAULT_BANNERS) {
      batch.set(doc(db, 'banners', ban.id), {
        ...ban,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }
    for (const prod of DEFAULT_PRODUCTS) {
      batch.set(doc(db, 'products', prod.id), {
        ...prod,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }
    for (const cpn of DEFAULT_COUPONS) {
      batch.set(doc(db, 'coupons', cpn.id), {
        ...cpn,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }
    await batch.commit();
    showToast('Initial Store BD Online catalog synced to Firestore!');
  } catch (err) {
    console.warn('Auto-seed skipped:', err);
  }
}


// =========================================================================
// 15. NAVIGATION, MODALS, STATIC PAGES & GLOBAL EVENT DELEGATION
// =========================================================================
function switchView(viewName) {
  state.currentView = viewName;
  document.querySelectorAll('.view-panel').forEach(el => {
    el.classList.toggle('active', el.id === `view-${viewName}`);
  });
  document.querySelectorAll('.desktop-nav-link, .bottom-nav-item').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-nav') === viewName);
  });

  if (viewName === 'deals') {
    state.currentView = 'shop';
    document.getElementById('view-shop').classList.add('active');
    state.selectedCategory = 'all';
    renderShopGrid();
  } else if (viewName === 'shop') {
    renderShopGrid();
  } else if (viewName === 'wishlist') {
    renderWishlistGrid();
  } else if (viewName === 'checkout') {
    renderCheckoutView();
  } else if (viewName === 'account') {
    renderAccountView();
    syncOrdersWithServer();
  } else if (viewName === 'admin') {
    renderAdminView();
    syncOrdersWithServer();
  }
  toggleMobileMenu(false);
  window.scrollTo({ top: 0, behavior: 'smooth' });
  refreshIcons();
}

function toggleMobileMenu(open) {
  document.getElementById('mobileMenuBackdrop')?.classList.toggle('open', open);
  document.getElementById('mobileMenuDrawer')?.classList.toggle('open', open);
}

function toggleCartDrawer(open) {
  if (open) renderCartDrawer();
  document.getElementById('cartDrawerBackdrop')?.classList.toggle('open', open);
  document.getElementById('cartDrawer')?.classList.toggle('open', open);
}

function openDynamicModal(title, bodyHtml) {
  document.getElementById('dynamicModalTitle').textContent = title;
  document.getElementById('dynamicModalBody').innerHTML = bodyHtml;
  document.getElementById('dynamicModal').classList.add('open');
  refreshIcons();
}

function closeDynamicModal() {
  document.getElementById('dynamicModal').classList.remove('open');
}

function openInfoPage(type) {
  const siteTitle = state.settings.siteName || 'STORE BD ONLINE';
  const pages = {
    about: {
      title: `About ${siteTitle}`,
      body: `${siteTitle} (${state.settings.tagline || 'Shop Smart • Save More'}) is Bangladesh’s premier online retail destination for authentic smart gadgets, wireless audio, home security cameras, portable projectors, and gaming accessories. Every order is backed by fast nationwide delivery and responsive customer support.`
    },
    contact: {
      title: 'Contact Us',
      body: `Need help with an order or product inquiry? Reach our support team 24/7 via Email (${state.settings.supportEmail}), WhatsApp (${state.settings.whatsappNumber}), or visit our Dhaka dispatch center at ${state.settings.address}.`
    },
    privacy: {
      title: 'Privacy Policy',
      body: 'We strictly protect your personal data (Name, Phone Number, Delivery Address) using isolated Firestore security rules. Your information is used solely to fulfill and deliver your orders and is never shared with unauthorized third parties.'
    },
    terms: {
      title: 'Terms & Conditions',
      body: 'All prices are listed in Bangladeshi Taka (BDT ৳). Manual bKash and Nagad payments require valid Transaction ID verification by our billing team prior to dispatch.'
    },
    refund: {
      title: '7-Day Return & Replacement Policy',
      body: 'If you receive a damaged, defective, or incorrect item, notify us within 7 days of delivery with unboxing proof for a fast replacement or full refund via bKash/Nagad.'
    },
    shipping: {
      title: 'Shipping & Delivery Policy',
      body: `Inside City delivery: ${formatPrice(state.settings.insideDhakaFee)}. Outside City courier delivery: ${formatPrice(state.settings.outsideDhakaFee)}. Orders above ${formatPrice(state.settings.freeDeliveryThreshold)} qualify for FREE shipping. ${state.settings.estimatedDeliveryMessage || ''}`
    },
    faq: {
      title: 'Frequently Asked Questions (FAQ)',
      body: 'Q: Can I pay via Cash on Delivery? Yes, Cash on Delivery is available across Bangladesh. Q: How do I track my order? Click "Track Order" in the navigation bar and enter your Order ID and phone number.'
    }
  };
  const info = pages[type] || pages.about;
  document.getElementById('infoPageContent').innerHTML = `
    <h1 class="section-title" style="margin-bottom:12px;">${escapeHtml(info.title)}</h1>
    <p style="font-size:14.5px;color:var(--text-secondary);line-height:1.7;margin-bottom:20px;">${escapeHtml(info.body)}</p>
    <button type="button" class="btn btn-red" data-nav="home">← Back to Storefront</button>
  `;
  switchView('info');
}

// Global delegated click listener
document.addEventListener('click', (e) => {
  const navBtn = e.target.closest('[data-nav]');
  if (navBtn) {
    e.preventDefault();
    switchView(navBtn.getAttribute('data-nav'));
    return;
  }

  const infoBtn = e.target.closest('[data-info]');
  if (infoBtn) {
    e.preventDefault();
    openInfoPage(infoBtn.getAttribute('data-info'));
    return;
  }

  const catBtn = e.target.closest('[data-category-filter]');
  if (catBtn) {
    const cat = catBtn.getAttribute('data-category-filter');
    state.selectedCategory = state.selectedCategory === cat ? 'all' : cat;
    renderCategoriesUI();
    switchView('shop');
    return;
  }

  const prodOpen = e.target.closest('[data-open-product]');
  if (prodOpen) {
    openProductDetail(prodOpen.getAttribute('data-open-product'));
    return;
  }

  const addCartBtn = e.target.closest('[data-add-cart]');
  if (addCartBtn) {
    e.stopPropagation();
    addToCart(addCartBtn.getAttribute('data-add-cart'), 1, true);
    return;
  }

  const wishBtn = e.target.closest('[data-toggle-wishlist]');
  if (wishBtn) {
    e.stopPropagation();
    toggleWishlist(wishBtn.getAttribute('data-toggle-wishlist'));
    return;
  }

  const dotBtn = e.target.closest('[data-hero-dot]');
  if (dotBtn) {
    state.heroIndex = Number(dotBtn.getAttribute('data-hero-dot')) || 0;
    updateActiveHeroSlide();
    return;
  }

  const colTab = e.target.closest('[data-collection]');
  if (colTab) {
    state.selectedCollectionTab = colTab.getAttribute('data-collection');
    document.querySelectorAll('#featuredCollectionTabs .collection-tab-btn').forEach(b => {
      b.classList.toggle('active', b === colTab);
    });
    renderFeaturedCollectionTabGrid();
    return;
  }

  const cartDec = e.target.closest('[data-cart-dec]');
  if (cartDec) {
    updateCartQty(cartDec.getAttribute('data-cart-dec'), -1);
    return;
  }
  const cartInc = e.target.closest('[data-cart-inc]');
  if (cartInc) {
    updateCartQty(cartInc.getAttribute('data-cart-inc'), 1);
    return;
  }
  const cartRem = e.target.closest('[data-cart-rem]');
  if (cartRem) {
    updateCartQty(cartRem.getAttribute('data-cart-rem'), -9999);
    return;
  }

  if (e.target.id === 'resetShopFiltersBtn') {
    state.selectedCategory = 'all';
    state.searchQuery = '';
    document.getElementById('globalSearchInput').value = '';
    renderCategoriesUI();
    renderShopGrid();
  }
});

// Header & Drawer controls
document.getElementById('openMobileMenuBtn')?.addEventListener('click', () => toggleMobileMenu(true));
document.getElementById('closeMobileMenuBtn')?.addEventListener('click', () => toggleMobileMenu(false));
document.getElementById('mobileMenuBackdrop')?.addEventListener('click', () => toggleMobileMenu(false));
document.getElementById('mobileCategoriesBtn')?.addEventListener('click', () => toggleMobileMenu(true));

document.getElementById('openCartDrawerBtn')?.addEventListener('click', () => toggleCartDrawer(true));
document.getElementById('closeCartDrawerBtn')?.addEventListener('click', () => toggleCartDrawer(false));
document.getElementById('cartDrawerBackdrop')?.addEventListener('click', () => toggleCartDrawer(false));

document.getElementById('headerAccountBtn')?.addEventListener('click', () => {
  if (state.currentUser) switchView('account');
  else openAuthModal('login');
});

document.getElementById('closeDynamicModalBtn')?.addEventListener('click', closeDynamicModal);
document.getElementById('openFilterModalBtn')?.addEventListener('click', () => switchView('shop'));

// Private Owner Shortcut (3 rapid clicks on Footer Copyright or #admin URL hash)
let ownerShortcutClicks = 0;
let ownerShortcutTimer = null;
document.getElementById('footerCopyrightTrigger')?.addEventListener('click', () => {
  ownerShortcutClicks += 1;
  clearTimeout(ownerShortcutTimer);
  ownerShortcutTimer = setTimeout(() => { ownerShortcutClicks = 0; }, 1200);
  if (ownerShortcutClicks >= 3) {
    ownerShortcutClicks = 0;
    switchView('admin');
  }
});

window.addEventListener('hashchange', () => {
  if (window.location.hash.toLowerCase() === '#admin') {
    switchView('admin');
  }
});

// Hero Previous / Next buttons
document.getElementById('heroPrevBtn')?.addEventListener('click', () => {
  const heroCount = state.banners.filter(b => b.type === 'hero' && b.active !== false).length || 1;
  state.heroIndex = (state.heroIndex - 1 + heroCount) % heroCount;
  updateActiveHeroSlide();
});
document.getElementById('heroNextBtn')?.addEventListener('click', () => {
  const heroCount = state.banners.filter(b => b.type === 'hero' && b.active !== false).length || 1;
  state.heroIndex = (state.heroIndex + 1) % heroCount;
  updateActiveHeroSlide();
});

// Notifications Modal
document.getElementById('openNotificationsBtn')?.addEventListener('click', () => {
  const modal = document.getElementById('notificationsModal');
  const list = document.getElementById('notificationsListContainer');
  if (!modal || !list) return;

  if (state.notifications.length === 0) {
    list.innerHTML = `<p style="font-size:13.5px;color:var(--text-secondary);padding:12px 0;">You have no notifications right now.</p>`;
  } else {
    list.innerHTML = state.notifications.map(n => `
      <div style="padding:12px;border-bottom:1px solid var(--border-subtle);background:${n.read ? 'transparent' : 'var(--bg-light)'};">
        <div style="font-weight:700;font-size:13.5px;">${escapeHtml(n.title)}</div>
        <div style="font-size:12.5px;color:var(--text-secondary);margin-top:2px;">${escapeHtml(n.message)}</div>
      </div>
    `).join('');
  }
  modal.classList.add('open');
});
document.getElementById('closeNotificationsModalBtn')?.addEventListener('click', () => {
  document.getElementById('notificationsModal')?.classList.remove('open');
});

// Live Debounced Search Bar & Suggestions
let searchDebounce = null;
const searchInput = document.getElementById('globalSearchInput');
const clearSearchBtn = document.getElementById('clearSearchBtn');
const suggestionsBox = document.getElementById('searchSuggestionsBox');

searchInput?.addEventListener('input', (e) => {
  const val = e.target.value;
  clearSearchBtn?.classList.toggle('visible', val.length > 0);
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(() => {
    state.searchQuery = val;
    const q = val.trim().toLowerCase();
    if (!q) {
      suggestionsBox?.classList.remove('open');
      if (state.currentView === 'shop') renderShopGrid();
      return;
    }
    const matches = state.products.filter(p =>
      p.active !== false && (
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        (p.brand || '').toLowerCase().includes(q)
      )
    ).slice(0, 5);

    if (matches.length > 0 && suggestionsBox) {
      suggestionsBox.innerHTML = matches.map(m => `
        <div class="suggestion-item" data-suggest-id="${escapeHtml(m.id)}">
          <img src="${escapeHtml(m.images?.[0] || '')}" alt="" class="suggestion-thumb" referrerpolicy="no-referrer" />
          <div style="flex:1;min-width:0;">
            <div style="font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(m.name)}</div>
            <div style="font-size:11.5px;color:var(--text-secondary);">${escapeHtml(m.category)} · <strong style="color:var(--brand-red);">${formatPrice(m.discountPrice || m.regularPrice)}</strong></div>
          </div>
        </div>
      `).join('') + `
        <div class="suggestion-item" id="viewAllSearchMatchesBtn" style="justify-content:center;font-size:12.5px;font-weight:700;color:var(--brand-red);">
          View all results for "${escapeHtml(val.trim())}" →
        </div>
      `;
      suggestionsBox.classList.add('open');

      suggestionsBox.querySelectorAll('[data-suggest-id]').forEach(item => {
        item.addEventListener('click', () => {
          suggestionsBox.classList.remove('open');
          openProductDetail(item.getAttribute('data-suggest-id'));
        });
      });
      document.getElementById('viewAllSearchMatchesBtn')?.addEventListener('click', () => {
        suggestionsBox.classList.remove('open');
        switchView('shop');
      });
    } else if (suggestionsBox) {
      suggestionsBox.classList.remove('open');
    }
    if (state.currentView === 'shop') renderShopGrid();
  }, 220);
});

searchInput?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    suggestionsBox?.classList.remove('open');
    switchView('shop');
  }
});

clearSearchBtn?.addEventListener('click', () => {
  searchInput.value = '';
  state.searchQuery = '';
  clearSearchBtn.classList.remove('visible');
  suggestionsBox?.classList.remove('open');
  renderShopGrid();
});

document.getElementById('shopCategorySelect')?.addEventListener('change', (e) => {
  state.selectedCategory = e.target.value;
  renderCategoriesUI();
  renderShopGrid();
});
document.getElementById('shopSortSelect')?.addEventListener('change', (e) => {
  state.sortBy = e.target.value;
  renderShopGrid();
});

document.getElementById('orderTrackingForm')?.addEventListener('submit', handleOrderTrackingSubmit);

async function syncOrdersWithServer() {
  const token = sessionStorage.getItem('sbd_server_session_token') || '';
  try {
    const resp = await fetch('/api/orders', {
      headers: token ? { Authorization: `Bearer ${token}` } : {}
    });
    if (resp.ok) {
      const data = await resp.json();
      if (Array.isArray(data.orders)) {
        const localList = JSON.parse(localStorage.getItem('sbd_local_orders') || '[]');
        const map = new Map();
        for (const ord of localList) {
          if (ord && ord.id) map.set(ord.id, ord);
        }
        for (const ord of data.orders) {
          if (ord && ord.id) map.set(ord.id, ord);
        }
        const merged = Array.from(map.values()).sort((a, b) => {
          const dA = new Date(a.createdAt?.seconds ? a.createdAt.seconds * 1000 : (a.createdAt || 0)).getTime();
          const dB = new Date(b.createdAt?.seconds ? b.createdAt.seconds * 1000 : (b.createdAt || 0)).getTime();
          return dB - dA;
        });
        state.orders = merged;
        localStorage.setItem('sbd_local_orders', JSON.stringify(merged));
        if (state.currentView === 'admin') renderAdminView();
        if (state.currentView === 'account') renderAccountView();
      }
    }
  } catch (err) {
    console.warn('Orders sync notice:', err);
  }
}

// Initial Boot
function initApp() {
  prepareTransparentLogo();
  applySettingsToUI();
  renderHeroSlider();
  renderPromoBanner();
  renderCategoriesUI();
  renderAllProductGrids();
  updateCountersUI();
  setupPublicListeners();
  syncOrdersWithServer();
  if (window.location.hash.toLowerCase() === '#admin') {
    switchView('admin');
  }
  refreshIcons();
}

Object.assign(globalThis, {
  firebaseConfig, ADMIN_EMAIL, app, db, auth, storage, OperationType, handleFirestoreError,
  DEFAULT_SETTINGS, DEFAULT_CATEGORIES, DEFAULT_BANNERS, DEFAULT_PRODUCTS, DEFAULT_COUPONS, BD_DIVISIONS,
  state, formatPrice, escapeHtml, showToast, refreshIcons, prepareTransparentLogo,
  setupPublicListeners, setupAuthenticatedListeners, seedInitialDatabaseIfEmpty, formatBrandHtml,
  getWhatsAppUrl, applySettingsToUI, updateCountersUI, renderHeroSlider, updateActiveHeroSlide,
  renderPromoBanner, renderCategoriesUI, createProductCardHTML, renderAllProductGrids,
  renderFeaturedCollectionTabGrid, renderShopGrid, renderWishlistGrid, openProductDetail,
  renderProductDetailView, toggleWishlist, openReviewModal, saveCart, addToCart, updateCartQty,
  calculateCartTotals, renderCartDrawer, applyCouponCode, renderCheckoutView, handleCheckoutSubmit,
  renderOrderConfirmation, ORDER_STATUS_STEPS, handleOrderTrackingSubmit, clearOtpTimer,
  openForgotPasswordOtpFlow, activateServerCustomerSession, openAuthModal, ensureUserProfileDoc,
  renderAccountView, validateAdminImageFile, uploadImageAsset, renderAdminView, renderAdminOverview,
  renderAdminProducts, openProductFormModal, renderAdminCategories, renderAdminOrders,
  renderAdminCustomers, renderAdminBanners, renderAdminCoupons, renderAdminReviews,
  renderAdminSettings, renderAdminReports, downloadCsv, switchView, toggleMobileMenu,
  toggleCartDrawer, openDynamicModal, closeDynamicModal, openInfoPage, initApp, syncOrdersWithServer
});

// Firebase Auth Listener (Hides Admin links from all non-admin visitors)
if (auth) {
  onAuthStateChanged(auth, async (user) => {
  if (user) {
    sessionStorage.removeItem('sbd_server_session_token');
    state.currentUser = user;
    state.isAdmin = Boolean(user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase() && user.emailVerified);

    const topAdminBtn = document.getElementById('topAdminBtn');
    const topAdminSep = document.getElementById('topAdminSep');
    const mobileAdminBtn = document.getElementById('mobileDrawerAdminBtn');
    if (topAdminBtn) topAdminBtn.style.display = state.isAdmin ? 'inline-block' : 'none';
    if (topAdminSep) topAdminSep.style.display = state.isAdmin ? 'inline' : 'none';
    if (mobileAdminBtn) mobileAdminBtn.style.display = state.isAdmin ? 'flex' : 'none';

    await ensureUserProfileDoc(user);
    setupAuthenticatedListeners(user, state.isAdmin);
    if (state.isAdmin) {
      seedInitialDatabaseIfEmpty();
    }
  } else {
    const topAdminBtn = document.getElementById('topAdminBtn');
    const topAdminSep = document.getElementById('topAdminSep');
    const mobileAdminBtn = document.getElementById('mobileDrawerAdminBtn');
    if (topAdminBtn) topAdminBtn.style.display = 'none';
    if (topAdminSep) topAdminSep.style.display = 'none';
    if (mobileAdminBtn) mobileAdminBtn.style.display = 'none';

    state.isAdmin = false;
    setupAuthenticatedListeners(null, false);

    const token = sessionStorage.getItem('sbd_server_session_token') || '';
    if (token) {
      try {
        const resp = await fetch('/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await resp.json();
        if (resp.ok && data.ok && data.user) {
          activateServerCustomerSession(data.user, token);
          return;
        }
      } catch (_) {}
      sessionStorage.removeItem('sbd_server_session_token');
    }

    state.currentUser = null;
    state.userProfile = null;
  }
  if (state.currentView === 'account') renderAccountView();
  if (state.currentView === 'admin') renderAdminView();
  });
}

initApp();

