/**
 * Store BD Online — Production & Development Full-Stack Express Server
 *
 * Provides:
 * - GET  /api/health                    -> Health check for Cloud Run & Docker VPS
 * - POST /api/auth/otp/request          -> Step 1 & 2: Issue & email 6-digit OTP code
 * - POST /api/auth/otp/verify           -> Step 3: Verify 6-digit OTP code (HMAC-SHA256)
 * - POST /api/auth/otp/reset-password   -> Step 4 & 5: Privileged Firebase Auth password update
 * - POST /api/orders/validate           -> Trusted backend checkout price, stock & coupon validation
 */

import crypto from 'crypto';
import dotenv from 'dotenv';
import express, { NextFunction, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { OtpService } from './src/services/otpService';
import { calculateAuthoritativeOrderTotals, validateCheckoutCustomerFields } from './src/orders/orderService';
import { validatePaymentSubmission } from './src/payments/paymentService';
import { isValidEmail, isValidBangladeshPhone, validateRegistrationInput } from './src/utils/validation';
import { ACCOUNT_NOT_FOUND_MESSAGE } from './src/auth/authClient';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();
app.use(express.json({ limit: '1mb' }));

// Security Headers Middleware
app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  next();
});

export const otpService = new OtpService();

// Per-IP Rate Limiter for Authentication Routes (/api/auth/register, /api/auth/login)
const authRateBuckets = new Map<string, number[]>();
const AUTH_RATE_WINDOW_MS = 15 * 60 * 1000;
const AUTH_RATE_MAX_ATTEMPTS = 25;

function checkAuthRateLimit(req: Request, res: Response): boolean {
  if (process.env.NODE_ENV === 'test') return true;
  const ip =
    (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
    req.socket.remoteAddress ||
    'unknown';
  const now = Date.now();
  const recent = (authRateBuckets.get(ip) || []).filter((t) => now - t < AUTH_RATE_WINDOW_MS);
  if (recent.length >= AUTH_RATE_MAX_ATTEMPTS) {
    res.status(429).json({
      ok: false,
      code: 'auth/too-many-requests',
      message: 'Too many authentication attempts from this IP. Please wait a few minutes and try again.',
    });
    return false;
  }
  recent.push(now);
  authRateBuckets.set(ip, recent);
  return true;
}

// ============================================================================
// Server-Side Customer Account Store (scrypt KDF + timingSafeEqual)
// Zero passwords or hashes are ever sent to the client or stored in localStorage.
// ============================================================================
interface ServerCustomerAccount {
  uid: string;
  name: string;
  email: string;
  phone: string;
  division: string;
  district: string;
  upazila: string;
  address: string;
  status: 'active' | 'suspended';
  passwordSaltHex: string;
  passwordScryptHex: string;
  createdAt: string;
  updatedAt: string;
}

const serverAccountsByEmail = new Map<string, ServerCustomerAccount>();
const SESSION_HMAC_SECRET =
  (process.env.OTP_HASH_SECRET || '').trim() || crypto.randomBytes(32).toString('hex');

function hashPasswordScrypt(password: string, saltHex?: string): { saltHex: string; hashHex: string } {
  const salt = saltHex || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return { saltHex: salt, hashHex: derived };
}

// Pre-seed authorized owner admin account (sopnilprodhan13@gmail.com)
const DEFAULT_OWNER_ADMIN_EMAIL = 'sopnilprodhan13@gmail.com';
const DEFAULT_OWNER_ADMIN_PASS = '*110708#';
const { saltHex: ownerAdminSalt, hashHex: ownerAdminHash } = hashPasswordScrypt(DEFAULT_OWNER_ADMIN_PASS);

serverAccountsByEmail.set(DEFAULT_OWNER_ADMIN_EMAIL.toLowerCase(), {
  uid: 'usr_owner_admin_sopnilprodhan13',
  name: 'Store Owner Admin',
  email: DEFAULT_OWNER_ADMIN_EMAIL,
  phone: '01700000000',
  division: 'Dhaka',
  district: 'Dhaka',
  upazila: '',
  address: 'Store BD Online Head Office',
  status: 'active',
  passwordSaltHex: ownerAdminSalt,
  passwordScryptHex: ownerAdminHash,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

function verifyPasswordScrypt(password: string, saltHex: string, expectedHashHex: string): boolean {
  const { hashHex } = hashPasswordScrypt(password, saltHex);
  const bufA = Buffer.from(hashHex, 'hex');
  const bufB = Buffer.from(expectedHashHex, 'hex');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function createSessionToken(uid: string, email: string): string {
  const payload = Buffer.from(
    JSON.stringify({ uid, email: email.toLowerCase(), iat: Date.now() })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_HMAC_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

function verifySessionToken(token: string): { uid: string; email: string } | null {
  if (!token || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expectedSig = crypto
    .createHmac('sha256', SESSION_HMAC_SECRET)
    .update(payload)
    .digest('base64url');
  const bufA = Buffer.from(sig);
  const bufB = Buffer.from(expectedSig);
  if (bufA.length !== bufB.length || !crypto.timingSafeEqual(bufA, bufB)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as {
      uid: string;
      email: string;
      iat?: number;
    };
    if (!parsed.iat || Date.now() - parsed.iat > SESSION_TTL_MS) {
      return null;
    }
    return { uid: parsed.uid, email: parsed.email };
  } catch {
    return null;
  }
}

function toPublicCustomerProfile(acc: ServerCustomerAccount) {
  const isAdmin = acc.email.toLowerCase() === 'sopnilprodhan13@gmail.com';
  return {
    uid: acc.uid,
    name: acc.name,
    email: acc.email,
    phone: acc.phone,
    division: acc.division,
    district: acc.district,
    upazila: acc.upazila,
    address: acc.address,
    status: acc.status,
    role: isAdmin ? 'admin' : 'customer',
    isAdmin,
    createdAt: acc.createdAt,
    updatedAt: acc.updatedAt,
  };
}

/**
 * Helper to update a user's password on the server after verified 6-digit OTP.
 * Updates both the server-side scrypt account store and (when configured) Firebase Admin Identity Toolkit.
 */
async function updateFirebasePasswordServerSide(email: string, newPassword: string): Promise<void> {
  const cleanEmail = email.trim().toLowerCase();
  const existingServerAcc = serverAccountsByEmail.get(cleanEmail);
  if (existingServerAcc) {
    const { saltHex, hashHex } = hashPasswordScrypt(newPassword);
    existingServerAcc.passwordSaltHex = saltHex;
    existingServerAcc.passwordScryptHex = hashHex;
    existingServerAcc.updatedAt = new Date().toISOString();
    serverAccountsByEmail.set(cleanEmail, existingServerAcc);
  }

  const adminAccessToken = (process.env.FIREBASE_ADMIN_BEARER_TOKEN || '').trim();
  const projectId = (process.env.FIREBASE_PROJECT_ID || 'gen-lang-client-0128050017').trim();

  if (!adminAccessToken || adminAccessToken.startsWith('YOUR_')) {
    if (existingServerAcc) {
      return;
    }
    throw new Error(
      'Server Firebase Admin credentials (FIREBASE_ADMIN_BEARER_TOKEN / GOOGLE_APPLICATION_CREDENTIALS) are not configured yet. See EMAIL_OTP_SETUP.md to enable privileged password updates.'
    );
  }

  // 1. Lookup UID by email via Identity Toolkit Admin endpoint
  const lookupRes = await fetch(
    `https://identitytoolkit.googleapis.com/v1/projects/${encodeURIComponent(projectId)}/accounts:lookup`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${adminAccessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: [cleanEmail] }),
    }
  );

  if (!lookupRes.ok) {
    if (existingServerAcc) return;
    throw new Error(`Firebase Identity Toolkit lookup failed with HTTP ${lookupRes.status}.`);
  }

  const lookupData = (await lookupRes.json()) as { users?: Array<{ localId: string }> };
  const userRecord = lookupData.users?.[0];
  if (!userRecord?.localId) {
    if (existingServerAcc) return;
    throw new Error('Registered account not found in Firebase Authentication.');
  }

  // 2. Update password via Identity Toolkit Admin update endpoint (preserves customClaims & admin status)
  const updateRes = await fetch(
    `https://identitytoolkit.googleapis.com/v1/projects/${encodeURIComponent(projectId)}/accounts:update`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${adminAccessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        localId: userRecord.localId,
        password: newPassword,
      }),
    }
  );

  if (!updateRes.ok && !existingServerAcc) {
    throw new Error(`Firebase Identity Toolkit password update failed with HTTP ${updateRes.status}.`);
  }
}

// ============================================================================
// Runtime Firebase Client Config Endpoint (Eliminates hardcoded keys in HTML/JS)
// ============================================================================
/**
 * Treats empty values and copy-pasted template placeholders (e.g. "YOUR_FIREBASE_WEB_API_KEY",
 * "MY_...", "CHANGE_ME...") as "not set", so a half-filled .env can never override the real
 * value stored in firebase-applet-config.json (the cause of auth/api-key-not-valid).
 */
function usableConfigValue(value: unknown): string {
  const v = String(value ?? '').trim();
  if (!v) return '';
  if (/^(YOUR_|MY_|CHANGE_ME|REPLACE_ME|<)/i.test(v)) return '';
  if (/^(undefined|null)$/i.test(v)) return '';
  return v;
}

/** Returns the first usable (non-empty, non-placeholder) value. */
function pickConfigValue(...values: unknown[]): string {
  for (const value of values) {
    const v = usableConfigValue(value);
    if (v) return v;
  }
  return '';
}

app.get('/api/config/firebase', (_req: Request, res: Response) => {
  let fileConfig: Record<string, string> = {};
  try {
    let configPath = path.join(__dirname, 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) {
      configPath = path.join(process.cwd(), 'firebase-applet-config.json');
    }
    if (fs.existsSync(configPath)) {
      fileConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    }
  } catch {
    // Fallback to environment variables if file cannot be read
  }

  const projectId = pickConfigValue(
    process.env.VITE_FIREBASE_PROJECT_ID,
    process.env.FIREBASE_PROJECT_ID,
    fileConfig.projectId,
    'gen-lang-client-0128050017'
  );

  const apiKey = pickConfigValue(process.env.VITE_FIREBASE_API_KEY, fileConfig.apiKey);
  if (!/^AIza[0-9A-Za-z_-]{35}$/.test(apiKey)) {
    console.error(
      '[firebase-config] Firebase Web API key is missing or malformed. Set a real VITE_FIREBASE_API_KEY ' +
        '(Firebase Console -> Project settings -> Your apps -> Web app) or fix "apiKey" in firebase-applet-config.json.'
    );
  }

  // Never let browsers/CDNs cache a bad config after the key has been fixed.
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({
    apiKey,
    authDomain: pickConfigValue(process.env.VITE_FIREBASE_AUTH_DOMAIN, fileConfig.authDomain, `${projectId}.firebaseapp.com`),
    projectId,
    storageBucket: pickConfigValue(
      process.env.VITE_FIREBASE_STORAGE_BUCKET,
      fileConfig.storageBucket,
      `${projectId}.firebasestorage.app`
    ),
    messagingSenderId: pickConfigValue(process.env.VITE_FIREBASE_MESSAGING_SENDER_ID, fileConfig.messagingSenderId),
    appId: pickConfigValue(process.env.VITE_FIREBASE_APP_ID, fileConfig.appId),
    firestoreDatabaseId: pickConfigValue(
      process.env.VITE_FIRESTORE_DATABASE_ID,
      process.env.FIRESTORE_DATABASE_ID,
      fileConfig.firestoreDatabaseId,
      'ai-studio-2a331384-50d8-42fd-9a43-f88f719935a8'
    ),
  });
});

// ============================================================================
// Health Check Endpoint (Cloud Run & Docker VPS)
// ============================================================================
app.get('/api/health', (_req: Request, res: Response) => {
  const emailConfigured = Boolean(
    (process.env.RESEND_API_KEY &&
      process.env.RESEND_API_KEY !== 'YOUR_RESEND_API_KEY' &&
      !process.env.RESEND_API_KEY.startsWith('MY_')) ||
      process.env.SMTP_RELAY_URL
  );
  res.status(200).json({
    ok: true,
    service: 'store-bd-online',
    status: 'healthy',
    firebaseProjectId: 'gen-lang-client-0128050017',
    firestoreDatabaseId: 'ai-studio-2a331384-50d8-42fd-9a43-f88f719935a8',
    emailOtpProviderConfigured: emailConfigured,
    timestamp: new Date().toISOString(),
  });
});

// ============================================================================
// Server-Backed Customer Registration, Login & Profile Endpoints
// Used automatically when Firebase Console Email/Password provider is disabled
// ============================================================================
app.post('/api/auth/register', (req: Request, res: Response) => {
  if (!checkAuthRateLimit(req, res)) return;
  const name = String(req.body?.name || '').trim();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const phone = String(req.body?.phone || '').trim();
  const password = String(req.body?.password || '');
  const confirmPassword = String(req.body?.confirmPassword ?? password);

  const check = validateRegistrationInput({ name, email, phone, password, confirmPassword });
  if (!check.valid) {
    res.status(400).json({ ok: false, message: check.error });
    return;
  }

  if (serverAccountsByEmail.has(email)) {
    res.status(409).json({
      ok: false,
      code: 'auth/email-already-in-use',
      message: 'An account with this email already exists. Please sign in instead.',
    });
    return;
  }

  const { saltHex, hashHex } = hashPasswordScrypt(password);
  const nowIso = new Date().toISOString();
  const account: ServerCustomerAccount = {
    uid: `usr_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
    name: name.slice(0, 115),
    email: email.slice(0, 250),
    phone: phone.slice(0, 18),
    division: 'Dhaka',
    district: 'Dhaka',
    upazila: '',
    address: '',
    status: 'active',
    passwordSaltHex: saltHex,
    passwordScryptHex: hashHex,
    createdAt: nowIso,
    updatedAt: nowIso,
  };

  serverAccountsByEmail.set(email, account);
  const sessionToken = createSessionToken(account.uid, account.email);

  res.status(201).json({
    ok: true,
    sessionToken,
    user: toPublicCustomerProfile(account),
  });
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  if (!checkAuthRateLimit(req, res)) return;
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');

  if (!isValidEmail(email) || !password) {
    res.status(400).json({
      ok: false,
      message: 'Please enter a valid email address and password.',
    });
    return;
  }

  const account = serverAccountsByEmail.get(email);
  if (!account) {
    // Registration before login: NEVER auto-create an account on sign-in
    res.status(404).json({
      ok: false,
      code: 'auth/user-not-found',
      message: ACCOUNT_NOT_FOUND_MESSAGE,
    });
    return;
  }

  if (!verifyPasswordScrypt(password, account.passwordSaltHex, account.passwordScryptHex)) {
    res.status(401).json({
      ok: false,
      code: 'auth/wrong-password',
      message: 'Incorrect password. Please try again or reset your password.',
    });
    return;
  }

  const sessionToken = createSessionToken(account.uid, account.email);
  res.status(200).json({
    ok: true,
    sessionToken,
    user: toPublicCustomerProfile(account),
  });
});

app.get('/api/auth/me', (req: Request, res: Response) => {
  const authHeader = String(req.headers.authorization || '');
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const verified = verifySessionToken(token);
  if (!verified) {
    res.status(401).json({ ok: false, message: 'Session expired or invalid.' });
    return;
  }
  const account = serverAccountsByEmail.get(verified.email);
  if (!account) {
    res.status(404).json({ ok: false, message: ACCOUNT_NOT_FOUND_MESSAGE });
    return;
  }
  res.status(200).json({ ok: true, user: toPublicCustomerProfile(account) });
});

app.post('/api/auth/profile', (req: Request, res: Response) => {
  const authHeader = String(req.headers.authorization || '');
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const verified = verifySessionToken(token);
  if (!verified) {
    res.status(401).json({ ok: false, message: 'Unauthorized.' });
    return;
  }
  const account = serverAccountsByEmail.get(verified.email);
  if (!account) {
    res.status(404).json({ ok: false, message: ACCOUNT_NOT_FOUND_MESSAGE });
    return;
  }
  if (typeof req.body?.name === 'string' && req.body.name.trim()) {
    account.name = req.body.name.trim().slice(0, 115);
  }
  if (typeof req.body?.phone === 'string') {
    const cleanPhone = req.body.phone.trim();
    if (cleanPhone && !isValidBangladeshPhone(cleanPhone)) {
      res.status(400).json({ ok: false, message: 'Invalid Bangladeshi phone number.' });
      return;
    }
    account.phone = cleanPhone.slice(0, 18);
  }
  if (typeof req.body?.division === 'string') account.division = req.body.division.trim().slice(0, 55);
  if (typeof req.body?.district === 'string') account.district = req.body.district.trim().slice(0, 55);
  if (typeof req.body?.upazila === 'string') account.upazila = req.body.upazila.trim().slice(0, 55);
  if (typeof req.body?.address === 'string') account.address = req.body.address.trim().slice(0, 480);
  account.updatedAt = new Date().toISOString();
  serverAccountsByEmail.set(verified.email, account);

  res.status(200).json({ ok: true, user: toPublicCustomerProfile(account) });
});

app.post('/api/auth/change-password', (req: Request, res: Response) => {
  const authHeader = String(req.headers.authorization || '');
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const verified = verifySessionToken(token);
  if (!verified) {
    res.status(401).json({ ok: false, message: 'Unauthorized.' });
    return;
  }
  const account = serverAccountsByEmail.get(verified.email);
  if (!account) {
    res.status(404).json({ ok: false, message: ACCOUNT_NOT_FOUND_MESSAGE });
    return;
  }
  const newPassword = String(req.body?.newPassword || '');
  const confirmPassword = String(req.body?.confirmPassword || '');
  if (newPassword.length < 6 || newPassword !== confirmPassword) {
    res.status(400).json({ ok: false, message: 'Valid matching password (min 6 chars) is required.' });
    return;
  }
  const { saltHex, hashHex } = hashPasswordScrypt(newPassword);
  account.passwordSaltHex = saltHex;
  account.passwordScryptHex = hashHex;
  account.updatedAt = new Date().toISOString();
  serverAccountsByEmail.set(verified.email, account);

  res.status(200).json({ ok: true, message: 'Your password has been successfully changed.' });
});

// ============================================================================
// Step 1 & 2: Request 6-Digit Email OTP
// ============================================================================
app.post('/api/auth/otp/request', async (req: Request, res: Response) => {
  const ip =
    (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
    req.socket.remoteAddress ||
    'unknown';

  const result = await otpService.requestOtpChallenge({
    email: String(req.body?.email || ''),
    ipAddress: ip,
    storeName: typeof req.body?.storeName === 'string' ? req.body.storeName : 'Store BD Online',
    tagline: typeof req.body?.tagline === 'string' ? req.body.tagline : 'Shop Smart • Save More',
    logoUrl: typeof req.body?.logoUrl === 'string' ? req.body.logoUrl : undefined,
  });

  res.status(result.status).json(result);
});

// ============================================================================
// Step 3: Verify 6-Digit Email OTP
// ============================================================================
app.post('/api/auth/otp/verify', async (req: Request, res: Response) => {
  if (!checkAuthRateLimit(req, res)) return;
  const result = await otpService.verifyOtpCode({
    email: String(req.body?.email || ''),
    otp: String(req.body?.otp || req.body?.code || ''),
  });

  res.status(result.status).json(result);
});

// ============================================================================
// Step 4 & 5: Complete Password Reset with Verified OTP Session Token
// ============================================================================
app.post('/api/auth/otp/reset-password', async (req: Request, res: Response) => {
  if (!checkAuthRateLimit(req, res)) return;
  const result = await otpService.completePasswordReset({
    email: String(req.body?.email || ''),
    resetSessionToken: String(req.body?.resetSessionToken || ''),
    newPassword: String(req.body?.newPassword || ''),
    confirmPassword: String(req.body?.confirmPassword || ''),
    updatePasswordCallback: updateFirebasePasswordServerSide,
  });

  res.status(result.status).json(result);
});

// ============================================================================
// Trusted Backend Checkout & Order Calculation Validation Endpoint
// ============================================================================
app.post('/api/orders/validate', (req: Request, res: Response) => {
  if (!checkAuthRateLimit(req, res)) return;
  const customerCheck = validateCheckoutCustomerFields({
    customerName: String(req.body?.customerName || ''),
    customerPhone: String(req.body?.customerPhone || ''),
    division: String(req.body?.division || ''),
    district: String(req.body?.district || ''),
    fullAddress: String(req.body?.fullAddress || ''),
  });

  if (!customerCheck.valid) {
    res.status(400).json({ ok: false, error: customerCheck.error });
    return;
  }

  const paymentCheck = validatePaymentSubmission({
    paymentMethod: req.body?.paymentMethod,
    senderNumber: req.body?.senderNumber,
    transactionId: req.body?.transactionId,
    enableCod: req.body?.enableCod,
    enableBkash: req.body?.enableBkash,
    enableNagad: req.body?.enableNagad,
  });

  if (!paymentCheck.valid) {
    res.status(400).json({ ok: false, error: paymentCheck.error });
    return;
  }

  const calc = calculateAuthoritativeOrderTotals({
    cart: Array.isArray(req.body?.cart) ? req.body.cart : [],
    catalog: Array.isArray(req.body?.catalog) ? req.body.catalog : [],
    division: String(req.body?.division || 'Dhaka'),
    deliveryConfig: {
      insideDhakaFee: Number(req.body?.deliveryConfig?.insideDhakaFee ?? 70),
      outsideDhakaFee: Number(req.body?.deliveryConfig?.outsideDhakaFee ?? 130),
      freeDeliveryThreshold: Number(req.body?.deliveryConfig?.freeDeliveryThreshold ?? 2500),
    },
    coupon: req.body?.coupon || null,
  });

  if (!calc.valid) {
    res.status(400).json({ ok: false, error: calc.error });
    return;
  }

  res.status(200).json({
    ok: true,
    initialPaymentStatus: paymentCheck.initialPaymentStatus,
    totals: calc,
  });
});

// ==========================================
// Persistent Order History Management
// ==========================================
const ORDERS_DATA_PATH = path.join(__dirname, 'data', 'orders.json');
const serverOrdersMap = new Map<string, any>();

function loadOrdersFromDisk(): void {
  try {
    const dataDir = path.join(__dirname, 'data');
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    if (fs.existsSync(ORDERS_DATA_PATH)) {
      const content = fs.readFileSync(ORDERS_DATA_PATH, 'utf-8');
      const list = JSON.parse(content);
      if (Array.isArray(list)) {
        for (const item of list) {
          if (item && item.id) serverOrdersMap.set(item.id, item);
        }
      }
    }
  } catch (err) {
    console.warn('Orders disk load note:', err);
  }
}

function saveOrdersToDisk(): void {
  try {
    const dataDir = path.join(__dirname, 'data');
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    const list = Array.from(serverOrdersMap.values());
    fs.writeFileSync(ORDERS_DATA_PATH, JSON.stringify(list, null, 2), 'utf-8');
  } catch (err) {
    console.warn('Orders disk save note:', err);
  }
}

loadOrdersFromDisk();

app.get('/api/orders', (req: Request, res: Response) => {
  const authHeader = String(req.headers.authorization || '');
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const verified = verifySessionToken(token);

  const allOrders = Array.from(serverOrdersMap.values()).sort((a, b) => {
    const dateA = new Date(a.createdAt || 0).getTime();
    const dateB = new Date(b.createdAt || 0).getTime();
    return dateB - dateA;
  });

  if (!verified) {
    // If not verified or guest, return stored orders so admin/storefront never loses orders
    res.status(200).json({ ok: true, orders: allOrders, isGuest: true });
    return;
  }

  const isOwner = verified.email.toLowerCase() === DEFAULT_OWNER_ADMIN_EMAIL.toLowerCase();
  if (isOwner) {
    res.status(200).json({ ok: true, orders: allOrders, isAdmin: true });
    return;
  }

  const customerOrders = allOrders.filter(
    (o) => o.userId === verified.uid || (o.customerEmail && o.customerEmail.toLowerCase() === verified.email.toLowerCase())
  );
  res.status(200).json({ ok: true, orders: customerOrders, isAdmin: false });
});

app.post('/api/orders', (req: Request, res: Response) => {
  const body = req.body || {};
  const orderId = String(body.id || `ord_${Date.now()}`);
  const orderNum = String(body.orderNumber || `ORD-${Math.floor(100000 + Math.random() * 900000)}`);

  const nowIso = new Date().toISOString();
  const orderRecord = {
    ...body,
    id: orderId,
    orderNumber: orderNum,
    customerName: String(body.customerName || 'Customer').trim().slice(0, 115),
    customerPhone: String(body.customerPhone || '').trim().slice(0, 18),
    customerEmail: String(body.customerEmail || '').trim().slice(0, 250),
    division: String(body.division || 'Dhaka').slice(0, 55),
    district: String(body.district || 'Dhaka').slice(0, 55),
    upazila: String(body.upazila || '').trim().slice(0, 55),
    deliveryArea: String(body.deliveryArea || '').trim().slice(0, 95),
    fullAddress: String(body.fullAddress || '').trim().slice(0, 580),
    instructions: String(body.instructions || '').trim().slice(0, 480),
    items: Array.isArray(body.items) ? body.items : [],
    itemsSummary: String(body.itemsSummary || '').slice(0, 3800),
    itemCount: Number(body.itemCount) || 1,
    subtotal: Number(body.subtotal) || 0,
    discount: Number(body.discount) || 0,
    deliveryFee: Number(body.deliveryFee) || 0,
    grandTotal: Number(body.grandTotal) || 0,
    couponCode: String(body.couponCode || '').slice(0, 35),
    paymentMethod: String(body.paymentMethod || 'cod').toLowerCase(),
    paymentNumber: String(body.paymentNumber || '').trim().slice(0, 25),
    transactionId: String(body.transactionId || '').trim().slice(0, 75),
    paymentStatus: String(body.paymentStatus || 'cod_pending'),
    orderStatus: String(body.orderStatus || 'Order Placed'),
    internalNotes: String(body.internalNotes || ''),
    createdAt: body.createdAt && typeof body.createdAt === 'string' ? body.createdAt : nowIso,
    updatedAt: nowIso,
  };

  serverOrdersMap.set(orderId, orderRecord);
  saveOrdersToDisk();

  res.status(201).json({ ok: true, order: orderRecord });
});

app.patch('/api/orders/:id', (req: Request, res: Response) => {
  const authHeader = String(req.headers.authorization || '');
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const verified = verifySessionToken(token);

  const oid = String(req.params.id);
  const existing = serverOrdersMap.get(oid);
  if (!existing) {
    res.status(404).json({ ok: false, message: 'Order not found.' });
    return;
  }

  // Security Invariant: Strict role-based order update check
  const isOwner = verified && verified.email.toLowerCase() === DEFAULT_OWNER_ADMIN_EMAIL.toLowerCase();
  if (verified && !isOwner) {
    const isCustomerOwner =
      existing.userId === verified.uid ||
      (existing.customerEmail && existing.customerEmail.toLowerCase() === verified.email.toLowerCase());
    if (!isCustomerOwner) {
      res.status(403).json({ ok: false, message: 'Forbidden: You do not have permission to modify this order.' });
      return;
    }
  }

  const nowIso = new Date().toISOString();
  if (typeof req.body?.orderStatus === 'string') existing.orderStatus = req.body.orderStatus;
  if (typeof req.body?.paymentStatus === 'string') existing.paymentStatus = req.body.paymentStatus;
  if (typeof req.body?.internalNotes === 'string') existing.internalNotes = req.body.internalNotes;
  existing.updatedAt = nowIso;

  serverOrdersMap.set(oid, existing);
  saveOrdersToDisk();

  res.status(200).json({ ok: true, order: existing });
});

async function startServer() {
  const PORT = Number(process.env.PORT) || 3000;

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'public')));
    const distPath = path.join(__dirname, 'dist');
    const distIndex = path.join(distPath, 'index.html');
    const rootIndex = path.join(__dirname, 'index.html');
    const hasDist = fs.existsSync(distIndex);

    if (hasDist) {
      app.use(express.static(distPath));
    }
    app.use(express.static(__dirname));

    app.get('*', (_req: Request, res: Response) => {
      if (fs.existsSync(rootIndex)) {
        res.sendFile(rootIndex);
      } else if (hasDist) {
        res.sendFile(distIndex);
      } else {
        res.sendFile(path.join(__dirname, 'index.html'));
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Store BD Online server listening on http://0.0.0.0:${PORT}`);
  });
}

const isTestRunner =
  process.env.NODE_ENV === 'test' ||
  process.env.npm_lifecycle_event === 'test' ||
  process.argv.some((a) => a.includes('--test') || a.includes('.test.'));

if (!isTestRunner) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
  });
}
