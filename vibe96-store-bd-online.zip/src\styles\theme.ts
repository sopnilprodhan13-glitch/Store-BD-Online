/**
 * Store BD Online — Responsive Breakpoints, Brand Color Palette & Typography Constants
 */

export const BRAND_PALETTE = {
  black: '#080808',
  red: '#E50914',
  yellow: '#FFD500',
  white: '#FFFFFF',
  background: '#F7F7F8',
  heroHeading: '#111111',
  heroHighlight: '#E50914',
  heroParagraph: '#333333',
  heroBadge: '#8A5700',
} as const;

export const SUPPORTED_VIEWPORT_WIDTHS = [
  320,
  360,
  375,
  390,
  414,
  430,
  768,
  1024,
  1366,
  1920,
] as const;

export const TYPOGRAPHY_FAMILIES = {
  english: "'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
  bengali: "'Hind Siliguri', sans-serif",
} as const;
