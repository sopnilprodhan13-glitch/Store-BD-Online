/**
 * Store BD Online — Complete Admin Logo & Store Branding Customization Service
 *
 * Supports:
 * - File type validation (PNG, JPG/JPEG, WebP, ICO)
 * - File size validation (<= 5MB)
 * - Transparent PNG preservation (never forces onto an opaque background)
 * - Default logo fallback and reset
 * - Authorization guard (only sopnilprodhan13@gmail.com may persist branding changes)
 */

import { ADMIN_OWNER_EMAIL } from '../utils/validation';

export const DEFAULT_BRAND_LOGO_URL = '/assets/aistudio/image_cd2fbd85.png';
export const MAX_LOGO_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB
export const ALLOWED_LOGO_MIME_TYPES = [
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
] as const;

export interface StoreBrandingSettings {
  siteName: string;
  tagline: string;
  footerAbout: string;
  logoUrl: string;
  faviconUrl: string;
  primaryColor: string;
  secondaryColor: string;
  buttonColor: string;
  headerBgColor: string;
  footerBgColor: string;
  promoBarText: string;
  supportEmail: string;
  contactPhone: string;
  whatsappCountryCode: string;
  whatsappNumber: string;
  whatsappDefaultMessage: string;
  whatsappSupportStatus: string;
  enableFloatingWhatsapp: boolean;
  facebookPageName: string;
  facebookUrl: string;
  facebookMessengerUrl: string;
  enableFacebookButton: boolean;
  address: string;
  copyrightText: string;
  seoTitle: string;
  seoDescription: string;
}

export const DEFAULT_BRANDING_SETTINGS: StoreBrandingSettings = {
  siteName: 'STORE BD ONLINE',
  tagline: 'Shop Smart • Save More',
  footerAbout:
    'Trusted Bangladesh online shopping destination for smart gadgets, audio gear, home electronics, and daily tech essentials.',
  logoUrl: DEFAULT_BRAND_LOGO_URL,
  faviconUrl: DEFAULT_BRAND_LOGO_URL,
  primaryColor: '#E50914',
  secondaryColor: '#FFD500',
  buttonColor: '#E50914',
  headerBgColor: '#FFFFFF',
  footerBgColor: '#080808',
  promoBarText: 'FLASH SALE LIVE: Up to 35% OFF on Smart Gadgets + Free Inside-City Delivery Over ৳2,500!',
  supportEmail: 'sopnilprodhan13@gmail.com',
  contactPhone: '+880 1700-000000',
  whatsappCountryCode: '880',
  whatsappNumber: '+880 1700-000000',
  whatsappDefaultMessage: 'Hello STORE BD ONLINE! I need assistance with a product or order.',
  whatsappSupportStatus: 'Online (9:00 AM – 11:00 PM)',
  enableFloatingWhatsapp: true,
  facebookPageName: 'STORE BD ONLINE Official',
  facebookUrl: 'https://facebook.com/storebdonline',
  facebookMessengerUrl: 'https://m.me/storebdonline',
  enableFacebookButton: true,
  address: 'Level 4, Gulshan Avenue, Dhaka-1212, Bangladesh',
  copyrightText: 'STORE BD ONLINE. All Rights Reserved.',
  seoTitle: 'STORE BD ONLINE | Shop Smart • Save More',
  seoDescription:
    'STORE BD ONLINE — Shop Smart • Save More. Trusted Bangladesh e-commerce destination for smart gadgets, audio gear, smart home tech, gaming accessories, and daily essentials.',
};

export interface LogoValidationResult {
  valid: boolean;
  error?: string;
}

/**
 * Validates a selected logo file for type (PNG, JPG/JPEG, WebP) and size (<= 5MB).
 */
export function validateLogoFile(file: {
  name: string;
  type: string;
  size: number;
} | null | undefined): LogoValidationResult {
  if (!file) {
    return { valid: false, error: 'Please select an image file to upload.' };
  }

  const mime = String(file.type || '').toLowerCase();
  const extMatch = /\.(png|jpe?g|webp)$/i.test(String(file.name || ''));

  if (!ALLOWED_LOGO_MIME_TYPES.includes(mime as typeof ALLOWED_LOGO_MIME_TYPES[number]) && !extMatch) {
    return {
      valid: false,
      error: 'Unsupported file format. Please upload a PNG, JPG/JPEG, or WebP image.',
    };
  }

  if (typeof file.size !== 'number' || file.size <= 0) {
    return { valid: false, error: 'Selected image file is empty.' };
  }

  if (file.size > MAX_LOGO_FILE_SIZE_BYTES) {
    return {
      valid: false,
      error: 'Logo file size must not exceed 5 MB.',
    };
  }

  return { valid: true };
}

/**
 * Verifies whether the current authenticated user is authorized to modify store branding.
 */
export function canUserModifyBranding(user: {
  email?: string | null;
  emailVerified?: boolean;
} | null | undefined): boolean {
  if (!user || !user.email) return false;
  return (
    user.email.trim().toLowerCase() === ADMIN_OWNER_EMAIL.toLowerCase() &&
    user.emailVerified === true
  );
}

/**
 * Builds a valid WhatsApp `https://wa.me/` deep link using country code, phone number, and message.
 */
export function buildWhatsAppLink(
  rawNumber: string,
  countryCode = '880',
  message = ''
): string {
  let digits = String(rawNumber || '').replace(/[^0-9]/g, '');
  const cleanCountry = String(countryCode || '880').replace(/[^0-9]/g, '') || '880';

  if (digits.startsWith('0') && digits.length === 11) {
    digits = cleanCountry + digits.slice(1);
  } else if (digits.length === 10 && !digits.startsWith(cleanCountry)) {
    digits = cleanCountry + digits;
  }

  if (!digits) {
    digits = '8801700000000';
  }

  const encoded = encodeURIComponent(message || DEFAULT_BRANDING_SETTINGS.whatsappDefaultMessage);
  return `https://wa.me/${digits}?text=${encoded}`;
}
