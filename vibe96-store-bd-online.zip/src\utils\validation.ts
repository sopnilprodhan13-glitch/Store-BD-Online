/**
 * Store BD Online — Core Validation, Sanitization & E-Commerce Calculation Utilities
 * Used by both frontend modules, backend Express routes, and automated tests.
 */

export const ADMIN_OWNER_EMAIL = 'sopnilprodhan13@gmail.com';

export const BD_DIVISIONS: Record<string, string[]> = {
  Dhaka: ['Dhaka', 'Gazipur', 'Narayanganj', 'Tangail', 'Faridpur', 'Manikganj', 'Munshiganj', 'Narsingdi'],
  Chattogram: ['Chattogram', "Cox's Bazar", 'Cumilla', 'Feni', 'Noakhali', 'Brahmanbaria', 'Chandpur'],
  Rajshahi: ['Rajshahi', 'Bogura', 'Pabna', 'Sirajganj', 'Natore', 'Naogaon', 'Chapainawabganj'],
  Khulna: ['Khulna', 'Jashore', 'Kushtia', 'Satkhira', 'Bagerhat', 'Jhenaidah'],
  Sylhet: ['Sylhet', 'Moulvibazar', 'Habiganj', 'Sunamganj'],
  Barishal: ['Barishal', 'Patuakhali', 'Bhola', 'Pirojpur', 'Jhalokati'],
  Rangpur: ['Rangpur', 'Dinajpur', 'Kurigram', 'Gaibandha', 'Nilphamari', 'Thakurgaon'],
  Mymensingh: ['Mymensingh', 'Jamalpur', 'Netrokona', 'Sherpur'],
};

/**
 * Validates standard email format (RFC 5322 practical subset, max 254 chars).
 */
export function isValidEmail(email: string): boolean {
  if (typeof email !== 'string') return false;
  const trimmed = email.trim();
  if (trimmed.length < 3 || trimmed.length > 254) return false;
  const regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+$/;
  return regex.test(trimmed);
}

/**
 * Validates Bangladeshi mobile number:
 * Supports 01[3-9]XXXXXXXX, +8801[3-9]XXXXXXXX, or 8801[3-9]XXXXXXXX.
 */
export function isValidBangladeshPhone(phone: string): boolean {
  if (typeof phone !== 'string') return false;
  const cleaned = phone.replace(/[\s\-()]/g, '');
  return /^(?:\+?880|0)1[3-9]\d{8}$/.test(cleaned);
}

/**
 * Normalizes a Bangladeshi phone number to 11-digit local format (01XXXXXXXXX).
 */
export function normalizeBangladeshPhone(phone: string): string {
  const digits = String(phone || '').replace(/[^0-9]/g, '');
  if (digits.startsWith('8801') && digits.length === 13) {
    return '0' + digits.slice(3);
  }
  return digits;
}

/**
 * Validates customer registration inputs before calling Firebase Authentication.
 */
export interface RegistrationValidationResult {
  valid: boolean;
  error?: string;
}

export function validateRegistrationInput(input: {
  name: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
}): RegistrationValidationResult {
  const name = String(input.name || '').trim();
  const email = String(input.email || '').trim();
  const phone = String(input.phone || '').trim();
  const password = String(input.password || '');
  const confirmPassword = String(input.confirmPassword || '');

  if (name.length < 2 || name.length > 120) {
    return { valid: false, error: 'Full Name must be between 2 and 120 characters.' };
  }
  if (!isValidEmail(email)) {
    return { valid: false, error: 'Please enter a valid email address.' };
  }
  if (!isValidBangladeshPhone(phone)) {
    return {
      valid: false,
      error: 'Please enter a valid 11-digit Bangladeshi mobile number (e.g. 017XXXXXXXX).',
    };
  }
  if (password.length < 6 || password.length > 128) {
    return { valid: false, error: 'Password must be at least 6 characters long.' };
  }
  if (password !== confirmPassword) {
    return { valid: false, error: 'Passwords do not match. Please confirm your password.' };
  }
  return { valid: true };
}

/**
 * Validates a 6-digit numeric OTP code string.
 */
export function isValidSixDigitOtp(otp: string): boolean {
  if (typeof otp !== 'string') return false;
  return /^\d{6}$/.test(otp.trim());
}

/**
 * Generates URL-safe product or category slug.
 */
export function toSlug(text: string): string {
  return String(text || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 180);
}

/**
 * Escapes HTML special characters to prevent XSS.
 */
export function escapeHtml(str: unknown): string {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Formats BDT price with symbol (৳).
 */
export function formatBdtPrice(amount: number, currencySymbol = '৳'): string {
  const num = Number(amount) || 0;
  return `${currencySymbol}${Math.round(num).toLocaleString('en-BD')}`;
}
