# Database Schema & Firestore Architecture (`DATABASE_SCHEMA.md`)

**Firebase Project ID:** `gen-lang-client-0128050017`  
**Firestore Database ID:** `ai-studio-2a331384-50d8-42fd-9a43-f88f719935a8`  
**Storage Bucket:** `gen-lang-client-0128050017.firebasestorage.app`

---

## Collections Overview

### 1. `/settings/store` (`Settings`)
Stores global store branding, logo URLs, colors, SEO metadata, social links, payment numbers, and delivery fees.
- **Read**: Public (`allow get, list: if true`)
- **Write**: Owner Admin only (`sopnilprodhan13@gmail.com` with `email_verified == true`)
- **Key Fields**:
  - `siteName` (`string`), `tagline` (`string`), `logoUrl` (`string`), `faviconUrl` (`string`)
  - `primaryColor`, `secondaryColor`, `buttonColor`, `headerBgColor`, `footerBgColor` (`string`)
  - `seoTitle` (`string`), `seoDescription` (`string`), `copyrightText` (`string`), `footerAbout` (`string`)
  - `supportEmail`, `contactPhone`, `whatsappCountryCode`, `whatsappNumber`, `whatsappDefaultMessage`, `whatsappSupportStatus`, `enableFloatingWhatsapp`
  - `facebookPageName`, `facebookUrl`, `facebookMessengerUrl`, `enableFacebookButton`
  - `bkashNumber`, `nagadNumber`, `paymentAccountType`, `paymentInstructions`, `enableCod`, `enableBkash`, `enableNagad`
  - `insideDhakaFee`, `outsideDhakaFee`, `freeDeliveryThreshold`, `estimatedDeliveryMessage`, `promoBarText`

### 2. `/products/{productId}` (`Product`)
- **Read**: Public
- **Write**: Owner Admin only (validated by `isValidProduct()`)
- **Key Fields**: `id`, `name`, `slug`, `category`, `brand`, `sku`, `regularPrice`, `discountPrice`, `stock`, `rating`, `reviewCount`, `featured`, `trending`, `bestseller`, `active`, `images` (`string[]`), `shortDescription`, `description`, `specs`, `createdAt`, `updatedAt`.

### 3. `/categories/{categoryId}` (`Category`)
- **Read**: Public
- **Write**: Owner Admin only (`isValidCategory()`)
- **Key Fields**: `id`, `name`, `slug`, `icon`, `description`, `featured`, `order`, `active`.

### 4. `/banners/{bannerId}` (`Banner`)
- **Read**: Public
- **Write**: Owner Admin only (`isValidBanner()`)
- **Key Fields**: `id`, `badge`, `title`, `highlight`, `subtitle`, `ctaText`, `ctaSecondaryText`, `categoryLink`, `imageUrl`, `bgGradient`, `order`, `active`.

### 5. `/coupons/{couponId}` (`Coupon`)
- **Read**: Public
- **Write**: Owner Admin only (`isValidCoupon()`)
- **Key Fields**: `id`, `code`, `type` (`'percent' | 'fixed'`), `value`, `minOrder`, `maxDiscount`, `usageLimit`, `usedCount`, `active`, `expiresAt`.

### 6. `/users/{userId}` (`UserProfile`)
- **Read**: Authenticated document owner (`request.auth.uid == userId`) or Owner Admin.
- **Create / Update**: Authenticated document owner (cannot escalate role/status) or Owner Admin.
- **Key Fields**: `uid`, `name`, `email`, `phone`, `division`, `district`, `upazila`, `address`, `status` (`'active' | 'blocked'`), `wishlist` (`string[]`), `createdAt`, `updatedAt`.

### 7. `/orders/{orderId}` (`Order`)
- **Create**: Public/Customer checkout with strict `isValidOrderCreate()` validation (`orderStatus == 'Order Placed'`, manual payments must start as `'Pending Verification'`).
- **Read**: Document owner (`resource.data.userId == request.auth.uid`) or Owner Admin.
- **Update**: Owner Admin (full status & payment verification) or Customer (cancel own order while still in `'Order Placed'` state).

### 8. `/orderTracking/{orderId}` (`OrderTracking`)
- **Read**: Public (`get` only by exact Order ID — `list` is disabled to prevent enumeration).
- **Create / Update**: Created alongside `/orders/{orderId}` with sanitized tracking summary fields (`orderNumber`, `phoneLast4`, `orderStatus`, `paymentMethod`, `paymentStatus`, `grandTotal`, `itemsSummary`).

### 9. `/reviews/{reviewId}` (`Review`)
- **Read**: Public
- **Create**: Authenticated customers (`request.resource.data.userId == request.auth.uid`, rating `1..5`)
- **Update / Delete**: Owner Admin only

### 10. `/notifications/{notificationId}` (`Notification`)
- **Read**: Public store announcements or user-targeted notifications
- **Write**: Owner Admin only

### 11. `/passwordResetChallenges/{challengeId}` (`PasswordResetChallenge`)
- **Read / Write**: `allow read, write: if false;` for all client SDKs. Accessed exclusively by the backend server / Cloud Functions using Admin credentials.
- **Key Fields**: `emailHash`, `codeHmac`, `expiresAt`, `resendAvailableAt`, `attempts`, `maxAttempts` (`5`), `verified`, `used`, `resetTokenHmac`, `ipHash`, `createdAt`.
