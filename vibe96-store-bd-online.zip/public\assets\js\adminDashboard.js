import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword,
  updateProfile,
  signOut
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  writeBatch,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js';


// =========================================================================
// 14. ADMIN DASHBOARD (Restricted strictly to sopnilprodhan13@gmail.com)
// =========================================================================
function validateAdminImageFile(file) {
  if (!file) return { valid: false, error: 'Please select an image file.' };
  const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: 'Unsupported format. Allowed formats: PNG, JPG, JPEG, WebP.' };
  }
  if (file.size > 5 * 1024 * 1024) {
    return { valid: false, error: 'File size exceeds 5MB limit. Please choose an image under 5MB.' };
  }
  return { valid: true };
}

async function uploadImageAsset(file, folder = 'products') {
  if (!file) return '';
  const check = validateAdminImageFile(file);
  if (!check.valid) {
    showToast(check.error);
    throw new Error(check.error);
  }
  try {
    const path = `${folder}/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '')}`;
    const sRef = storageRef(storage, path);
    await uploadBytes(sRef, file);
    return await getDownloadURL(sRef);
  } catch (err) {
    // Fallback to resized DataURL if Storage bucket rules are not yet initialized
    return await new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || '').slice(0, 950));
      reader.onerror = () => resolve('');
      reader.readAsDataURL(file);
    });
  }
}

function renderAdminView() {
  const container = document.getElementById('adminDashboardContainer');
  if (!container) return;

  const logoSrc = state.settings.logoUrl && state.settings.logoUrl !== DEFAULT_SETTINGS.logoUrl
    ? state.settings.logoUrl
    : (state.transparentLogoDataUrl || DEFAULT_SETTINGS.logoUrl);

  if (!state.currentUser || !state.isAdmin) {
    container.innerHTML = `
      <div style="max-width:520px;margin:28px auto;background:var(--bg-white);padding:32px;border-radius:var(--radius-lg);border:1px solid var(--border-light);text-align:center;">
        <div class="brand-logo-wrap" style="margin:0 auto 12px;width:58px;height:58px;">
          <img src="${logoSrc}" alt="Store BD Online" class="brand-logo-img" />
        </div>
        <h1 class="section-title" style="margin-bottom:6px;color:var(--brand-red);">Access Denied — Administrator Only</h1>
        <p style="font-size:13.5px;color:var(--text-secondary);margin-bottom:18px;">
          This private administration portal is restricted exclusively to the verified store owner (<strong>${ADMIN_EMAIL}</strong>) via Firebase Authentication.
        </p>
        ${state.currentUser ? `
          <div style="padding:12px;border-radius:var(--radius-sm);background:#FEF2F2;color:#991B1B;font-size:13px;font-weight:700;margin-bottom:14px;">
            Access Denied — Administrator Only (${escapeHtml(state.currentUser.email)} is a standard customer account).
          </div>
          <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
            <button type="button" class="btn btn-outline" data-nav="home">← Return to Storefront</button>
            <button type="button" class="btn btn-red" id="adminSwitchOwnerBtn">Sign In as Admin (${ADMIN_EMAIL})</button>
          </div>
        ` : `
          <div style="display:flex;flex-direction:column;gap:10px;">
            <button type="button" class="btn btn-red" id="adminSignInBtn" style="width:100%;height:44px;">Sign In as Admin (${ADMIN_EMAIL})</button>
            <button type="button" class="btn btn-outline" data-nav="home" style="width:100%;height:42px;">← Return to Storefront</button>
          </div>
        `}
      </div>
    `;
    document.getElementById('adminSwitchOwnerBtn')?.addEventListener('click', () => openAuthModal('login', ADMIN_EMAIL));
    document.getElementById('adminSignInBtn')?.addEventListener('click', () => openAuthModal('login', ADMIN_EMAIL));
    return;
  }

  const tabs = [
    { id: 'overview', label: '📊 Dashboard Overview' }, { id: 'settings', label: '🎨 Website Branding & Customization' },
    { id: 'products', label: '📦 Product Management' }, { id: 'categories', label: '🗂️ Category Management' },
    { id: 'orders', label: '🧾 Order Management' }, { id: 'customers', label: '👥 Customer Management' },
    { id: 'banners', label: '🖼️ Banner Management' }, { id: 'coupons', label: '🎟️ Coupon Management' },
    { id: 'reviews', label: '⭐ Review Moderation' }, { id: 'reports', label: '📈 Reports & CSV Export' }
  ];

  container.innerHTML = `
    <div class="admin-shell">
      <aside class="admin-sidebar">
        <div style="display:flex;align-items:center;gap:10px;padding-bottom:14px;margin-bottom:14px;border-bottom:1px solid rgba(255,255,255,0.12);">
          <div class="brand-logo-wrap" style="width:40px;height:40px;">
            <img src="${logoSrc}" alt="Admin" class="brand-logo-img" />
          </div>
          <div>
            <div style="font-size:14px;font-weight:800;color:#FFF;">OWNER ADMIN</div>
            <div style="font-size:11px;color:var(--brand-yellow);">${escapeHtml(state.currentUser.email)}</div>
          </div>
        </div>
        ${tabs.map(t => `
          <button type="button" class="admin-nav-btn ${state.adminTab === t.id ? 'active' : ''}" data-admin-tab="${t.id}">
            ${t.label}
          </button>
        `).join('')}
        <hr style="border:none;border-top:1px solid rgba(255,255,255,0.12);margin:10px 0;" />
        <button type="button" class="admin-nav-btn" id="adminSyncSeedBtn" style="color:var(--brand-yellow);">🔄 Sync Default Catalog</button>
        <button type="button" class="admin-nav-btn" data-nav="home">← View Storefront</button>
      </aside>

      <div id="adminMainPanel"></div>
    </div>
  `;

  container.querySelectorAll('[data-admin-tab]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.adminTab = btn.getAttribute('data-admin-tab');
      renderAdminView();
    });
  });

  document.getElementById('adminSyncSeedBtn')?.addEventListener('click', () => seedInitialDatabaseIfEmpty());

  const mainPanel = document.getElementById('adminMainPanel');
  if (state.adminTab === 'overview') renderAdminOverview(mainPanel);
  else if (state.adminTab === 'products') renderAdminProducts(mainPanel);
  else if (state.adminTab === 'categories') renderAdminCategories(mainPanel);
  else if (state.adminTab === 'orders') renderAdminOrders(mainPanel);
  else if (state.adminTab === 'customers') renderAdminCustomers(mainPanel);
  else if (state.adminTab === 'banners') renderAdminBanners(mainPanel);
  else if (state.adminTab === 'coupons') renderAdminCoupons(mainPanel);
  else if (state.adminTab === 'reviews') renderAdminReviews(mainPanel);
  else if (state.adminTab === 'settings') renderAdminSettings(mainPanel);
  else if (state.adminTab === 'reports') renderAdminReports(mainPanel);
}

function renderAdminOverview(panel) {
  const validOrders = state.orders.filter(o => o.orderStatus !== 'Cancelled');
  const totalSales = validOrders.reduce((s, o) => s + (Number(o.grandTotal) || 0), 0);
  const pendingOrders = state.orders.filter(o => ['Order Placed', 'Order Confirmed', 'Processing'].includes(o.orderStatus)).length;
  const completedOrders = state.orders.filter(o => o.orderStatus === 'Delivered').length;
  const cancelledOrders = state.orders.filter(o => o.orderStatus === 'Cancelled').length;
  const lowStockProducts = state.products.filter(p => (p.stock || 0) <= 10);

  panel.innerHTML = `
    <h1 class="section-title" style="margin-bottom:14px;">Admin Dashboard Overview</h1>
    <div class="stat-grid">
      <div class="stat-card"><div class="stat-label">Total Sales</div><div class="stat-value" style="color:var(--brand-red);">${formatPrice(totalSales)}</div></div>
      <div class="stat-card"><div class="stat-label">Total Orders</div><div class="stat-value">${state.orders.length}</div></div>
      <div class="stat-card"><div class="stat-label">Total Products</div><div class="stat-value">${state.products.length}</div></div>
      <div class="stat-card"><div class="stat-label">Total Customers</div><div class="stat-value">${state.customers.length}</div></div>
      <div class="stat-card"><div class="stat-label">Pending Orders</div><div class="stat-value" style="color:var(--warning);">${pendingOrders}</div></div>
      <div class="stat-card"><div class="stat-label">Completed Orders</div><div class="stat-value" style="color:var(--success);">${completedOrders}</div></div>
      <div class="stat-card"><div class="stat-label">Cancelled Orders</div><div class="stat-value" style="color:var(--danger);">${cancelledOrders}</div></div>
      <div class="stat-card"><div class="stat-label">Low Stock Items (≤10)</div><div class="stat-value">${lowStockProducts.length}</div></div>
    </div>

    <!-- Category Revenue / Stock Bar Chart -->
    <div style="background:var(--bg-white);padding:18px;border-radius:var(--radius-md);border:1px solid var(--border-light);margin-bottom:20px;">
      <h3 style="font-size:15px;font-weight:800;margin-bottom:12px;">Catalog Stock & Category Distribution</h3>
      <div style="display:flex;flex-direction:column;gap:10px;">
        ${state.categories.map(cat => {
          const catProds = state.products.filter(p => p.category === cat.name);
          const stockSum = catProds.reduce((s, p) => s + (p.stock || 0), 0);
          const pct = Math.min(100, Math.max(8, Math.round((stockSum / 150) * 100)));
          return `
            <div>
              <div style="display:flex;justify-content:space-between;font-size:12.5px;font-weight:600;margin-bottom:4px;">
                <span>${escapeHtml(cat.name)} (${catProds.length} products)</span>
                <span class="tabular-nums">${stockSum} units in stock</span>
              </div>
              <div style="height:10px;background:var(--bg-light);border-radius:999px;overflow:hidden;">
                <div style="width:${pct}%;height:100%;background:linear-gradient(90deg,var(--brand-red),var(--brand-yellow));"></div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    </div>

    <div class="data-table-wrap">
      <div style="padding:14px 16px;border-bottom:1px solid var(--border-light);font-weight:800;font-size:15px;">Recent Orders</div>
      <table class="data-table">
        <thead>
          <tr>
            <th>Order #</th>
            <th>Customer</th>
            <th>Total</th>
            <th>Payment</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${state.orders.slice(0, 6).map(o => `
            <tr>
              <td><strong>${escapeHtml(o.orderNumber)}</strong></td>
              <td>${escapeHtml(o.customerName)} (${escapeHtml(o.customerPhone)})</td>
              <td class="tabular-nums">${formatPrice(o.grandTotal)}</td>
              <td>${escapeHtml(o.paymentMethod.toUpperCase())} · ${escapeHtml(o.paymentStatus)}</td>
              <td><strong>${escapeHtml(o.orderStatus)}</strong></td>
            </tr>
          `).join('') || `<tr><td colspan="5" style="text-align:center;">No orders recorded yet.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function renderAdminProducts(panel) {
  panel.innerHTML = `
    <div class="section-head">
      <h2 class="section-title">Product Management (${state.products.length})</h2>
      <button type="button" class="btn btn-red" id="adminAddProductBtn">+ Add New Product</button>
    </div>
    <div class="data-table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Image</th>
            <th>Name & SKU</th>
            <th>Category</th>
            <th>Regular / Discount</th>
            <th>Stock</th>
            <th>Badges</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${state.products.map(p => `
            <tr>
              <td><img src="${escapeHtml(p.images?.[0] || '')}" alt="" style="width:44px;height:44px;border-radius:6px;object-fit:cover;" referrerpolicy="no-referrer" /></td>
              <td>
                <div style="font-weight:700;">${escapeHtml(p.name)}</div>
                <div style="font-size:11.5px;color:var(--text-secondary);">SKU: ${escapeHtml(p.sku)}</div>
              </td>
              <td>${escapeHtml(p.category)}</td>
              <td class="tabular-nums">${formatPrice(p.regularPrice)} / <strong>${formatPrice(p.discountPrice)}</strong></td>
              <td class="tabular-nums" style="color:${p.stock <= 10 ? 'var(--danger)' : 'inherit'};font-weight:700;">${p.stock}</td>
              <td style="font-size:11px;">
                ${p.bestseller ? '🔥 Bestseller ' : ''}
                ${p.trending ? '⚡ Trending ' : ''}
              </td>
              <td>${p.active !== false ? '✅ Active' : '⏸️ Inactive'}</td>
              <td>
                <div style="display:flex;gap:6px;">
                  <button type="button" class="btn btn-outline" data-edit-product="${escapeHtml(p.id)}" style="padding:5px 10px;font-size:12px;">Edit</button>
                  <button type="button" class="btn btn-outline" data-del-product="${escapeHtml(p.id)}" style="padding:5px 10px;font-size:12px;color:var(--danger);">Delete</button>
                </div>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;

  document.getElementById('adminAddProductBtn')?.addEventListener('click', () => openProductFormModal(null));
  panel.querySelectorAll('[data-edit-product]').forEach(btn => {
    btn.addEventListener('click', () => {
      const prod = state.products.find(p => p.id === btn.getAttribute('data-edit-product'));
      if (prod) openProductFormModal(prod);
    });
  });
  panel.querySelectorAll('[data-del-product]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const pid = btn.getAttribute('data-del-product');
      try {
        await deleteDoc(doc(db, 'products', pid));
        state.products = state.products.filter(p => p.id !== pid);
        renderAllProductGrids();
        renderAdminView();
        showToast('Product deleted.');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `products/${pid}`);
      }
    });
  });
}

function openProductFormModal(existingProd = null) {
  const p = existingProd || {
    id: `prod_${Date.now()}`,
    name: '',
    slug: '',
    shortDescription: '',
    description: '',
    category: state.categories[0]?.name || 'Gadgets',
    brand: 'StoreBD',
    images: ['/assets/images/prod_charging_station_1794737029320.jpg'],
    regularPrice: 2500,
    discountPrice: 1990,
    stock: 25,
    sku: `SBD-${Math.floor(100 + Math.random() * 899)}`,
    rating: 4.8,
    reviewCount: 15,
    featured: true,
    trending: true,
    bestseller: false,
    active: true,
    specs: ''
  };

  openDynamicModal(existingProd ? `Edit Product: ${p.name}` : 'Add New Product', `
    <form id="adminProductForm">
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Product Name *</label>
          <input type="text" id="pfName" class="form-control" required maxlength="190" value="${escapeHtml(p.name)}" />
        </div>
        <div class="form-group">
          <label class="form-label">Category *</label>
          <select id="pfCategory" class="form-control">
            ${state.categories.map(c => `<option value="${escapeHtml(c.name)}" ${c.name === p.category ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Regular Price (৳) *</label>
          <input type="number" id="pfRegPrice" class="form-control" required min="1" value="${p.regularPrice}" />
        </div>
        <div class="form-group">
          <label class="form-label">Discount Price (৳) *</label>
          <input type="number" id="pfDiscPrice" class="form-control" required min="1" value="${p.discountPrice}" />
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Stock Quantity *</label>
          <input type="number" id="pfStock" class="form-control" required min="0" value="${p.stock}" />
        </div>
        <div class="form-group">
          <label class="form-label">SKU *</label>
          <input type="text" id="pfSku" class="form-control" required maxlength="70" value="${escapeHtml(p.sku)}" />
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Image URLs (comma-separated) or Upload File</label>
        <input type="text" id="pfImages" class="form-control" value="${escapeHtml((p.images || []).join(', '))}" style="margin-bottom:6px;" />
        <input type="file" id="pfImageFile" accept="image/*" class="form-control" />
      </div>
      <div class="form-group">
        <label class="form-label">Short Description</label>
        <input type="text" id="pfShortDesc" class="form-control" maxlength="480" value="${escapeHtml(p.shortDescription || '')}" />
      </div>
      <div class="form-group">
        <label class="form-label">Full Description</label>
        <textarea id="pfDesc" class="form-control" rows="3" maxlength="3800">${escapeHtml(p.description || '')}</textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Specifications</label>
        <input type="text" id="pfSpecs" class="form-control" maxlength="1800" value="${escapeHtml(p.specs || '')}" />
      </div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:14px;font-size:13px;font-weight:600;">
        <label><input type="checkbox" id="pfBestseller" ${p.bestseller ? 'checked' : ''} /> Bestseller Badge</label>
        <label><input type="checkbox" id="pfTrending" ${p.trending ? 'checked' : ''} /> Trending Badge</label>
        <label><input type="checkbox" id="pfFeatured" ${p.featured ? 'checked' : ''} /> Featured</label>
        <label><input type="checkbox" id="pfActive" ${p.active !== false ? 'checked' : ''} /> Active</label>
      </div>
      <button type="submit" class="btn btn-red" style="width:100%;">Save Product</button>
    </form>
  `);

  document.getElementById('adminProductForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fileInput = document.getElementById('pfImageFile');
    let imgList = document.getElementById('pfImages').value
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    if (fileInput?.files?.[0]) {
      const uploadedUrl = await uploadImageAsset(fileInput.files[0], 'products');
      if (uploadedUrl) imgList.unshift(uploadedUrl);
    }
    if (imgList.length === 0) {
      imgList = ['/assets/images/prod_charging_station_1794737029320.jpg'];
    }

    const name = document.getElementById('pfName').value.trim().slice(0, 190);
    const regPrice = Math.max(0, Number(document.getElementById('pfRegPrice').value) || 0);
    const discPrice = Math.min(regPrice, Math.max(0, Number(document.getElementById('pfDiscPrice').value) || regPrice));

    const docData = {
      id: p.id,
      name,
      slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 200) || p.id,
      shortDescription: document.getElementById('pfShortDesc').value.trim().slice(0, 480),
      description: document.getElementById('pfDesc').value.trim().slice(0, 3800),
      category: document.getElementById('pfCategory').value.slice(0, 95),
      brand: (p.brand || 'StoreBD').slice(0, 95),
      images: imgList.slice(0, 10),
      regularPrice: regPrice,
      discountPrice: discPrice,
      stock: Math.max(0, Number(document.getElementById('pfStock').value) || 0),
      sku: document.getElementById('pfSku').value.trim().slice(0, 75),
      rating: Number(p.rating || 4.8),
      reviewCount: Number(p.reviewCount || 12),
      bestseller: document.getElementById('pfBestseller').checked,
      trending: document.getElementById('pfTrending').checked,
      featured: document.getElementById('pfFeatured').checked,
      active: document.getElementById('pfActive').checked,
      specs: document.getElementById('pfSpecs').value.trim().slice(0, 1800),
      createdAt: p.createdAt || serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    try {
      await setDoc(doc(db, 'products', p.id), docData);
      closeDynamicModal();
      showToast('Product saved to Firestore!');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `products/${p.id}`);
    }
  });
}

function renderAdminCategories(panel) {
  panel.innerHTML = `
    <div class="section-head">
      <h2 class="section-title">Category Management (${state.categories.length})</h2>
      <button type="button" class="btn btn-red" id="adminAddCatBtn">+ Add Category</button>
    </div>
    <div class="data-table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Order</th><th>Icon / Image</th><th>Name</th><th>Slug</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
          ${state.categories.map(c => `
            <tr>
              <td class="tabular-nums">${c.order}</td>
              <td>
                ${c.image
                  ? `<img src="${escapeHtml(c.image)}" alt="" style="width:32px;height:32px;border-radius:6px;object-fit:contain;" referrerpolicy="no-referrer" />`
                  : `<code>${escapeHtml(c.icon)}</code>`
                }
              </td>
              <td><strong>${escapeHtml(c.name)}</strong></td>
              <td><code>${escapeHtml(c.slug || '')}</code></td>
              <td>${c.active !== false ? '✅ Active' : '⏸️ Inactive'}</td>
              <td>
                <div style="display:flex;gap:6px;">
                  <button type="button" class="btn btn-outline" data-edit-cat="${escapeHtml(c.id)}" style="padding:4px 10px;font-size:12px;">Edit</button>
                  <button type="button" class="btn btn-outline" data-del-cat="${escapeHtml(c.id)}" style="padding:4px 10px;font-size:12px;color:var(--danger);">Delete</button>
                </div>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;

  const openCatModal = (existingCat = null) => {
    const c = existingCat || {
      id: `cat_${Date.now()}`,
      name: '',
      icon: 'watch',
      image: '',
      order: state.categories.length + 1,
      active: true
    };
    openDynamicModal(existingCat ? `Edit Category: ${c.name}` : 'Add Category', `
      <form id="addCatForm">
        <div class="form-group">
          <label class="form-label">Category Name *</label>
          <input type="text" id="catNameIn" class="form-control" required maxlength="90" value="${escapeHtml(c.name)}" placeholder="e.g. Smart Watches" />
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Lucide Icon Name *</label>
            <input type="text" id="catIconIn" class="form-control" required maxlength="60" value="${escapeHtml(c.icon || 'box')}" />
          </div>
          <div class="form-group">
            <label class="form-label">Display Order *</label>
            <input type="number" id="catOrderIn" class="form-control" required value="${c.order || 1}" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Category Image URL or Upload (Optional)</label>
          <input type="text" id="catImgIn" class="form-control" value="${escapeHtml(c.image || '')}" placeholder="https://... or upload below" style="margin-bottom:6px;" />
          <input type="file" id="catImgFile" accept="image/*" class="form-control" />
        </div>
        <div class="form-group">
          <label style="font-size:13px;font-weight:600;"><input type="checkbox" id="catActiveIn" ${c.active !== false ? 'checked' : ''} /> Category Active</label>
        </div>
        <button type="submit" class="btn btn-red" style="width:100%;">Save Category</button>
      </form>
    `);
    document.getElementById('addCatForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('catNameIn').value.trim().slice(0, 90);
      let imgUrl = document.getElementById('catImgIn').value.trim().slice(0, 950);
      const fileIn = document.getElementById('catImgFile');
      if (fileIn?.files?.[0]) {
        const uploaded = await uploadImageAsset(fileIn.files[0], 'products');
        if (uploaded) imgUrl = uploaded;
      }
      try {
        await setDoc(doc(db, 'categories', c.id), {
          id: c.id,
          name,
          slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
          icon: document.getElementById('catIconIn').value.trim().slice(0, 60) || 'box',
          image: imgUrl,
          order: Number(document.getElementById('catOrderIn').value) || 1,
          active: document.getElementById('catActiveIn').checked,
          createdAt: c.createdAt || serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        closeDynamicModal();
        showToast('Category saved!');
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `categories/${c.id}`);
      }
    });
  };

  document.getElementById('adminAddCatBtn')?.addEventListener('click', () => openCatModal(null));
  panel.querySelectorAll('[data-edit-cat]').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = state.categories.find(c => c.id === btn.getAttribute('data-edit-cat'));
      if (cat) openCatModal(cat);
    });
  });

  panel.querySelectorAll('[data-del-cat]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const cid = btn.getAttribute('data-del-cat');
      try {
        await deleteDoc(doc(db, 'categories', cid));
        showToast('Category removed.');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `categories/${cid}`);
      }
    });
  });
}

function renderAdminOrders(panel) {
  const searchQ = (state.adminOrderSearch || '').trim().toLowerCase();
  const filteredOrders = searchQ
    ? state.orders.filter(o =>
        (o.orderNumber || '').toLowerCase().includes(searchQ) ||
        (o.id || '').toLowerCase().includes(searchQ) ||
        (o.customerName || '').toLowerCase().includes(searchQ) ||
        (o.customerPhone || '').toLowerCase().includes(searchQ) ||
        (o.customerEmail || '').toLowerCase().includes(searchQ) ||
        (o.deliveryArea || '').toLowerCase().includes(searchQ) ||
        (o.fullAddress || '').toLowerCase().includes(searchQ) ||
        (o.upazila || '').toLowerCase().includes(searchQ) ||
        (o.district || '').toLowerCase().includes(searchQ) ||
        (o.instructions || '').toLowerCase().includes(searchQ) ||
        (o.paymentNumber || '').toLowerCase().includes(searchQ) ||
        (o.transactionId || '').toLowerCase().includes(searchQ)
      )
    : state.orders;

  panel.innerHTML = `
    <div class="section-head" style="flex-wrap:wrap;gap:12px;">
      <h2 class="section-title">Order & Customer Delivery Management (${filteredOrders.length})</h2>
      <input type="text" id="adminOrderSearchInput" class="form-control" style="max-width:320px;" placeholder="Search Order #, Customer, Phone, Area, TrxID..." value="${escapeHtml(state.adminOrderSearch || '')}" />
    </div>
    <div class="data-table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Order #</th>
            <th>Customer & Delivery Address</th>
            <th>Items & Total</th>
            <th>Payment & TrxID</th>
            <th>Order Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${filteredOrders.map(o => `
            <tr>
              <td>
                <strong style="color:var(--brand-black);">${escapeHtml(o.orderNumber)}</strong>
                <div style="font-size:11px;color:var(--text-secondary);">${escapeHtml(o.id)}</div>
              </td>
              <td>
                <div style="font-weight:700;font-size:13px;">${escapeHtml(o.customerName)}</div>
                <div style="font-size:12px;font-weight:600;"><a href="tel:${escapeHtml(o.customerPhone)}" style="color:var(--brand-red);">${escapeHtml(o.customerPhone)}</a></div>
                ${o.customerEmail ? `<div style="font-size:11px;color:var(--text-secondary);">✉️ ${escapeHtml(o.customerEmail)}</div>` : ''}
                <div style="font-size:11.5px;color:var(--text-secondary);margin-top:2px;">
                  📍 ${escapeHtml(o.deliveryArea ? o.deliveryArea + ', ' : '')}${escapeHtml(o.fullAddress || '')}
                </div>
                <div style="font-size:11px;color:var(--text-muted);">
                  ${escapeHtml(o.upazila ? o.upazila + ', ' : '')}${escapeHtml(o.district || '')}, ${escapeHtml(o.division || '')}
                </div>
                ${o.instructions ? `<div style="margin-top:3px;padding:2px 6px;border-radius:4px;background:#FFFBEB;border:1px solid #FDE68A;color:#92400E;font-size:11px;font-weight:600;">📝 Note: ${escapeHtml(o.instructions)}</div>` : ''}
              </td>
              <td>
                <div style="font-size:12px;max-width:220px;">${escapeHtml(o.itemsSummary)}</div>
                <div style="font-weight:800;color:var(--brand-red);" class="tabular-nums">${formatPrice(o.grandTotal)}</div>
              </td>
              <td>
                <div><strong class="badge" style="background:#0F172A;color:#fff;font-size:10.5px;">${escapeHtml(o.paymentMethod.toUpperCase())}</strong> <span style="font-size:11.5px;color:${o.paymentStatus === 'verified' ? 'var(--success)' : (o.paymentStatus === 'rejected' ? 'var(--danger)' : '#B45309')};font-weight:600;">(${escapeHtml(o.paymentStatus)})</span></div>
                ${o.paymentNumber ? `<div style="font-size:11.5px;margin-top:2px;">Sender: <strong>${escapeHtml(o.paymentNumber)}</strong></div>` : ''}
                ${o.transactionId ? `<div style="font-size:11.5px;">TrxID: <code>${escapeHtml(o.transactionId)}</code></div>` : ''}
                ${o.paymentStatus === 'pending_verification' ? `
                  <div style="display:flex;gap:4px;margin-top:4px;">
                    <button type="button" class="btn btn-outline" data-verify-pay="${escapeHtml(o.id)}" style="padding:3px 8px;font-size:11px;color:var(--success);border-color:var(--success);">✓ Verify</button>
                    <button type="button" class="btn btn-outline" data-reject-pay="${escapeHtml(o.id)}" style="padding:3px 8px;font-size:11px;color:var(--danger);border-color:var(--danger);">✕ Reject</button>
                  </div>
                ` : ''}
              </td>
              <td>
                <select class="form-control" data-order-status-select="${escapeHtml(o.id)}" style="padding:6px 8px;font-size:12px;min-width:145px;">
                  ${['Pending', 'Order Placed', 'Confirmed', 'Order Confirmed', 'Processing', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled', 'Returned', 'Refunded'].map(st => `
                    <option value="${st}" ${o.orderStatus === st ? 'selected' : ''}>${st}</option>
                  `).join('')}
                </select>
              </td>
              <td>
                <div style="display:flex;flex-direction:column;gap:5px;">
                  <button type="button" class="btn btn-red" data-view-order="${escapeHtml(o.id)}" style="padding:5px 8px;font-size:11.5px;width:100%;">👁️ View All</button>
                  <button type="button" class="btn btn-outline" data-print-invoice="${escapeHtml(o.id)}" style="padding:4px 8px;font-size:11.5px;width:100%;">🖨️ Invoice</button>
                </div>
              </td>
            </tr>
          `).join('') || `<tr><td colspan="6" style="text-align:center;">No orders found.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;

  document.getElementById('adminOrderSearchInput')?.addEventListener('input', (e) => {
    state.adminOrderSearch = e.target.value;
    renderAdminOrders(panel);
    const input = document.getElementById('adminOrderSearchInput');
    if (input) {
      input.focus();
      input.setSelectionRange(input.value.length, input.value.length);
    }
  });

  panel.querySelectorAll('[data-order-status-select]').forEach(sel => {
    sel.addEventListener('change', async () => {
      const oid = sel.getAttribute('data-order-status-select');
      const nextStatus = sel.value;
      const ord = state.orders.find(o => o.id === oid);
      if (ord) ord.orderStatus = nextStatus;

      fetch(`/api/orders/${encodeURIComponent(oid)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderStatus: nextStatus })
      }).catch(() => {});

      localStorage.setItem('sbd_local_orders', JSON.stringify(state.orders));

      try {
        const batch = writeBatch(db);
        batch.update(doc(db, 'orders', oid), { orderStatus: nextStatus, updatedAt: serverTimestamp() });
        batch.update(doc(db, 'orderTracking', oid), { orderStatus: nextStatus, updatedAt: serverTimestamp() });
        if (ord?.userId) {
          const nid = `notif_${Date.now()}`;
          batch.set(doc(db, 'notifications', nid), {
            id: nid,
            targetUserId: ord.userId,
            title: `Order ${ord.orderNumber}: ${nextStatus}`,
            message: `Your order ${ord.orderNumber} status has been updated to "${nextStatus}".`,
            type: 'order_status',
            orderId: oid,
            read: false,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
        }
        await batch.commit();
      } catch (err) {}
      showToast(`Order status updated to ${nextStatus}`);
    });
  });

  panel.querySelectorAll('[data-verify-pay]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const oid = btn.getAttribute('data-verify-pay');
      const ord = state.orders.find(o => o.id === oid);
      if (ord) {
        ord.paymentStatus = 'verified';
        ord.orderStatus = 'Order Confirmed';
      }

      fetch(`/api/orders/${encodeURIComponent(oid)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentStatus: 'verified', orderStatus: 'Order Confirmed' })
      }).catch(() => {});

      localStorage.setItem('sbd_local_orders', JSON.stringify(state.orders));

      try {
        const batch = writeBatch(db);
        batch.update(doc(db, 'orders', oid), { paymentStatus: 'verified', orderStatus: 'Order Confirmed', updatedAt: serverTimestamp() });
        batch.update(doc(db, 'orderTracking', oid), { paymentStatus: 'verified', orderStatus: 'Order Confirmed', updatedAt: serverTimestamp() });
        await batch.commit();
      } catch (err) {}
      showToast('Payment verified & order confirmed!');
      renderAdminOrders(panel);
    });
  });

  panel.querySelectorAll('[data-reject-pay]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const oid = btn.getAttribute('data-reject-pay');
      const ord = state.orders.find(o => o.id === oid);
      if (ord) ord.paymentStatus = 'rejected';

      fetch(`/api/orders/${encodeURIComponent(oid)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentStatus: 'rejected' })
      }).catch(() => {});

      localStorage.setItem('sbd_local_orders', JSON.stringify(state.orders));

      try {
        const batch = writeBatch(db);
        batch.update(doc(db, 'orders', oid), { paymentStatus: 'rejected', updatedAt: serverTimestamp() });
        batch.update(doc(db, 'orderTracking', oid), { paymentStatus: 'rejected', updatedAt: serverTimestamp() });
        await batch.commit();
      } catch (err) {}
      showToast('Payment marked as rejected.');
      renderAdminOrders(panel);
    });
  });

  panel.querySelectorAll('[data-view-order]').forEach(btn => {
    btn.addEventListener('click', () => {
      const ord = state.orders.find(o => o.id === btn.getAttribute('data-view-order'));
      if (!ord) return;
      const createdText = ord.createdAt?.toDate ? ord.createdAt.toDate().toLocaleString('en-BD') : (ord.createdAt ? new Date(ord.createdAt).toLocaleString('en-BD') : 'Just now');
      openDynamicModal(`Order #${escapeHtml(ord.orderNumber)} — Customer Details`, `
        <div style="display:flex;flex-direction:column;gap:12px;max-height:76vh;overflow-y:auto;padding-right:4px;">
          <div style="display:flex;justify-content:space-between;align-items:center;background:var(--bg-light);border:1px solid var(--border-light);border-radius:var(--radius-sm);padding:10px 14px;">
            <div>
              <div style="font-size:11px;color:var(--text-secondary);font-weight:700;">ORDER NUMBER</div>
              <div style="font-size:18px;font-weight:900;color:var(--brand-black);">${escapeHtml(ord.orderNumber)}</div>
              <div style="font-size:11px;color:var(--text-muted);">ID: <code>${escapeHtml(ord.id)}</code> • Placed: ${escapeHtml(createdText)}</div>
            </div>
            <div style="text-align:right;">
              <span class="badge" style="background:var(--brand-red);color:#fff;font-size:11.5px;padding:4px 8px;">${escapeHtml(ord.orderStatus || 'Pending')}</span>
              <div style="font-size:11.5px;margin-top:3px;font-weight:700;color:${ord.paymentStatus === 'verified' ? 'var(--success)' : (ord.paymentStatus === 'rejected' ? 'var(--danger)' : '#B45309')};">
                Payment: ${escapeHtml(ord.paymentStatus || '—')}
              </div>
            </div>
          </div>

          <div style="border:1px solid var(--border-light);border-radius:var(--radius-sm);padding:12px;background:#fff;">
            <h4 style="font-size:13px;font-weight:800;margin-bottom:8px;color:var(--brand-black);">👤 1. Customer Information</h4>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;font-size:12.5px;">
              <div><span style="color:var(--text-secondary);">Full Name:</span><br/><strong>${escapeHtml(ord.customerName || '—')}</strong></div>
              <div><span style="color:var(--text-secondary);">Mobile Number (BD):</span><br/><a href="tel:${escapeHtml(ord.customerPhone)}" style="color:var(--brand-red);font-weight:700;">${escapeHtml(ord.customerPhone || '—')}</a></div>
              <div><span style="color:var(--text-secondary);">Email Address:</span><br/><strong>${escapeHtml(ord.customerEmail || 'Not provided')}</strong></div>
              <div><span style="color:var(--text-secondary);">User ID:</span><br/><code style="font-size:10.5px;">${escapeHtml(ord.userId || '—')}</code></div>
            </div>
          </div>

          <div style="border:1px solid var(--border-light);border-radius:var(--radius-sm);padding:12px;background:#FAFAFA;">
            <h4 style="font-size:13px;font-weight:800;margin-bottom:8px;color:var(--brand-black);">📍 2. Delivery Information (Bangladesh)</h4>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;font-size:12.5px;margin-bottom:8px;">
              <div><span style="color:var(--text-secondary);">Division:</span><br/><strong>${escapeHtml(ord.division || '—')}</strong></div>
              <div><span style="color:var(--text-secondary);">District:</span><br/><strong>${escapeHtml(ord.district || '—')}</strong></div>
              <div><span style="color:var(--text-secondary);">Upazila / Thana:</span><br/><strong>${escapeHtml(ord.upazila || '—')}</strong></div>
              <div><span style="color:var(--text-secondary);">Delivery Area / Landmark:</span><br/><strong style="color:var(--brand-red);">${escapeHtml(ord.deliveryArea || '—')}</strong></div>
            </div>
            <div style="font-size:12.5px;margin-bottom:8px;">
              <span style="color:var(--text-secondary);font-weight:600;">Full Street Address:</span>
              <div style="margin-top:3px;padding:8px 10px;background:#fff;border:1px solid var(--border-light);border-radius:4px;font-weight:600;white-space:pre-wrap;">${escapeHtml(ord.fullAddress || '—')}</div>
            </div>
            <div style="font-size:12.5px;">
              <span style="color:var(--text-secondary);font-weight:600;">Additional Delivery Instructions:</span>
              <div style="margin-top:3px;padding:8px 10px;background:${ord.instructions ? '#FFFBEB' : '#fff'};border:1px solid ${ord.instructions ? '#FDE68A' : 'var(--border-light)'};border-radius:4px;color:${ord.instructions ? '#92400E' : 'var(--text-secondary)'};font-weight:${ord.instructions ? '700' : '400'};">
                ${ord.instructions ? escapeHtml(ord.instructions) : '<em>None specified by customer</em>'}
              </div>
            </div>
          </div>

          <div style="border:1px solid var(--border-light);border-radius:var(--radius-sm);padding:12px;background:#fff;">
            <h4 style="font-size:13px;font-weight:800;margin-bottom:8px;color:var(--brand-black);">💳 3. Payment Verification Details</h4>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;font-size:12.5px;">
              <div><span style="color:var(--text-secondary);">Payment Method:</span><br/><span class="badge" style="background:#0F172A;color:#fff;font-size:11px;">${escapeHtml((ord.paymentMethod || '').toUpperCase())}</span></div>
              <div><span style="color:var(--text-secondary);">Payment Status:</span><br/><strong style="color:${ord.paymentStatus === 'verified' ? 'var(--success)' : (ord.paymentStatus === 'rejected' ? 'var(--danger)' : '#B45309')};">${escapeHtml(ord.paymentStatus || '—')}</strong></div>
              <div><span style="color:var(--text-secondary);">Sender Mobile Number:</span><br/><strong>${escapeHtml(ord.paymentNumber || (ord.paymentMethod === 'cod' ? 'Cash on Delivery' : '—'))}</strong></div>
              <div><span style="color:var(--text-secondary);">Transaction ID (TrxID):</span><br/><code>${escapeHtml(ord.transactionId || (ord.paymentMethod === 'cod' ? 'COD (Pay on Delivery)' : '—'))}</code></div>
            </div>
          </div>

          <div style="border:1px solid var(--border-light);border-radius:var(--radius-sm);padding:12px;background:#fff;">
            <h4 style="font-size:13px;font-weight:800;margin-bottom:8px;color:var(--brand-black);">📦 4. Items Ordered & Financials</h4>
            <div style="padding:8px 10px;background:var(--bg-light);border-radius:4px;font-size:12.5px;line-height:1.6;margin-bottom:8px;">
              ${escapeHtml(ord.itemsSummary || '—')}
            </div>
            <div style="display:flex;justify-content:flex-end;">
              <div style="min-width:240px;font-size:12.5px;" class="tabular-nums">
                <div style="display:flex;justify-content:space-between;padding:2px 0;"><span>Subtotal (${ord.itemCount || 1} items):</span> <strong>${formatPrice(ord.subtotal)}</strong></div>
                ${ord.discount ? `<div style="display:flex;justify-content:space-between;padding:2px 0;color:var(--success);"><span>Coupon (${escapeHtml(ord.couponCode || 'DISCOUNT')}):</span> <strong>−${formatPrice(ord.discount)}</strong></div>` : ''}
                <div style="display:flex;justify-content:space-between;padding:2px 0;"><span>Delivery Fee:</span> <strong>${formatPrice(ord.deliveryFee)}</strong></div>
                <div style="display:flex;justify-content:space-between;padding:6px 0;border-top:2px solid var(--brand-black);font-size:15px;font-weight:900;color:var(--brand-red);"><span>Grand Total:</span> <span>${formatPrice(ord.grandTotal)}</span></div>
              </div>
            </div>
          </div>

          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-top:2px;">
            <a href="https://wa.me/88${escapeHtml(ord.customerPhone?.replace(/[^0-9]/g, ''))}" target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="color:#25D366;border-color:#25D366;font-weight:700;font-size:12px;">
              💬 WhatsApp Customer
            </a>
            <button type="button" class="btn btn-black" data-print-invoice="${escapeHtml(ord.id)}" style="font-size:12px;">🖨️ Print Invoice</button>
          </div>
        </div>
      `);
      document.querySelector('.dynamic-modal-overlay [data-print-invoice]')?.addEventListener('click', () => {
        printInvoiceForOrder(ord);
      });
    });
  });

  panel.querySelectorAll('[data-print-invoice]').forEach(btn => {
    btn.addEventListener('click', () => {
      const ord = state.orders.find(o => o.id === btn.getAttribute('data-print-invoice'));
      if (ord) printInvoiceForOrder(ord);
    });
  });
}

function printInvoiceForOrder(ord) {
  if (!ord) return;
  openDynamicModal(`Invoice — ${ord.orderNumber}`, `
    <div id="printableInvoiceArea" style="padding:16px;border:1px solid var(--border-light);border-radius:var(--radius-sm);font-size:13px;">
      <div style="display:flex;justify-content:space-between;border-bottom:2px solid var(--brand-black);padding-bottom:10px;margin-bottom:12px;">
        <div>
          <strong style="font-size:17px;">${escapeHtml(state.settings.siteName || 'STORE BD ONLINE')}</strong>
          <div>${escapeHtml(state.settings.tagline || 'Shop Smart • Save More')}</div>
          <div>WhatsApp: ${escapeHtml(state.settings.whatsappNumber)}</div>
        </div>
        <div style="text-align:right;">
          <div><strong>INVOICE: ${escapeHtml(ord.orderNumber)}</strong></div>
          <div>ID: ${escapeHtml(ord.id)}</div>
          <div>Status: ${escapeHtml(ord.orderStatus)}</div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
        <div>
          <strong>Bill To:</strong> ${escapeHtml(ord.customerName)}<br/>
          <strong>Phone:</strong> ${escapeHtml(ord.customerPhone)}<br/>
          ${ord.customerEmail ? `<strong>Email:</strong> ${escapeHtml(ord.customerEmail)}<br/>` : ''}
          <strong>Payment:</strong> ${escapeHtml((ord.paymentMethod || '').toUpperCase())} (${escapeHtml(ord.paymentStatus || '')})<br/>
          ${ord.paymentNumber ? `<strong>Sender Number:</strong> ${escapeHtml(ord.paymentNumber)}<br/>` : ''}
          ${ord.transactionId ? `<strong>TrxID:</strong> ${escapeHtml(ord.transactionId)}<br/>` : ''}
        </div>
        <div>
          <strong>Delivery Destination:</strong><br/>
          ${ord.deliveryArea ? `<strong>Area/Landmark:</strong> ${escapeHtml(ord.deliveryArea)}<br/>` : ''}
          <strong>Street Address:</strong> ${escapeHtml(ord.fullAddress || '')}<br/>
          <strong>Upazila / District:</strong> ${escapeHtml(ord.upazila || '')}, ${escapeHtml(ord.district || '')}, ${escapeHtml(ord.division || '')}<br/>
          ${ord.instructions ? `<strong>Instructions:</strong> ${escapeHtml(ord.instructions)}<br/>` : ''}
        </div>
      </div>
      <div style="padding:10px;background:var(--bg-light);margin-bottom:12px;">
        <strong>Order Items:</strong><br/>${escapeHtml(ord.itemsSummary)}
      </div>
      <div style="text-align:right;" class="tabular-nums">
        <div>Subtotal: ${formatPrice(ord.subtotal)}</div>
        <div>Discount: −${formatPrice(ord.discount)}</div>
        <div>Delivery Fee: ${formatPrice(ord.deliveryFee)}</div>
        <div style="font-size:16px;font-weight:800;color:var(--brand-red);">Grand Total: ${formatPrice(ord.grandTotal)}</div>
      </div>
    </div>
    <button type="button" class="btn btn-black" onclick="window.print()" style="width:100%;margin-top:14px;">🖨️ Print Invoice Now</button>
  `);
}

function renderAdminCustomers(panel) {
  panel.innerHTML = `
    <div class="section-head"><h2 class="section-title">Customer Management (${state.customers.length})</h2></div>
    <div class="data-table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Name</th><th>Email</th><th>Mobile</th><th>Location</th><th>Orders</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
          ${state.customers.map(c => {
            const custOrders = state.orders.filter(o => o.userId === c.uid);
            return `
              <tr>
                <td><strong>${escapeHtml(c.name)}</strong></td>
                <td>${escapeHtml(c.email)}</td>
                <td>${escapeHtml(c.phone || '—')}</td>
                <td>${escapeHtml(c.district || 'Dhaka')}, ${escapeHtml(c.division || 'Dhaka')}</td>
                <td class="tabular-nums"><strong>${custOrders.length}</strong></td>
                <td>${escapeHtml(c.status || 'active')}</td>
                <td>
                  <button type="button" class="btn btn-outline" data-view-cust-orders="${escapeHtml(c.uid)}" style="padding:4px 10px;font-size:12px;">Order History</button>
                </td>
              </tr>
            `;
          }).join('') || `<tr><td colspan="7" style="text-align:center;">No customer records found.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;

  panel.querySelectorAll('[data-view-cust-orders]').forEach(btn => {
    btn.addEventListener('click', () => {
      const uid = btn.getAttribute('data-view-cust-orders');
      const cust = state.customers.find(c => c.uid === uid);
      const custOrders = state.orders.filter(o => o.userId === uid);
      openDynamicModal(`Order History — ${cust?.name || 'Customer'}`, `
        <div style="font-size:13px;margin-bottom:12px;color:var(--text-secondary);">
          Email: <strong>${escapeHtml(cust?.email || '')}</strong> · Phone: <strong>${escapeHtml(cust?.phone || '—')}</strong>
        </div>
        ${custOrders.length === 0 ? `<p style="font-size:13.5px;">No orders placed by this customer yet.</p>` : `
          <div style="display:flex;flex-direction:column;gap:8px;max-height:360px;overflow-y:auto;">
            ${custOrders.map(o => `
              <div style="padding:10px;border-radius:var(--radius-sm);border:1px solid var(--border-light);background:var(--bg-light);font-size:12.5px;">
                <div style="display:flex;justify-content:space-between;font-weight:700;">
                  <span>${escapeHtml(o.orderNumber)} (${escapeHtml(o.orderStatus)})</span>
                  <span style="color:var(--brand-red);">${formatPrice(o.grandTotal)}</span>
                </div>
                <div style="margin-top:4px;color:var(--text-secondary);">${escapeHtml(o.itemsSummary)}</div>
              </div>
            `).join('')}
          </div>
        `}
      `);
    });
  });
}


export {
  validateAdminImageFile, uploadImageAsset, renderAdminView, renderAdminOverview,
  renderAdminProducts, openProductFormModal, renderAdminCategories, renderAdminOrders,
  renderAdminCustomers
};
