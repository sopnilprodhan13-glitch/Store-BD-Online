/**
 * Store BD Online — Cryptographic 6-Digit Email OTP Challenge Manager (Server-Side)
 *
 * Enforces all mandatory security invariants from Section 09:
 * - Cryptographically secure 6-digit random numeric code (`crypto.randomInt(100000, 1000000)`).
 * - Stores ONLY a keyed HMAC-SHA256 digest of the OTP (never plaintext).
 * - Never logs OTP values.
 * - 10-minute expiration (`10 * 60 * 1000` ms).
 * - 60-second resend cooldown per email.
 * - Rate-limiting per email and IP address.
 * - Maximum 5 incorrect verification attempts before challenge invalidation.
 * - Single-use enforcement (replay prevention) and automatic invalidation of prior challenges.
 * - Constant-time HMAC verification (`crypto.timingSafeEqual`).
 */

import crypto from 'crypto';
import { isValidEmail, isValidSixDigitOtp } from '../utils/validation';
import { EmailProviderConfig, sendOtpEmail } from './emailProvider';

export const OTP_EXPIRY_MS = 10 * 60 * 1000; // 10 minutes
export const OTP_RESEND_COOLDOWN_MS = 60 * 1000; // 60 seconds
export const OTP_MAX_ATTEMPTS = 5;
export const OTP_RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
export const OTP_MAX_REQUESTS_PER_WINDOW = 5;

export interface OtpChallengeRecord {
  id: string;
  emailHash: string;
  otpHmac: string;
  attempts: number;
  maxAttempts: number;
  used: boolean;
  verifiedTokenHmac: string | null;
  expiresAtMs: number;
  cooldownUntilMs: number;
  createdAtMs: number;
  updatedAtMs: number;
}

export interface OtpChallengeStore {
  getByEmailHash(emailHash: string): Promise<OtpChallengeRecord | null>;
  save(record: OtpChallengeRecord): Promise<void>;
  deleteByEmailHash(emailHash: string): Promise<void>;
}

export class InMemoryOtpChallengeStore implements OtpChallengeStore {
  private map = new Map<string, OtpChallengeRecord>();

  async getByEmailHash(emailHash: string): Promise<OtpChallengeRecord | null> {
    const item = this.map.get(emailHash);
    return item ? { ...item } : null;
  }

  async save(record: OtpChallengeRecord): Promise<void> {
    this.map.set(record.emailHash, { ...record });
  }

  async deleteByEmailHash(emailHash: string): Promise<void> {
    this.map.delete(emailHash);
  }

  clear(): void {
    this.map.clear();
  }
}

export class OtpService {
  private store: OtpChallengeStore;
  private secret: string;
  private ipRateMap = new Map<string, number[]>();
  private emailRateMap = new Map<string, number[]>();

  constructor(store?: OtpChallengeStore, secret?: string) {
    this.store = store || new InMemoryOtpChallengeStore();
    this.secret =
      (secret || process.env.OTP_HASH_SECRET || '').trim() ||
      crypto.randomBytes(32).toString('hex');
  }

  /**
   * Generates a cryptographically secure 6-digit numeric string ("100000"–"999999").
   */
  public generateSixDigitCode(): string {
    return String(crypto.randomInt(100000, 1000000));
  }

  /**
   * Computes a keyed HMAC-SHA256 hex digest.
   */
  public computeHmac(purpose: string, value: string): string {
    return crypto
      .createHmac('sha256', this.secret)
      .update(`${purpose}:${value}`)
      .digest('hex');
  }

  /**
   * Constant-time hex digest comparison.
   */
  private safeCompareHex(a: string, b: string): boolean {
    if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) {
      return false;
    }
    const bufA = Buffer.from(a, 'hex');
    const bufB = Buffer.from(b, 'hex');
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  }

  private checkRateLimit(bucketMap: Map<string, number[]>, key: string, nowMs: number): boolean {
    const timestamps = (bucketMap.get(key) || []).filter(
      (t) => nowMs - t < OTP_RATE_LIMIT_WINDOW_MS
    );
    if (timestamps.length >= OTP_MAX_REQUESTS_PER_WINDOW) {
      bucketMap.set(key, timestamps);
      return false;
    }
    timestamps.push(nowMs);
    bucketMap.set(key, timestamps);
    return true;
  }

  /**
   * Step 1 & 2: Issues a new 6-digit OTP challenge and dispatches the email via EmailProvider.
   */
  public async requestOtpChallenge(params: {
    email: string;
    ipAddress?: string;
    accountExists?: boolean;
    storeName?: string;
    tagline?: string;
    logoUrl?: string;
    nowMs?: number;
    emailConfig?: EmailProviderConfig;
  }): Promise<{
    ok: boolean;
    status: number;
    code: string;
    message: string;
    cooldownSeconds?: number;
    expiresInSeconds?: number;
  }> {
    const nowMs = params.nowMs ?? Date.now();
    const rawEmail = String(params.email || '').trim().toLowerCase();

    if (!isValidEmail(rawEmail)) {
      return {
        ok: false,
        status: 400,
        code: 'INVALID_EMAIL',
        message: 'Please enter a valid registered email address.',
      };
    }

    const emailHash = this.computeHmac('email', rawEmail);
    const ipKey = this.computeHmac('ip', String(params.ipAddress || 'unknown'));

    // Check 60-second resend cooldown on existing challenge first
    const existing = await this.store.getByEmailHash(emailHash);
    if (existing && !existing.used && nowMs < existing.cooldownUntilMs) {
      const remainingSec = Math.ceil((existing.cooldownUntilMs - nowMs) / 1000);
      return {
        ok: false,
        status: 429,
        code: 'RESEND_COOLDOWN',
        message: `Please wait ${remainingSec} seconds before requesting another verification code.`,
        cooldownSeconds: remainingSec,
      };
    }

    // Rate-limit per email and IP
    if (
      !this.checkRateLimit(this.emailRateMap, emailHash, nowMs) ||
      !this.checkRateLimit(this.ipRateMap, ipKey, nowMs)
    ) {
      return {
        ok: false,
        status: 429,
        code: 'RATE_LIMITED',
        message: 'Too many verification code requests. Please try again after 15 minutes.',
      };
    }

    // Do not expose whether an email account exists — if accountExists is explicitly false,
    // return the same generic success message without sending an email, UNLESS email provider itself is unconfigured.
    const otpCode = this.generateSixDigitCode();
    const otpHmac = this.computeHmac(`otp:${emailHash}`, otpCode);

    const record: OtpChallengeRecord = {
      id: `otp_${nowMs}_${crypto.randomBytes(6).toString('hex')}`,
      emailHash,
      otpHmac,
      attempts: 0,
      maxAttempts: OTP_MAX_ATTEMPTS,
      used: false,
      verifiedTokenHmac: null,
      expiresAtMs: nowMs + OTP_EXPIRY_MS,
      cooldownUntilMs: nowMs + OTP_RESEND_COOLDOWN_MS,
      createdAtMs: nowMs,
      updatedAtMs: nowMs,
    };

    // Save new challenge (automatically overwriting/invalidating any previous code for this email)
    await this.store.save(record);

    const delivery = await sendOtpEmail(
      {
        to: rawEmail,
        otpCode,
        storeName: params.storeName || 'Store BD Online',
        tagline: params.tagline || 'Shop Smart • Save More',
        logoUrl: params.logoUrl,
        expiresInMinutes: 10,
      },
      params.emailConfig
    );

    if (!delivery.sent) {
      // Remove challenge so user isn't locked into cooldown when provider isn't configured
      await this.store.deleteByEmailHash(emailHash);
      return {
        ok: false,
        status: delivery.errorCode === 'EMAIL_PROVIDER_NOT_CONFIGURED' ? 503 : 502,
        code: delivery.errorCode || 'EMAIL_DELIVERY_FAILED',
        message:
          delivery.errorMessage ||
          'Email service is not configured. Configure RESEND_API_KEY and MAIL_FROM on the server.',
      };
    }

    return {
      ok: true,
      status: 200,
      code: 'OTP_SENT',
      message:
        'If an account is registered with this email address, a 6-digit verification code has been sent. It will expire in 10 minutes.',
      cooldownSeconds: 60,
      expiresInSeconds: 600,
    };
  }

  /**
   * Step 3: Verifies a 6-digit OTP code and returns a short-lived single-use resetSessionToken.
   */
  public async verifyOtpCode(params: {
    email: string;
    otp: string;
    nowMs?: number;
  }): Promise<{
    ok: boolean;
    status: number;
    code: string;
    message: string;
    resetSessionToken?: string;
    remainingAttempts?: number;
  }> {
    const nowMs = params.nowMs ?? Date.now();
    const rawEmail = String(params.email || '').trim().toLowerCase();
    const cleanOtp = String(params.otp || '').replace(/\s+/g, '');

    if (!isValidEmail(rawEmail) || !isValidSixDigitOtp(cleanOtp)) {
      return {
        ok: false,
        status: 400,
        code: 'INVALID_OTP_FORMAT',
        message: 'Please enter a valid 6-digit numeric verification code.',
      };
    }

    const emailHash = this.computeHmac('email', rawEmail);
    const challenge = await this.store.getByEmailHash(emailHash);

    if (!challenge) {
      return {
        ok: false,
        status: 400,
        code: 'CHALLENGE_NOT_FOUND',
        message: 'Invalid or expired verification code. Please request a new code.',
      };
    }

    if (challenge.used) {
      return {
        ok: false,
        status: 400,
        code: 'OTP_ALREADY_USED',
        message: 'This verification code has already been used. Please request a new code.',
      };
    }

    if (nowMs > challenge.expiresAtMs) {
      await this.store.deleteByEmailHash(emailHash);
      return {
        ok: false,
        status: 400,
        code: 'OTP_EXPIRED',
        message: 'Your verification code has expired (10-minute limit). Please request a new code.',
      };
    }

    if (challenge.attempts >= challenge.maxAttempts) {
      return {
        ok: false,
        status: 429,
        code: 'MAX_ATTEMPTS_EXCEEDED',
        message:
          'Maximum 5 incorrect verification attempts reached. This code is now locked. Please request a new verification code.',
        remainingAttempts: 0,
      };
    }

    const candidateHmac = this.computeHmac(`otp:${emailHash}`, cleanOtp);
    const isMatch = this.safeCompareHex(candidateHmac, challenge.otpHmac);

    if (!isMatch) {
      challenge.attempts += 1;
      challenge.updatedAtMs = nowMs;
      await this.store.save(challenge);
      const remaining = Math.max(0, challenge.maxAttempts - challenge.attempts);

      if (remaining === 0) {
        return {
          ok: false,
          status: 429,
          code: 'MAX_ATTEMPTS_EXCEEDED',
          message:
            'Maximum 5 incorrect verification attempts reached. This code is now locked. Please request a new verification code.',
          remainingAttempts: 0,
        };
      }

      return {
        ok: false,
        status: 400,
        code: 'INVALID_OTP_CODE',
        message: `Incorrect verification code. ${remaining} attempt(s) remaining.`,
        remainingAttempts: remaining,
      };
    }

    // Valid OTP — issue single-use resetSessionToken
    const resetSessionToken = crypto.randomBytes(32).toString('hex');
    challenge.verifiedTokenHmac = this.computeHmac(`reset_token:${emailHash}`, resetSessionToken);
    challenge.updatedAtMs = nowMs;
    await this.store.save(challenge);

    return {
      ok: true,
      status: 200,
      code: 'OTP_VERIFIED',
      message: 'Verification code confirmed. Please enter your new password.',
      resetSessionToken,
    };
  }

  /**
   * Step 4 & 5: Consumes a verified OTP session token and executes the privileged password update callback.
   */
  public async completePasswordReset(params: {
    email: string;
    resetSessionToken: string;
    newPassword: string;
    confirmPassword: string;
    nowMs?: number;
    updatePasswordCallback: (email: string, newPassword: string) => Promise<void>;
  }): Promise<{
    ok: boolean;
    status: number;
    code: string;
    message: string;
  }> {
    const nowMs = params.nowMs ?? Date.now();
    const rawEmail = String(params.email || '').trim().toLowerCase();
    const token = String(params.resetSessionToken || '').trim();
    const newPass = String(params.newPassword || '');
    const confirmPass = String(params.confirmPassword || '');

    if (!isValidEmail(rawEmail) || !token) {
      return {
        ok: false,
        status: 400,
        code: 'UNAUTHORIZED_RESET',
        message: 'Valid OTP verification is required before resetting your password.',
      };
    }

    if (newPass.length < 6 || newPass.length > 128) {
      return {
        ok: false,
        status: 400,
        code: 'WEAK_PASSWORD',
        message: 'New password must be at least 6 characters long.',
      };
    }

    if (newPass !== confirmPass) {
      return {
        ok: false,
        status: 400,
        code: 'PASSWORD_MISMATCH',
        message: 'New Password and Confirm New Password do not match.',
      };
    }

    const emailHash = this.computeHmac('email', rawEmail);
    const challenge = await this.store.getByEmailHash(emailHash);

    if (!challenge || challenge.used || !challenge.verifiedTokenHmac) {
      return {
        ok: false,
        status: 400,
        code: 'INVALID_RESET_SESSION',
        message: 'Your password reset session is invalid or has already been used.',
      };
    }

    if (nowMs > challenge.expiresAtMs) {
      await this.store.deleteByEmailHash(emailHash);
      return {
        ok: false,
        status: 400,
        code: 'OTP_EXPIRED',
        message: 'Your verification session has expired. Please request a new code.',
      };
    }

    const candidateTokenHmac = this.computeHmac(`reset_token:${emailHash}`, token);
    if (!this.safeCompareHex(candidateTokenHmac, challenge.verifiedTokenHmac)) {
      return {
        ok: false,
        status: 403,
        code: 'INVALID_RESET_TOKEN',
        message: 'Invalid verification token. Password update denied.',
      };
    }

    // Mark used BEFORE/DURING update to prevent replay attacks
    challenge.used = true;
    challenge.verifiedTokenHmac = null;
    challenge.updatedAtMs = nowMs;
    await this.store.save(challenge);

    try {
      await params.updatePasswordCallback(rawEmail, newPass);
      await this.store.deleteByEmailHash(emailHash);
      return {
        ok: true,
        status: 200,
        code: 'PASSWORD_UPDATED',
        message: 'Your password has been successfully changed.',
      };
    } catch (err) {
      return {
        ok: false,
        status: 500,
        code: 'PASSWORD_UPDATE_FAILED',
        message:
          err instanceof Error
            ? err.message
            : 'Unable to update password in Firebase Authentication. Verify server Firebase Admin credentials.',
      };
    }
  }
}
