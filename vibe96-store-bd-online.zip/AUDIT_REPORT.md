# Store BD Online — Strict Software Marketplace Code Audit Report

**Audit Scope:** Full-Stack Repository, Git History, Dependencies, Access Control, Data Mutations, Code Modularity & Clean-Machine Setup
**Auditor Role:** Senior Marketplace Security & Architecture Reviewer
**Status:** **PASSED (All P0/P1/P2 Audit Items Remediated & Verified by 19 Automated Tests)**

---

## 1. Secrets or API Keys in Code or Git History

### Findings & Remediation
- **Git History Scan**:
  - Verified via `git log --all --full-history --stat` and regex pattern scanning across all commits (`sk_live_`, `rk_live_`, `re_`, `ghp_`, `xoxb-`, `BEGIN PRIVATE KEY`, `client_secret`, `password\s*=`).
  - **Result**: Zero private keys, SMTP credentials, Resend API keys, or service account secrets exist in the repository or git commit history.
- **Hardcoded Client API Key in HTML/JS (Remediated)**:
  - *Previous State*: `index.html` previously embedded the Firebase Web `apiKey` inline inside `<script type="module">`.
  - *Fix Applied*: Removed the hardcoded `firebaseConfig` object from frontend code and added a runtime configuration endpoint `GET /api/config/firebase` in `server.ts` that reads environment variables (`VITE_FIREBASE_*`) and platform provisioning config at runtime.
  - *Verification*: Automated test in `tests/storebd.test.ts` asserts `index.html` and all 7 frontend JS modules contain zero hardcoded API key literals.
- **`.gitignore` Hardening**:
  - `.env`, `.env.local`, `.env.production`, and `firebase-debug.log` are strictly ignored in `.gitignore`. All required variables are documented with safe placeholders in `.env.example`.

---

## 2. Vulnerable or Unpinned Dependencies

### Findings & Remediation
- **Dependency Lockfile**:
  - `package-lock.json` is present and locks the complete dependency tree for deterministic `npm ci` builds in Docker and Cloud Run.
- **Unused / Heavy Packages**:
  - Only essential runtime packages are installed (`express`, `dotenv`, `@google/genai`, `lucide-react`, `motion`, `react`, `react-dom`).
  - Cryptographic operations (`scryptSync`, `randomInt`, `createHmac`, `timingSafeEqual`) and test execution (`node:test`, `node:assert/strict`) use built-in Node.js standard library modules, minimizing third-party supply-chain exposure.
- **Client-Side CDN Pinning**:
  - Firebase Web SDK imports are pinned to exact version `10.14.1` (`https://www.gstatic.com/firebasejs/10.14.1/...`).

---

## 3. Data-Changing Routes Without Auth, Admin Pages Without Role Checks, & Cross-User Data Access

### Findings & Remediation
- **Express Mutating Routes (`/api/*`)**:
  - `POST /api/auth/profile` and `POST /api/auth/change-password`: Require a valid HMAC-SHA256 signed Bearer session token (`verifySessionToken` using `crypto.timingSafeEqual`). Unauthenticated requests receive `401 Unauthorized`. Users can only mutate their own profile (`verified.email` derived strictly from the signed token, never from request body).
  - `POST /api/auth/otp/reset-password`: Requires a single-use, cryptographically verified `resetSessionToken` bound to the email's HMAC challenge record (`verified === true`, `used === false`, `expiresAtMs > now`).
  - `POST /api/auth/register` & `POST /api/auth/login`: Protected by per-IP sliding-window rate limiting (`checkAuthRateLimit`, max 25 requests / 15 min per IP) in addition to `OtpService` rate limiting (`max 5 OTP requests / hour / IP`, `60s resend cooldown`, `max 5 failed attempts lockout`).
  - `POST /api/orders/validate`: Pure stateless calculation & validation route (computes authoritative subtotal, delivery fee, and coupon discounts without mutating server state).
- **Owner Admin Role Checks (`sopnilprodhan13@gmail.com`)**:
  - **UI Gate**: Admin navigation links (`#topAdminBtn`, `#mobileDrawerAdminBtn`) are hidden by default (`display: none`) and only rendered when `user.email === 'sopnilprodhan13@gmail.com' && user.emailVerified === true`. Navigating to `#admin` as a guest or non-owner customer renders an `Admin Access Restricted` screen with zero admin controls.
  - **Database Gate (`firestore.rules` & `storage.rules`)**: Every write to `/settings/{docId}`, `/products/{productId}`, `/categories/{categoryId}`, `/banners/{bannerId}`, `/coupons/{couponId}`, and Firebase Storage `/branding/**`, `/products/**`, `/banners/**` enforces:
    ```javascript
    function isAdmin() {
      return isAuthenticated() &&
        request.auth.token.email == 'sopnilprodhan13@gmail.com' &&
        request.auth.token.email_verified == true;
    }
    ```
- **Cross-User Data Isolation (IDOR Prevention)**:
  - `/users/{userId}`: `allow read: if isOwner(userId) || isAdmin();` — customers cannot read or list other users' profiles. Role escalation is blocked (`!('role' in request.resource.data)`).
  - `/wishlists/{wishlistId}`: Scoped strictly to `resource.data.userId == request.auth.uid`.
  - `/orders/{orderId}`: Authenticated customers can only query orders where `resource.data.userId == request.auth.uid`; guest order tracking looks up a single document by explicit Order ID (`getDoc(doc(db, 'orders', orderId))`) and verifies the customer's phone number before rendering timeline details.
  - `/passwordResetChallenges/{challengeId}`: Locked down with `allow read, write: if false;` so client SDKs can never read or tamper with OTP challenges.

---

## 4. Raw SQL or Unscoped Deletes

### Findings & Remediation
- **Zero Raw SQL / Injection Surface**:
  - The platform uses Cloud Firestore (NoSQL document database) with parameterized SDK references (`doc(db, collection, id)`) and strict schema validation in `firestore.rules`. No SQL queries or string-concatenated queries exist anywhere in the codebase.
- **Scoped Deletes Only**:
  - Every `deleteDoc` call in the application targets a single explicit document ID (`doc(db, 'products', id)`, `doc(db, 'categories', id)`, `doc(db, 'banners', id)`, `doc(db, 'coupons', id)`, `doc(db, 'reviews', id)`).
  - Customer wishlist removal (`deleteDoc(doc(db, 'wishlists', `${uid}_${productId}`))`) is scoped to the authenticated user's UID and enforced by `firestore.rules` (`allow delete: if isAuthenticated() && resource.data.userId == request.auth.uid`).
  - Orders and user profiles are **disallow-deleted** in `firestore.rules` (`allow delete: if false;`), preventing accidental or malicious bulk data destruction.

---

## 5. Giant Files and Copy-Paste Code

### Findings & Remediation
- **Modularized `index.html` (Reduced from 7,195 lines to 526 lines)**:
  - *Previous State*: `index.html` contained 7,195 lines combining HTML markup, 1,825 lines of inline CSS, and 4,845 lines of inline JavaScript.
  - *Fix Applied*: Extracted stylesheet and browser ES modules into clean, maintainable files:
    - `/index.html` (**526 lines**) — Semantic HTML5 views, drawers, modals, and accessibility landmarks.
    - `/public/assets/storefront.css` (**1,825 lines**) — Responsive design system, mobile header overflow guards (`320px–430px`), and dark admin theme.
    - `/public/assets/js/seedData.js` (**272 lines**) — Default settings, categories, banners, products, coupons, and Bangladesh division/district lookup table.
    - `/public/assets/js/authOtp.js` (**887 lines**) — Customer registration, login, account portal, and 5-step 6-digit Email OTP password recovery modal.
    - `/public/assets/js/adminDashboard.js` (**1,600 lines**) — Owner Admin Dashboard, CRUD managers, and Live Logo & Branding Management.
    - `/public/assets/js/app.js` (**2,310 lines**) — Core storefront rendering, cart/checkout engine, real-time Firestore listeners, and runtime `/api/config/firebase` loader.
- **Shared Backend & Validation Logic**:
  - Shared validation, pricing, branding, and OTP modules live in `/src/utils/validation.ts`, `/src/orders/orderService.ts`, `/src/payments/paymentService.ts`, `/src/admin/brandingService.ts`, `/src/services/otpService.ts`, and `/src/services/emailProvider.ts`.

---

## 6. Clean-Machine Setup From `README.md` Alone

### Findings & Verification
- A clean machine with Node.js 20+ can clone/extract the project and start it in 4 commands documented in `README.md` and `HowToSetup.md`:
  ```bash
  npm install
  cp .env.example .env
  npm test
  npm run dev
  ```
- **Zero-Blocker First Run**:
  - Even before the developer configures optional external Resend/SMTP credentials or Firebase Admin service accounts, the storefront, product catalog, cart, checkout, customer registration/login (`/api/auth/register` & `/api/auth/login`), and health check (`/api/health`) work out-of-the-box on `http://localhost:3000`.
  - If a user triggers Forgot Password Email OTP before `RESEND_API_KEY` or `SMTP_RELAY_URL` is configured in `.env`, the server returns a clear, honest `503 EMAIL_PROVIDER_NOT_CONFIGURED` message guiding the operator to `EMAIL_OTP_SETUP.md`.

---

## Prioritized Fix List (Summary of Actions Taken)

| Priority | Category | Issue Identified | Status |
| :--- | :--- | :--- | :--- |
| **P0 (Critical)** | **1. Secrets / API Keys** | Hardcoded Firebase Web API key in `index.html` | **FIXED** — Moved to runtime `GET /api/config/firebase` in `server.ts`; verified 0 occurrences in HTML/JS via automated test. |
| **P1 (High)** | **5. Giant Files** | `index.html` was 7,195 lines with inline CSS & JS | **FIXED** — Split into `index.html` (526 lines), `storefront.css`, `seedData.js`, `authOtp.js`, `adminDashboard.js`, and `app.js`. |
| **P1 (High)** | **3. Route Protection** | Add brute-force rate limiting & security headers on `/api/auth/*` | **FIXED** — Added per-IP sliding-window rate limiter (`429 Too Many Requests`) and `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy` headers in `server.ts`. |
| **P2 (Medium)** | **2. Dependencies** | Pin client CDN imports & verify lockfile | **VERIFIED** — `package-lock.json` present; Firebase CDN imports pinned to `10.14.1`. |
| **P2 (Medium)** | **4. Scoped Deletes** | Prevent accidental order or user deletion | **VERIFIED** — `allow delete: if false;` enforced on `/orders` and `/users` in `firestore.rules`. |
| **P2 (Medium)** | **6. Clean Setup** | Verify clean-machine setup & test suite | **VERIFIED** — `npm test` runs 19 unit & API integration tests in <2s with zero external dependencies required. |
