# Security Architecture & Threat Model (`SECURITY.md`)

**Store BD Online** implements defense-in-depth across Firebase Authentication, Firestore Security Rules, Firebase Storage Rules, and the Express backend API.

---

## 1. Authentication & Password Security

- **Firebase Authentication Only**: Customer and Owner Admin credentials are managed by Google Firebase Authentication.
- **No Client-Side Password Storage**: Plaintext passwords and password hashes are never stored in `localStorage`, `sessionStorage`, cookies, or Firestore documents.
- **Strict Login Behavior**: Signing in never auto-creates an account. Unregistered email login attempts receive `"Account not found. Please create an account first."`

---

## 2. Cryptographic 6-Digit Email OTP Password Recovery

The 5-step Forgot Password flow (`src/services/otpService.ts` and `server.ts`) enforces strict cryptographic controls:

1. **CSPRNG Code Generation**: 6-digit numeric codes (`100000`–`999999`) are generated via Node.js `crypto.randomInt(100000, 1000000)`.
2. **Keyed HMAC-SHA256 Storage**: Plaintext OTP codes are never stored in memory or Firestore. Only `HMAC-SHA256(secret, "otp:" + emailHash + ":" + code)` is stored.
3. **Constant-Time Verification**: Verification compares HMAC digests using `crypto.timingSafeEqual` to prevent timing side-channel attacks.
4. **10-Minute Expiration**: Every OTP challenge expires strictly 10 minutes (`600,000 ms`) after creation.
5. **60-Second Resend Cooldown**: Repeat requests for the same email within 60 seconds are rejected with `429 RESEND_COOLDOWN`.
6. **5-Attempt Brute-Force Lockout**: After 5 incorrect verification attempts, the challenge is permanently locked (`429 MAX_ATTEMPTS_EXCEEDED`), requiring a fresh OTP request.
7. **Single-Use Replay Prevention**: Once a challenge is verified and consumed to update the password, `used` is marked `true` and the challenge is deleted so neither the OTP nor the `resetSessionToken` can be replayed.
8. **Client SDK Lockdown**: In `firestore.rules`, `/passwordResetChallenges/{challengeId}` is locked with `allow read, write: if false;`.

---

## 3. Private Owner Admin Access Control (`sopnilprodhan13@gmail.com`)

- **Firestore Rules (`firestore.rules`)**:
  ```javascript
  function isAdmin() {
    return isAuthenticated() &&
           request.auth.token.email == "sopnilprodhan13@gmail.com" &&
           request.auth.token.email_verified == true;
  }
  ```
- **Storage Rules (`storage.rules`)**:
  Only `sopnilprodhan13@gmail.com` (`email_verified == true`) can upload or modify files under `/branding/**`, `/products/**`, `/categories/**`, and `/banners/**`, and every upload is validated for image MIME type (`PNG`, `JPG/JPEG`, `WebP`) and size (`<= 5MB`).

---

## 4. Checkout & Manual Payment Integrity

- **Manual Payment Verification Guard**: `firestore.rules` enforces that any customer order created with `bKash` or `Nagad` must have `paymentStatus == 'Pending Verification'` (and `COD` must have `'Cash on Delivery'`). Customers cannot mark their own payments as `'Paid'` or `'Verified'`.
- **Order Privacy**: Full order documents in `/orders/{orderId}` are readable only by the authenticated customer who placed the order or the Owner Admin. Public order tracking uses `/orderTracking/{orderId}` with `allow get: if true; allow list: if false;` so orders cannot be enumerated.
