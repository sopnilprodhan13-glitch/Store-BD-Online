# 🛍️ VIBE96 LISTING & SELLING GUIDE — STORE BD ONLINE

Welcome! This guide gives you everything you need to successfully sell this product on [https://vibe96.com/](https://vibe96.com/).

---

## 📦 What to Upload on Vibe96

When submitting your product to Vibe96, you can upload:
1. **Direct Zip File (Recommended):**  
   `vibe96-store-bd-online.zip` (Located in project root & `public/vibe96-store-bd-online.zip`)
2. **Or the Unzipped Folder:**  
   `vibe96-upload/` — Contains the 100% clean, verified, standalone codebase ready for customers.

---

## 📸 Screenshots Ready to Upload

The following high-definition screenshots (1920×1080) are included in `vibe96-upload/screenshots/` for your Vibe96 listing gallery:

1. `01-homepage-desktop.png` — Hero banner, smart gadgets, bestsellers & navigation.
2. `02-product-listing-category.png` — Category filters, price range, stock status & sorting.
3. `03-product-detail-page.png` — Gallery, price badges, stock counters & customer reviews.
4. `04-shopping-cart-checkout.png` — Bangladesh delivery calculation (Inside/Outside Dhaka), coupon system, bKash/Nagad/COD checkout.
5. `05-owner-admin-branding.png` — Complete live Logo upload, color picker, WhatsApp links, and 10 management modules.

---

## 📝 Copy-Paste Listing Information for Vibe96

### 📌 Product Title
```text
Store BD Online — Complete E-Commerce Store with Owner Admin & bKash/Nagad/COD Checkout
```

### 🏷️ Short Description / Tagline
```text
A complete full-stack single-store e-commerce platform with live Firebase real-time catalog, private Owner Admin dashboard, 5-step email OTP password reset, and bKash, Nagad & Cash-on-Delivery payment verification.
```

### 📋 Full Product Description (Copy & Paste)
```markdown
### Store BD Online — Modern Full-Stack E-Commerce Platform

Store BD Online is a complete, production-ready single-store e-commerce web application designed for entrepreneurs and business owners. It provides a lightning-fast responsive storefront, an automated checkout system tailored for Bangladesh (Dhaka / Outside Dhaka delivery fees, coupons, bKash, Nagad, and COD), Firebase real-time sync, and an extensive Owner Admin Dashboard.

#### ✨ Key Features
- **Mobile-First Responsive Storefront**: Optimized for all screen sizes (320px to 4K), smooth hero slider, sticky header, drawer navigation, and instant search.
- **Dynamic Catalog & Filtering**: Category filtering, price filter, sorting (Popularity, Price, Rating), product detail modal & full page.
- **Authoritative Checkout & Payment**:
  - Cash on Delivery (COD)
  - bKash & Nagad manual verification (transaction ID + sender number check)
  - Dynamic delivery charge calculation (Inside Dhaka ৳70, Outside Dhaka ৳130, free shipping threshold)
  - Coupon system (fixed & percentage discounts)
  - Order tracking by Order ID + Phone number
- **Customer Account & Security**:
  - Secure customer registration & login (Firebase Authentication + Server-side fallback)
  - 5-step 6-digit Email OTP Password Reset flow with countdown timers and rate limiting
  - Zero plaintext passwords in localStorage
- **Private Owner Admin Dashboard**:
  - Restricted to verified store owner email (`sopnilprodhan13@gmail.com` or custom owner email)
  - Complete Brand & Logo Customization: Upload PNG/JPG/WebP up to 5MB, live preview, favicon upload, colors, social links, WhatsApp support button.
  - Complete Product CRUD, Categories, Orders & Payment verification, Coupon management, Customer management, and CSV export.

#### 🛠️ Tech Stack
- Frontend: HTML5, CSS3, Vanilla Modern ES Modules, Tailwind CSS, Lucide Icons
- Backend: Node.js, Express, TypeScript (server.ts)
- Database & Auth: Google Firebase (Authentication, Cloud Firestore, Firebase Storage)
- Deployment: Docker, Docker Compose, Google Cloud Run, or any Node.js VPS / hosting

#### 🚀 Quick Start for Buyers
1. Run `npm install`
2. Run `npm run dev`
3. Open `http://localhost:3000`
Everything works immediately with pre-configured Firebase defaults and automated seed data!
```

---

## 🔧 Firebase Verification Status

- ✅ **Pre-Configured & Tested**: `firebase-applet-config.json` is bundled so the app runs out-of-the-box without requiring buyers to set up their own Firebase project immediately.
- ✅ **Custom Firebase Ready**: Buyers can easily switch to their own Firebase project by editing `.env` or replacing `firebase-applet-config.json` following the instructions in `HowToSetup.md`.
- ✅ **Zero `auth/api-key-not-valid` Errors**: Server config endpoint `/api/config/firebase` automatically sanitizes placeholders and supplies valid fallback credentials.
- ✅ **Security Rules Included**: Production-grade `firestore.rules`, `storage.rules`, and `firestore.indexes.json` are included and verified.
