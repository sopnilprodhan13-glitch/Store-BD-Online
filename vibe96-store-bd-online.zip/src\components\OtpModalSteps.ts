/**
 * Store BD Online — 5-Step Forgot Password Email OTP Modal Step Renderer
 *
 * Renders the 5 mandatory steps defined in Section 09:
 * - Step 1: Registered Email Address + Send Verification Code button + Back to Login link
 * - Step 2: Email Delivery dispatch
 * - Step 3: Six-digit OTP input (numeric filter + paste support) + Verify button + Resend Code button + Countdown timer
 * - Step 4: New Password + Confirm New Password + Update Password button
 * - Step 5: Success confirmation ("Your password has been successfully changed.") + Return to Login button
 */

import { escapeHtml } from '../utils/validation';
import { PASSWORD_CHANGED_SUCCESS_MESSAGE } from '../auth/authClient';

export type OtpFlowStep = 'step1_email' | 'step3_verify' | 'step4_password' | 'step5_success';

export function renderOtpFlowStepHtml(params: {
  step: OtpFlowStep;
  email: string;
  cooldownRemaining: number;
  expiryRemaining: number;
  errorMessage?: string;
  infoMessage?: string;
}): string {
  const safeEmail = escapeHtml(params.email);
  const errorBlock = params.errorMessage
    ? `<div id="otpStepErrorBanner" style="margin-bottom:12px;padding:10px 12px;border-radius:8px;background:#FEF2F2;color:#991B1B;font-size:12.5px;font-weight:600;border:1px solid #FCA5A5;">${escapeHtml(params.errorMessage)}</div>`
    : `<div id="otpStepErrorBanner" style="display:none;margin-bottom:12px;padding:10px 12px;border-radius:8px;background:#FEF2F2;color:#991B1B;font-size:12.5px;font-weight:600;border:1px solid #FCA5A5;"></div>`;

  const infoBlock = params.infoMessage
    ? `<div id="otpStepInfoBanner" style="margin-bottom:12px;padding:10px 12px;border-radius:8px;background:#EFF6FF;color:#1E40AF;font-size:12.5px;font-weight:600;border:1px solid #BFDBFE;">${escapeHtml(params.infoMessage)}</div>`
    : '';

  if (params.step === 'step1_email') {
    return `
      ${errorBlock}
      ${infoBlock}
      <form id="otpStep1Form">
        <p style="font-size:13px;color:#333333;margin:0 0 14px;line-height:1.5;">
          Enter your registered email address. We will send a six-digit verification code to reset your password.
        </p>
        <div class="form-group">
          <label class="form-label" for="otpEmailInput">Registered Email Address *</label>
          <input type="email" id="otpEmailInput" class="form-control" required maxlength="254" value="${safeEmail}" placeholder="you@example.com" />
        </div>
        <button type="submit" id="sendOtpCodeBtn" class="btn btn-red" style="width:100%;height:44px;">
          Send Verification Code
        </button>
        <div style="margin-top:14px;text-align:center;">
          <button type="button" id="otpBackToLoginBtn" style="color:#E50914;font-weight:700;font-size:13px;">
            ← Back to Login
          </button>
        </div>
      </form>
    `;
  }

  if (params.step === 'step3_verify') {
    const mins = Math.floor(params.expiryRemaining / 60);
    const secs = String(params.expiryRemaining % 60).padStart(2, '0');
    const resendDisabled = params.cooldownRemaining > 0 ? 'disabled' : '';
    const resendLabel =
      params.cooldownRemaining > 0
        ? `Resend Code (${params.cooldownRemaining}s)`
        : 'Resend Code';

    return `
      ${errorBlock}
      ${infoBlock}
      <form id="otpStep3Form">
        <p style="font-size:13px;color:#333333;margin:0 0 10px;line-height:1.5;">
          Enter the 6-digit verification code sent to <strong>${safeEmail}</strong>.
        </p>
        <div style="font-size:12px;color:#8A5700;background:#FFFBEB;padding:8px 12px;border-radius:8px;margin-bottom:14px;font-weight:700;display:flex;justify-content:space-between;align-items:center;">
          <span>Code expires in:</span>
          <span id="otpExpiryCountdown">${mins}:${secs}</span>
        </div>
        <div class="form-group">
          <label class="form-label" for="otpSixDigitInput">Six-Digit Verification Code *</label>
          <input
            type="text"
            id="otpSixDigitInput"
            class="form-control"
            inputmode="numeric"
            autocomplete="one-time-code"
            pattern="[0-9]{6}"
            maxlength="6"
            required
            placeholder="000000"
            style="font-size:22px;font-weight:800;letter-spacing:0.35em;text-align:center;font-family:monospace;"
          />
        </div>
        <button type="submit" id="verifyOtpCodeBtn" class="btn btn-red" style="width:100%;height:44px;margin-bottom:10px;">
          Verify
        </button>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:6px;">
          <button type="button" id="resendOtpCodeBtn" class="btn btn-outline" style="height:38px;font-size:12.5px;" ${resendDisabled}>
            ${escapeHtml(resendLabel)}
          </button>
          <button type="button" id="otpBackToLoginBtn" style="color:#E50914;font-weight:700;font-size:12.5px;">
            ← Back to Login
          </button>
        </div>
      </form>
    `;
  }

  if (params.step === 'step4_password') {
    return `
      ${errorBlock}
      ${infoBlock}
      <form id="otpStep4Form">
        <p style="font-size:13px;color:#333333;margin:0 0 14px;line-height:1.5;">
          Verification confirmed for <strong>${safeEmail}</strong>. Set your new account password below.
        </p>
        <div class="form-group">
          <label class="form-label" for="otpNewPasswordInput">New Password *</label>
          <input type="password" id="otpNewPasswordInput" class="form-control" required minlength="6" maxlength="128" placeholder="At least 6 characters" />
        </div>
        <div class="form-group">
          <label class="form-label" for="otpConfirmPasswordInput">Confirm New Password *</label>
          <input type="password" id="otpConfirmPasswordInput" class="form-control" required minlength="6" maxlength="128" placeholder="Re-enter new password" />
        </div>
        <button type="submit" id="updateOtpPasswordBtn" class="btn btn-red" style="width:100%;height:44px;">
          Update Password
        </button>
      </form>
    `;
  }

  return `
    <div style="text-align:center;padding:12px 4px;">
      <div style="width:56px;height:56px;border-radius:50%;background:rgba(16,185,129,0.14);color:#10B981;display:inline-flex;align-items:center;justify-content:center;font-size:26px;font-weight:800;margin-bottom:12px;">✓</div>
      <h3 style="font-size:17px;font-weight:800;color:#080808;margin:0 0 8px;">Password Reset Complete</h3>
      <p style="font-size:14px;color:#111111;font-weight:600;margin:0 0 18px;">
        ${escapeHtml(PASSWORD_CHANGED_SUCCESS_MESSAGE)}
      </p>
      <button type="button" id="otpReturnToLoginBtn" class="btn btn-red" style="width:100%;height:44px;">
        Return to Login
      </button>
    </div>
  `;
}
