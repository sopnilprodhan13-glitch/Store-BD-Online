import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword,
  updateProfile,
  signOut
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  initializeFirestore,
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  writeBatch,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js';

function renderAdminBanners(panel) {
  panel.innerHTML = `
    <div class="section-head">
      <h2 class="section-title">Promotional Banner Management (${state.banners.length})</h2>
      <button type="button" class="btn btn-red" id="adminAddBannerBtn">+ Add Banner</button>
    </div>
    <div class="data-table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Image</th><th>Heading</th><th>Type</th><th>Button</th><th>Actions</th></tr>
        </thead>
        <tbody>
          ${state.banners.map(b => `
            <tr>
              <td><img src="${escapeHtml(b.image)}" alt="" style="width:72px;height:40px;object-fit:cover;border-radius:6px;" referrerpolicy="no-referrer" /></td>
              <td><strong>${escapeHtml(b.heading)}</strong> <span style="color:var(--brand-red);">${escapeHtml(b.highlight || '')}</span></td>
              <td>${escapeHtml(b.type)}</td>
              <td>${escapeHtml(b.buttonText)}</td>
              <td>
                <div style="display:flex;gap:6px;">
                  <button type="button" class="btn btn-outline" data-edit-banner="${escapeHtml(b.id)}" style="padding:4px 10px;font-size:12px;">Edit</button>
                  <button type="button" class="btn btn-outline" data-del-banner="${escapeHtml(b.id)}" style="padding:4px 10px;font-size:12px;color:var(--danger);">Delete</button>
                </div>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;

  const openBannerModal = (existingBan = null) => {
    const b = existingBan || {
      id: `ban_${Date.now()}`,
      badge: 'FLASH SALE',
      heading: 'SHOP SMART',
      highlight: 'UP TO 30% OFF',
      description: 'Best gadgets at unbeatable Bangladesh prices.',
      buttonText: 'SHOP NOW',
      buttonDest: 'shop',
      image: '/assets/images/hero_smart_gadgets_1794737028016.jpg',
      type: 'hero',
      order: state.banners.length + 1,
      active: true
    };
    openDynamicModal(existingBan ? `Edit Banner: ${b.heading}` : 'Add Promotional Banner', `
      <form id="addBannerForm">
        <div class="form-group">
          <label class="form-label">Badge Kicker</label>
          <input type="text" id="bnBadge" class="form-control" value="${escapeHtml(b.badge || '')}" maxlength="80" />
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Main Heading *</label>
            <input type="text" id="bnHead" class="form-control" required value="${escapeHtml(b.heading)}" maxlength="160" />
          </div>
          <div class="form-group">
            <label class="form-label">Red Highlight Text</label>
            <input type="text" id="bnHigh" class="form-control" value="${escapeHtml(b.highlight || '')}" maxlength="160" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Description</label>
          <input type="text" id="bnDesc" class="form-control" value="${escapeHtml(b.description || '')}" maxlength="500" />
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Banner Image URL or Upload *</label>
            <input type="text" id="bnImg" class="form-control" required value="${escapeHtml(b.image)}" style="margin-bottom:6px;" />
            <input type="file" id="bnImgFile" accept="image/*" class="form-control" />
          </div>
          <div class="form-group">
            <label class="form-label">Banner Placement</label>
            <select id="bnType" class="form-control">
              <option value="hero" ${b.type === 'hero' ? 'selected' : ''}>Hero Slider</option>
              <option value="promo" ${b.type === 'promo' ? 'selected' : ''}>Mid-Page Promo</option>
            </select>
          </div>
        </div>
        <button type="submit" class="btn btn-red" style="width:100%;">Save Banner</button>
      </form>
    `);
    document.getElementById('addBannerForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      let imgUrl = document.getElementById('bnImg').value.trim().slice(0, 950);
      const fileIn = document.getElementById('bnImgFile');
      if (fileIn?.files?.[0]) {
        const uploaded = await uploadImageAsset(fileIn.files[0], 'banners');
        if (uploaded) imgUrl = uploaded;
      }
      try {
        await setDoc(doc(db, 'banners', b.id), {
          id: b.id,
          badge: document.getElementById('bnBadge').value.trim().slice(0, 80),
          heading: document.getElementById('bnHead').value.trim().slice(0, 160),
          highlight: document.getElementById('bnHigh').value.trim().slice(0, 160),
          description: document.getElementById('bnDesc').value.trim().slice(0, 500),
          buttonText: b.buttonText || 'SHOP NOW',
          buttonDest: b.buttonDest || 'shop',
          image: imgUrl,
          type: document.getElementById('bnType').value,
          order: b.order || state.banners.length + 1,
          active: true,
          createdAt: b.createdAt || serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        closeDynamicModal();
        showToast('Banner saved!');
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `banners/${b.id}`);
      }
    });
  };

  document.getElementById('adminAddBannerBtn')?.addEventListener('click', () => openBannerModal(null));
  panel.querySelectorAll('[data-edit-banner]').forEach(btn => {
    btn.addEventListener('click', () => {
      const ban = state.banners.find(b => b.id === btn.getAttribute('data-edit-banner'));
      if (ban) openBannerModal(ban);
    });
  });

  panel.querySelectorAll('[data-del-banner]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const bid = btn.getAttribute('data-del-banner');
      await deleteDoc(doc(db, 'banners', bid));
      showToast('Banner deleted.');
    });
  });
}

function renderAdminCoupons(panel) {
  panel.innerHTML = `
    <div class="section-head">
      <h2 class="section-title">Coupon Management (${state.coupons.length})</h2>
      <button type="button" class="btn btn-red" id="adminAddCouponBtn">+ Create Coupon</button>
    </div>
    <div class="data-table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Code</th><th>Type & Value</th><th>Min Order</th><th>Usage</th><th>Expires</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
          ${state.coupons.map(c => `
            <tr>
              <td><strong><code>${escapeHtml(c.code)}</code></strong></td>
              <td>${c.discountType === 'percentage' ? `${c.discountValue}% OFF` : `${formatPrice(c.discountValue)} OFF`}</td>
              <td class="tabular-nums">${formatPrice(c.minOrder)}</td>
              <td class="tabular-nums">${c.usedCount || 0} / ${c.maxUsage}</td>
              <td class="tabular-nums">${escapeHtml(c.expiresAt || '2027-12-31')}</td>
              <td>
                <button type="button" class="btn btn-outline" data-toggle-coupon="${escapeHtml(c.id)}" style="padding:3px 8px;font-size:11.5px;">
                  ${c.active !== false ? '✅ Active' : '⏸️ Inactive'}
                </button>
              </td>
              <td><button type="button" class="btn btn-outline" data-del-coupon="${escapeHtml(c.id)}" style="padding:4px 10px;font-size:12px;color:var(--danger);">Delete</button></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;

  document.getElementById('adminAddCouponBtn')?.addEventListener('click', () => {
    openDynamicModal('Create Discount Coupon', `
      <form id="addCouponForm">
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Coupon Code *</label>
            <input type="text" id="cpCode" class="form-control" required maxlength="30" placeholder="SAVE20" />
          </div>
          <div class="form-group">
            <label class="form-label">Discount Type *</label>
            <select id="cpType" class="form-control">
              <option value="percentage">Percentage (%)</option>
              <option value="fixed">Fixed Amount (৳)</option>
            </select>
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Discount Value *</label>
            <input type="number" id="cpVal" class="form-control" required min="1" value="15" />
          </div>
          <div class="form-group">
            <label class="form-label">Minimum Order (৳) *</label>
            <input type="number" id="cpMin" class="form-control" required min="0" value="1000" />
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Usage Limit *</label>
            <input type="number" id="cpMax" class="form-control" required min="1" value="100" />
          </div>
          <div class="form-group">
            <label class="form-label">Expiration Date *</label>
            <input type="date" id="cpExp" class="form-control" required value="2027-12-31" />
          </div>
        </div>
        <button type="submit" class="btn btn-red" style="width:100%;">Create Coupon</button>
      </form>
    `);
    document.getElementById('addCouponForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const code = document.getElementById('cpCode').value.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
      if (!code) return;
      try {
        await setDoc(doc(db, 'coupons', code), {
          id: code,
          code,
          discountType: document.getElementById('cpType').value,
          discountValue: Number(document.getElementById('cpVal').value) || 10,
          minOrder: Number(document.getElementById('cpMin').value) || 0,
          maxUsage: Number(document.getElementById('cpMax').value) || 100,
          usedCount: 0,
          expiresAt: (document.getElementById('cpExp').value || '2027-12-31').slice(0, 40),
          active: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        closeDynamicModal();
        showToast(`Coupon ${code} created!`);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `coupons/${code}`);
      }
    });
  });

  panel.querySelectorAll('[data-toggle-coupon]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const cid = btn.getAttribute('data-toggle-coupon');
      const c = state.coupons.find(x => x.id === cid);
      if (!c) return;
      try {
        await setDoc(doc(db, 'coupons', cid), {
          ...c,
          active: c.active === false,
          updatedAt: serverTimestamp()
        });
        showToast(`Coupon ${c.code} status updated.`);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `coupons/${cid}`);
      }
    });
  });

  panel.querySelectorAll('[data-del-coupon]').forEach(btn => {
    btn.addEventListener('click', async () => {
      await deleteDoc(doc(db, 'coupons', btn.getAttribute('data-del-coupon')));
      showToast('Coupon deleted.');
    });
  });
}

function renderAdminReviews(panel) {
  panel.innerHTML = `
    <div class="section-head"><h2 class="section-title">Customer Review Moderation (${state.reviews.length})</h2></div>
    <div class="data-table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Customer</th><th>Rating</th><th>Comment</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
          ${state.reviews.map(r => `
            <tr>
              <td><strong>${escapeHtml(r.userName)}</strong> ${r.verifiedPurchase ? '✓' : ''}</td>
              <td style="color:#F59E0B;">${'★'.repeat(r.rating || 5)}</td>
              <td>${escapeHtml(r.comment)}</td>
              <td>${escapeHtml(r.status)}</td>
              <td>
                <button type="button" class="btn btn-outline" data-del-review="${escapeHtml(r.id)}" style="padding:4px 10px;font-size:12px;color:var(--danger);">Delete</button>
              </td>
            </tr>
          `).join('') || `<tr><td colspan="5" style="text-align:center;">No reviews submitted yet.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
  panel.querySelectorAll('[data-del-review]').forEach(btn => {
    btn.addEventListener('click', async () => {
      await deleteDoc(doc(db, 'reviews', btn.getAttribute('data-del-review')));
      showToast('Review removed.');
    });
  });
}

function renderAdminSettings(panel) {
  const s = state.settings;
  const previewLogoSrc = s.logoUrl === 'NONE'
    ? ''
    : (s.logoUrl && s.logoUrl !== DEFAULT_SETTINGS.logoUrl ? s.logoUrl : (state.transparentLogoDataUrl || DEFAULT_SETTINGS.logoUrl));

  panel.innerHTML = `
    <div class="section-head" style="flex-wrap:wrap;gap:10px;">
      <div>
        <h2 class="section-title">WEBSITE BRANDING & CUSTOMIZATION</h2>
        <p style="font-size:13px;color:var(--text-secondary);">Manage your store logo, favicon, brand identity, colors, SEO metadata, social channels, payment numbers, and delivery charges.</p>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        ${state.transparentLogoDataUrl ? `<a href="${state.transparentLogoDataUrl}" download="store_bd_online_logo_transparent.png" class="btn btn-outline">⬇ Download Transparent PNG Logo</a>` : ''}
        <button type="button" class="btn btn-outline" id="resetDefaultBrandingBtn">↺ Reset to Default</button>
      </div>
    </div>

    <form id="adminSettingsForm" style="display:flex;flex-direction:column;gap:20px;">
      <!-- LOGO MANAGEMENT -->
      <div style="background:var(--bg-white);padding:22px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h3 style="font-size:16px;font-weight:800;margin-bottom:6px;color:var(--brand-red);">LOGO MANAGEMENT (Desktop & Mobile File Picker)</h3>
        <p style="font-size:12.5px;color:var(--text-secondary);margin-bottom:14px;">
          Supported formats: <strong>PNG, JPG, JPEG, WebP, Transparent PNG</strong> (max 5MB). Transparent PNG logos are preserved cleanly without forced black/white boxes and automatically update all 9 storefront locations.
        </p>

        <div style="display:grid;grid-template-columns:160px 1fr;gap:18px;align-items:center;margin-bottom:16px;" class="logo-mgmt-grid">
          <div style="border:1px dashed var(--border-medium);border-radius:var(--radius-md);padding:14px;text-align:center;background:repeating-conic-gradient(#F8FAFC 0% 25%, #FFFFFF 0% 50%) 50% / 16px 16px;">
            <div style="font-size:11px;font-weight:700;color:var(--text-muted);margin-bottom:6px;">LIVE LOGO PREVIEW</div>
            <img id="adminLogoLivePreview" src="${previewLogoSrc}" alt="Live Logo Preview" style="max-width:110px;max-height:80px;object-fit:contain;margin:0 auto;display:${previewLogoSrc ? 'block' : 'none'};" />
            <div id="adminLogoRemovedBadge" style="display:${previewLogoSrc ? 'none' : 'block'};font-size:11.5px;color:var(--text-secondary);padding:16px 0;">No Logo Active</div>
          </div>

          <div style="display:flex;flex-direction:column;gap:10px;">
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <label for="stLogoFile" class="btn btn-red" style="cursor:pointer;">
                📤 Upload New Logo / Select From Device
              </label>
              <input type="file" id="stLogoFile" accept="image/png,image/jpeg,image/jpg,image/webp" style="display:none;" />
              <button type="button" class="btn btn-outline" id="replaceExistingLogoBtn">🔄 Replace Existing Logo</button>
              <button type="button" class="btn btn-outline" id="removeCurrentLogoBtn">🗑️ Remove Current Logo</button>
              <button type="button" class="btn btn-outline" id="resetDefaultLogoBtn">↺ Reset to Default Logo</button>
            </div>
            <div id="logoUploadStatusMsg" style="font-size:12px;font-weight:700;color:var(--text-secondary);"></div>
            <div class="form-grid-2">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Main Website Logo URL</label>
                <input type="text" id="stLogoUrl" class="form-control" value="${escapeHtml(s.logoUrl || '')}" placeholder="/assets/aistudio/image_cd2fbd85.png" />
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Favicon URL or Upload Separate Favicon</label>
                <div style="display:flex;gap:6px;">
                  <input type="text" id="stFaviconUrl" class="form-control" value="${escapeHtml(s.faviconUrl || s.logoUrl || '')}" placeholder="Favicon URL" />
                  <label for="stFaviconFile" class="btn btn-outline" style="cursor:pointer;white-space:nowrap;">Upload Icon</label>
                  <input type="file" id="stFaviconFile" accept="image/png,image/jpeg,image/webp" style="display:none;" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- A. FULL BRAND CUSTOMIZATION & SEO -->
      <div style="background:var(--bg-white);padding:22px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h3 style="font-size:16px;font-weight:800;margin-bottom:14px;color:var(--brand-red);">A. Brand Identity, Colors & SEO Metadata</h3>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Store / Website Name *</label>
            <input type="text" id="stSiteName" class="form-control" required value="${escapeHtml(s.siteName)}" />
          </div>
          <div class="form-group">
            <label class="form-label">Tagline / Slogan *</label>
            <input type="text" id="stTagline" class="form-control" required value="${escapeHtml(s.tagline)}" />
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Primary Brand Color (Hex)</label>
            <input type="text" id="stPrimaryColor" class="form-control" value="${escapeHtml(s.primaryColor || '#E50914')}" placeholder="#E50914" />
          </div>
          <div class="form-group">
            <label class="form-label">Secondary Accent Color (Hex)</label>
            <input type="text" id="stSecondaryColor" class="form-control" value="${escapeHtml(s.secondaryColor || '#FFD500')}" placeholder="#FFD500" />
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Button Color (Hex)</label>
            <input type="text" id="stButtonColor" class="form-control" value="${escapeHtml(s.buttonColor || s.primaryColor || '#E50914')}" placeholder="#E50914" />
          </div>
          <div class="form-group">
            <label class="form-label">Header Background Color (Hex)</label>
            <input type="text" id="stHeaderBg" class="form-control" value="${escapeHtml(s.headerBgColor || '#FFFFFF')}" placeholder="#FFFFFF" />
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Footer Background Color (Hex)</label>
            <input type="text" id="stFooterBg" class="form-control" value="${escapeHtml(s.footerBgColor || '#080808')}" placeholder="#080808" />
          </div>
          <div class="form-group">
            <label class="form-label">Announcement Bar Text</label>
            <input type="text" id="stPromoBar" class="form-control" value="${escapeHtml(s.promoBarText)}" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Store Description / Footer Content</label>
          <textarea id="stFooterAbout" class="form-control" rows="2">${escapeHtml(s.footerAbout || '')}</textarea>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Contact Email</label>
            <input type="email" id="stSupportEmail" class="form-control" value="${escapeHtml(s.supportEmail || '')}" />
          </div>
          <div class="form-group">
            <label class="form-label">Contact Phone Number</label>
            <input type="text" id="stContactPhone" class="form-control" value="${escapeHtml(s.contactPhone || s.whatsappNumber || '+880 1700-000000')}" />
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">SEO Title</label>
            <input type="text" id="stSeoTitle" class="form-control" value="${escapeHtml(s.seoTitle || `${s.siteName} — ${s.tagline}`)}" />
          </div>
          <div class="form-group">
            <label class="form-label">Copyright Text</label>
            <input type="text" id="stCopyright" class="form-control" value="${escapeHtml(s.copyrightText || 'STORE BD ONLINE. All Rights Reserved.')}" />
          </div>
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">SEO Description</label>
          <input type="text" id="stSeoDesc" class="form-control" value="${escapeHtml(s.seoDescription || s.footerAbout || '')}" />
        </div>
      </div>

      <!-- B. WHATSAPP SETTINGS -->
      <div style="background:var(--bg-white);padding:22px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h3 style="font-size:16px;font-weight:800;margin-bottom:14px;color:#128C7E;">B. WhatsApp Support & Chat Settings</h3>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">WhatsApp Country Code</label>
            <input type="text" id="stWaCountry" class="form-control" value="${escapeHtml(s.whatsappCountryCode || '+880')}" placeholder="+880" />
          </div>
          <div class="form-group">
            <label class="form-label">WhatsApp Support Number</label>
            <input type="text" id="stWhatsapp" class="form-control" value="${escapeHtml(s.whatsappNumber)}" placeholder="+880 1700-000000" />
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">WhatsApp Support Status</label>
            <input type="text" id="stWaStatus" class="form-control" value="${escapeHtml(s.whatsappSupportStatus || 'Online (9:00 AM – 11:00 PM)')}" />
          </div>
          <div class="form-group">
            <label class="form-label">WhatsApp Default Inquiry Message</label>
            <input type="text" id="stWaMsg" class="form-control" value="${escapeHtml(s.whatsappDefaultMessage || 'Hello STORE BD ONLINE! I need assistance with a product or order.')}" />
          </div>
        </div>
        <label style="font-size:13px;font-weight:700;display:inline-flex;align-items:center;gap:8px;">
          <input type="checkbox" id="stEnableWaFloat" ${s.enableFloatingWhatsapp !== false ? 'checked' : ''} />
          Enable Floating WhatsApp Support Button on Storefront
        </label>
      </div>

      <!-- C. FACEBOOK SETTINGS -->
      <div style="background:var(--bg-white);padding:22px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h3 style="font-size:16px;font-weight:800;margin-bottom:14px;color:#1877F2;">C. Facebook Page & Messenger Settings</h3>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Facebook Page Name</label>
            <input type="text" id="stFbName" class="form-control" value="${escapeHtml(s.facebookPageName || 'STORE BD ONLINE Official')}" />
          </div>
          <div class="form-group">
            <label class="form-label">Facebook Page URL</label>
            <input type="text" id="stFbUrl" class="form-control" value="${escapeHtml(s.facebookUrl || 'https://facebook.com/storebdonline')}" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Facebook Messenger URL</label>
          <input type="text" id="stFbMessenger" class="form-control" value="${escapeHtml(s.facebookMessengerUrl || 'https://m.me/storebdonline')}" />
        </div>
        <label style="font-size:13px;font-weight:700;display:inline-flex;align-items:center;gap:8px;">
          <input type="checkbox" id="stEnableFbBtn" ${s.enableFacebookButton !== false ? 'checked' : ''} />
          Display Facebook Button in Footer
        </label>
      </div>

      <!-- D. PAYMENT SETTINGS -->
      <div style="background:var(--bg-white);padding:22px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h3 style="font-size:16px;font-weight:800;margin-bottom:14px;color:#E2136E;">D. Payment Methods & Manual Verification Settings</h3>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">bKash Number (Default: "Not configured")</label>
            <input type="text" id="stBkash" class="form-control" required value="${escapeHtml(s.bkashNumber || 'Not configured')}" />
          </div>
          <div class="form-group">
            <label class="form-label">Nagad Number (Default: "Not configured")</label>
            <input type="text" id="stNagad" class="form-control" required value="${escapeHtml(s.nagadNumber || 'Not configured')}" />
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Payment Account Type (Personal / Merchant)</label>
            <input type="text" id="stPayAccType" class="form-control" value="${escapeHtml(s.paymentAccountType || 'Personal / Merchant (Demo Mode)')}" />
          </div>
          <div class="form-group">
            <label class="form-label">Business Address</label>
            <input type="text" id="stAddress" class="form-control" value="${escapeHtml(s.address || '')}" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Checkout Payment Instructions</label>
          <input type="text" id="stPayInst" class="form-control" value="${escapeHtml(s.paymentInstructions || 'Send Money to the configured number and enter your Sender Mobile Number & Transaction ID (TrxID) below for admin verification.')}" />
        </div>
        <div style="display:flex;gap:18px;flex-wrap:wrap;font-size:13px;font-weight:700;">
          <label><input type="checkbox" id="stEnableCod" ${s.enableCod !== false ? 'checked' : ''} /> Enable Cash on Delivery</label>
          <label><input type="checkbox" id="stEnableBkash" ${s.enableBkash !== false ? 'checked' : ''} /> Enable bKash</label>
          <label><input type="checkbox" id="stEnableNagad" ${s.enableNagad !== false ? 'checked' : ''} /> Enable Nagad</label>
        </div>
      </div>

      <!-- E. DELIVERY SETTINGS -->
      <div style="background:var(--bg-white);padding:22px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h3 style="font-size:16px;font-weight:800;margin-bottom:14px;">E. Delivery Charges & Thresholds</h3>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label">Inside City Delivery Charge (৳)</label>
            <input type="number" id="stDhakaFee" class="form-control" required value="${s.insideDhakaFee}" />
          </div>
          <div class="form-group">
            <label class="form-label">Outside City Delivery Charge (৳)</label>
            <input type="number" id="stOutFee" class="form-control" required value="${s.outsideDhakaFee}" />
          </div>
        </div>
        <div class="form-grid-2">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Free Delivery Minimum Order (৳)</label>
            <input type="number" id="stFreeThresh" class="form-control" required value="${s.freeDeliveryThreshold}" />
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Estimated Delivery Message</label>
            <input type="text" id="stEstDelivery" class="form-control" value="${escapeHtml(s.estimatedDeliveryMessage || 'Inside City: 24–48 Hours • Outside City: 2–4 Days')}" />
          </div>
        </div>
      </div>

      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <button type="button" class="btn btn-outline" id="livePreviewSettingsBtn" style="height:48px;font-size:14px;">👁️ Live Preview</button>
        <button type="submit" class="btn btn-red" style="flex:1;height:48px;font-size:15px;">💾 Save & Publish Branding Changes</button>
      </div>
    </form>
  `;

  const logoFileIn = document.getElementById('stLogoFile');
  const logoUrlIn = document.getElementById('stLogoUrl');
  const previewImg = document.getElementById('adminLogoLivePreview');
  const removedBadge = document.getElementById('adminLogoRemovedBadge');
  const statusMsg = document.getElementById('logoUploadStatusMsg');

  const updateLogoPreviewBox = (src) => {
    if (!src || src === 'NONE') {
      if (previewImg) previewImg.style.display = 'none';
      if (removedBadge) removedBadge.style.display = 'block';
    } else {
      if (previewImg) {
        previewImg.src = src;
        previewImg.style.display = 'block';
      }
      if (removedBadge) removedBadge.style.display = 'none';
    }
  };

  document.getElementById('replaceExistingLogoBtn')?.addEventListener('click', () => {
    logoFileIn?.click();
  });

  logoFileIn?.addEventListener('change', async () => {
    const file = logoFileIn.files?.[0];
    if (!file) return;
    const check = validateAdminImageFile(file);
    if (!check.valid) {
      if (statusMsg) {
        statusMsg.textContent = check.error;
        statusMsg.style.color = '#991B1B';
      }
      showToast(check.error);
      logoFileIn.value = '';
      return;
    }
    if (statusMsg) {
      statusMsg.textContent = `Uploading "${file.name}" (${(file.size / 1024).toFixed(1)} KB)...`;
      statusMsg.style.color = 'var(--text-secondary)';
    }
    try {
      const uploadedUrl = await uploadImageAsset(file, 'branding');
      if (uploadedUrl) {
        logoUrlIn.value = uploadedUrl;
        updateLogoPreviewBox(uploadedUrl);
        if (statusMsg) {
          statusMsg.textContent = '✓ Logo uploaded and ready. Click "Save & Publish Branding Changes" to persist.';
          statusMsg.style.color = '#15803D';
        }
      }
    } catch (err) {
      if (statusMsg) {
        statusMsg.textContent = err.message || 'Logo upload failed.';
        statusMsg.style.color = '#991B1B';
      }
    }
  });

  document.getElementById('stFaviconFile')?.addEventListener('change', async (ev) => {
    const file = ev.target.files?.[0];
    if (!file) return;
    try {
      const uploadedFav = await uploadImageAsset(file, 'branding');
      if (uploadedFav) {
        document.getElementById('stFaviconUrl').value = uploadedFav;
        showToast('Favicon uploaded! Click Save & Publish to apply.');
      }
    } catch (_) {}
  });

  document.getElementById('removeCurrentLogoBtn')?.addEventListener('click', () => {
    logoUrlIn.value = 'NONE';
    if (logoFileIn) logoFileIn.value = '';
    updateLogoPreviewBox('NONE');
    showToast('Logo marked for removal. Click Save & Publish to apply.');
  });

  document.getElementById('resetDefaultLogoBtn')?.addEventListener('click', () => {
    logoUrlIn.value = DEFAULT_SETTINGS.logoUrl;
    document.getElementById('stFaviconUrl').value = DEFAULT_SETTINGS.faviconUrl;
    if (logoFileIn) logoFileIn.value = '';
    updateLogoPreviewBox(state.transparentLogoDataUrl || DEFAULT_SETTINGS.logoUrl);
    showToast('Reset to default Store BD Online logo.');
  });

  document.getElementById('resetDefaultBrandingBtn')?.addEventListener('click', async () => {
    const resetDoc = { ...DEFAULT_SETTINGS, updatedAt: serverTimestamp() };
    try {
      await setDoc(doc(db, 'settings', 'store'), resetDoc);
      state.settings = { ...DEFAULT_SETTINGS };
      applySettingsToUI();
      renderAdminSettings(panel);
      showToast('All branding & store settings restored to defaults.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'settings/store');
    }
  });

  const collectSettingsForm = () => {
    const rawLogo = document.getElementById('stLogoUrl').value.trim().slice(0, 950);
    const logoUrl = rawLogo || DEFAULT_SETTINGS.logoUrl;
    return {
      ...state.settings,
      siteName: document.getElementById('stSiteName').value.trim().slice(0, 115),
      tagline: document.getElementById('stTagline').value.trim().slice(0, 190),
      logoUrl,
      faviconUrl: document.getElementById('stFaviconUrl').value.trim().slice(0, 950) || logoUrl,
      primaryColor: document.getElementById('stPrimaryColor').value.trim().slice(0, 28) || '#E50914',
      secondaryColor: document.getElementById('stSecondaryColor').value.trim().slice(0, 28) || '#FFD500',
      buttonColor: document.getElementById('stButtonColor').value.trim().slice(0, 28) || '#E50914',
      headerBgColor: document.getElementById('stHeaderBg').value.trim().slice(0, 28) || '#FFFFFF',
      footerBgColor: document.getElementById('stFooterBg').value.trim().slice(0, 28) || '#080808',
      copyrightText: document.getElementById('stCopyright').value.trim().slice(0, 240),
      supportEmail: document.getElementById('stSupportEmail').value.trim().slice(0, 240),
      contactPhone: document.getElementById('stContactPhone').value.trim().slice(0, 28),
      seoTitle: document.getElementById('stSeoTitle').value.trim().slice(0, 155),
      seoDescription: document.getElementById('stSeoDesc').value.trim().slice(0, 310),
      footerAbout: document.getElementById('stFooterAbout').value.trim().slice(0, 950),
      whatsappCountryCode: document.getElementById('stWaCountry').value.trim().slice(0, 9) || '+880',
      whatsappNumber: document.getElementById('stWhatsapp').value.trim().slice(0, 28),
      whatsappSupportStatus: document.getElementById('stWaStatus').value.trim().slice(0, 115),
      whatsappDefaultMessage: document.getElementById('stWaMsg').value.trim().slice(0, 480),
      enableFloatingWhatsapp: document.getElementById('stEnableWaFloat').checked,
      facebookPageName: document.getElementById('stFbName').value.trim().slice(0, 115),
      facebookUrl: document.getElementById('stFbUrl').value.trim().slice(0, 480),
      facebookMessengerUrl: document.getElementById('stFbMessenger').value.trim().slice(0, 480),
      enableFacebookButton: document.getElementById('stEnableFbBtn').checked,
      bkashNumber: document.getElementById('stBkash').value.trim().slice(0, 28),
      nagadNumber: document.getElementById('stNagad').value.trim().slice(0, 28),
      paymentAccountType: document.getElementById('stPayAccType').value.trim().slice(0, 75),
      paymentInstructions: document.getElementById('stPayInst').value.trim().slice(0, 950),
      address: document.getElementById('stAddress').value.trim().slice(0, 380),
      enableCod: document.getElementById('stEnableCod').checked,
      enableBkash: document.getElementById('stEnableBkash').checked,
      enableNagad: document.getElementById('stEnableNagad').checked,
      insideDhakaFee: Number(document.getElementById('stDhakaFee').value) || 60,
      outsideDhakaFee: Number(document.getElementById('stOutFee').value) || 120,
      freeDeliveryThreshold: Number(document.getElementById('stFreeThresh').value) || 3000,
      estimatedDeliveryMessage: document.getElementById('stEstDelivery').value.trim().slice(0, 240),
      promoBarText: document.getElementById('stPromoBar').value.trim().slice(0, 290),
      updatedAt: serverTimestamp()
    };
  };

  document.getElementById('livePreviewSettingsBtn')?.addEventListener('click', () => {
    state.settings = collectSettingsForm();
    applySettingsToUI();
    showToast('Live preview applied across storefront! Click Save & Publish to persist.');
  });

  document.getElementById('adminSettingsForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const updated = collectSettingsForm();
    try {
      await setDoc(doc(db, 'settings', 'store'), updated);
      state.settings = updated;
      applySettingsToUI();
      showToast('All branding, logo & store settings saved and published!');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'settings/store');
    }
  });
}

function renderAdminReports(panel) {
  panel.innerHTML = `
    <div class="section-head">
      <h2 class="section-title">Reports & Data Export</h2>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-red" id="exportOrdersCsvBtn">⬇ Export Orders CSV</button>
        <button type="button" class="btn btn-outline" id="exportProductsCsvBtn">⬇ Export Inventory CSV</button>
        <button type="button" class="btn btn-black" onclick="window.print()">🖨️ Print Report</button>
      </div>
    </div>
    <div style="background:var(--bg-white);padding:20px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
      <h3 style="font-size:15px;font-weight:800;margin-bottom:10px;">Low Stock Alert Report (Stock ≤ 20)</h3>
      <table class="data-table">
        <thead><tr><th>SKU</th><th>Product</th><th>Category</th><th>Remaining Stock</th></tr></thead>
        <tbody>
          ${state.products.filter(p => p.stock <= 20).map(p => `
            <tr>
              <td><code>${escapeHtml(p.sku)}</code></td>
              <td><strong>${escapeHtml(p.name)}</strong></td>
              <td>${escapeHtml(p.category)}</td>
              <td class="tabular-nums" style="color:var(--danger);font-weight:800;">${p.stock}</td>
            </tr>
          `).join('') || `<tr><td colspan="4">All products are well stocked.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;

  document.getElementById('exportOrdersCsvBtn')?.addEventListener('click', () => {
    const rows = [
      ['OrderNumber', 'OrderID', 'Customer', 'Phone', 'Division', 'District', 'PaymentMethod', 'PaymentStatus', 'OrderStatus', 'GrandTotal'],
      ...state.orders.map(o => [
        o.orderNumber, o.id, o.customerName, o.customerPhone, o.division, o.district, o.paymentMethod, o.paymentStatus, o.orderStatus, o.grandTotal
      ])
    ];
    downloadCsv('store_bd_orders_report.csv', rows);
  });

  document.getElementById('exportProductsCsvBtn')?.addEventListener('click', () => {
    const rows = [
      ['ProductID', 'SKU', 'Name', 'Category', 'RegularPrice', 'DiscountPrice', 'Stock'],
      ...state.products.map(p => [p.id, p.sku, p.name, p.category, p.regularPrice, p.discountPrice, p.stock])
    ];
    downloadCsv('store_bd_inventory_report.csv', rows);
  });
}

function downloadCsv(filename, rows) {
  const csv = rows.map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}


export {
  renderAdminBanners,
  renderAdminCoupons,
  renderAdminReviews,
  renderAdminSettings,
  renderAdminReports,
  downloadCsv
};
