/**
 * Store BD Online — Product Catalog Filtering, Search & Sorting Service
 */

export interface ProductRecord {
  id: string;
  name: string;
  slug: string;
  description?: string;
  shortDescription?: string;
  category: string;
  brand?: string;
  sku: string;
  images: string[];
  regularPrice: number;
  discountPrice: number;
  stock: number;
  rating?: number;
  reviewCount?: number;
  featured: boolean;
  trending: boolean;
  bestseller: boolean;
  active: boolean;
  specs?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export function getEffectivePrice(product: Pick<ProductRecord, 'regularPrice' | 'discountPrice'>): number {
  const reg = Number(product.regularPrice) || 0;
  const disc = Number(product.discountPrice) || 0;
  return disc > 0 && disc < reg ? disc : reg;
}

export function getDiscountPercentage(product: Pick<ProductRecord, 'regularPrice' | 'discountPrice'>): number {
  const reg = Number(product.regularPrice) || 0;
  const disc = Number(product.discountPrice) || 0;
  if (reg <= 0 || disc <= 0 || disc >= reg) return 0;
  return Math.round(((reg - disc) / reg) * 100);
}

export function filterAndSortProducts(
  products: ProductRecord[],
  options: {
    category?: string;
    searchQuery?: string;
    minPrice?: number;
    maxPrice?: number;
    sortBy?: 'popular' | 'price-asc' | 'price-desc' | 'rating' | 'newest';
    includeInactive?: boolean;
  }
): ProductRecord[] {
  const category = (options.category || 'all').trim();
  const query = (options.searchQuery || '').trim().toLowerCase();
  const minPrice = typeof options.minPrice === 'number' ? options.minPrice : 0;
  const maxPrice = typeof options.maxPrice === 'number' ? options.maxPrice : Number.POSITIVE_INFINITY;

  const filtered = products.filter((p) => {
    if (!options.includeInactive && p.active === false) return false;
    if (category !== 'all' && p.category !== category) return false;

    const price = getEffectivePrice(p);
    if (price < minPrice || price > maxPrice) return false;

    if (query) {
      const hay = `${p.name} ${p.category} ${p.brand || ''} ${p.shortDescription || ''} ${p.sku || ''}`.toLowerCase();
      if (!hay.includes(query)) return false;
    }
    return true;
  });

  const sorted = [...filtered];
  switch (options.sortBy) {
    case 'price-asc':
      sorted.sort((a, b) => getEffectivePrice(a) - getEffectivePrice(b));
      break;
    case 'price-desc':
      sorted.sort((a, b) => getEffectivePrice(b) - getEffectivePrice(a));
      break;
    case 'rating':
      sorted.sort((a, b) => (Number(b.rating) || 0) - (Number(a.rating) || 0));
      break;
    default:
      break;
  }

  return sorted;
}
