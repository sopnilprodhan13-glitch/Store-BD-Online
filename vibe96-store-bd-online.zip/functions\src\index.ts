/**
 * Store BD Online — Firebase Cloud Functions (Gen 2)
 *
 * Implements:
 * 1. `requestPasswordResetOtp` — Generates a 6-digit numeric OTP, stores only its HMAC-SHA256
 *    in Firestore `/passwordResetChallenges/{emailHash}` (accessible exclusively by Admin SDK),
 *    and dispatches the branded HTML email via Resend / SMTP.
 * 2. `verifyPasswordResetOtp`  — Transactionally validates the 6-digit OTP (10-min expiry,
 *    max 5 attempts, constant-time HMAC check) and issues a single-use reset token.
 * 3. `completePasswordResetWithOtp` — Validates the single-use reset token, marks the challenge
 *    as used, and updates the user's password via `admin.auth().updateUser(uid, { password })`
 *    while preserving existing custom claims (including owner admin privileges).
 */

import crypto from 'crypto';
import { OtpService, OtpChallengeRecord, OtpChallengeStore } from '../../src/services/otpService';

/**
 * Firestore-backed OTP challenge adapter for Firebase Admin SDK.
 * Operates on the `/passwordResetChallenges` collection which is locked (`allow read, write: if false`)
 * to all client SDKs in `firestore.rules`.
 */
export class FirestoreAdminOtpChallengeStore implements OtpChallengeStore {
  private getCollection: () => {
    doc(id: string): {
      get(): Promise<{ exists: boolean; data(): Record<string, unknown> | undefined }>;
      set(data: Record<string, unknown>): Promise<unknown>;
      delete(): Promise<unknown>;
    };
  };

  constructor(
    firestoreInstance: {
      collection(name: string): ReturnType<FirestoreAdminOtpChallengeStore['getCollection']>;
    }
  ) {
    this.getCollection = () => firestoreInstance.collection('passwordResetChallenges');
  }

  async getByEmailHash(emailHash: string): Promise<OtpChallengeRecord | null> {
    const snap = await this.getCollection().doc(emailHash).get();
    if (!snap.exists) return null;
    const d = snap.data() || {};
    return {
      id: String(d.id || emailHash),
      emailHash: String(d.emailHash || emailHash),
      otpHmac: String(d.otpHmac || ''),
      attempts: Number(d.attempts || 0),
      maxAttempts: Number(d.maxAttempts || 5),
      used: Boolean(d.used),
      verifiedTokenHmac: typeof d.verifiedTokenHmac === 'string' ? d.verifiedTokenHmac : null,
      expiresAtMs: Number(d.expiresAtMs || 0),
      cooldownUntilMs: Number(d.cooldownUntilMs || 0),
      createdAtMs: Number(d.createdAtMs || 0),
      updatedAtMs: Number(d.updatedAtMs || 0),
    };
  }

  async save(record: OtpChallengeRecord): Promise<void> {
    await this.getCollection()
      .doc(record.emailHash)
      .set({
        ...record,
        expiresAt: new Date(record.expiresAtMs).toISOString(),
        cooldownUntil: new Date(record.cooldownUntilMs).toISOString(),
        createdAt: new Date(record.createdAtMs).toISOString(),
        updatedAt: new Date(record.updatedAtMs).toISOString(),
      });
  }

  async deleteByEmailHash(emailHash: string): Promise<void> {
    await this.getCollection().doc(emailHash).delete();
  }
}

export function createCloudFunctionsOtpService(
  firestoreInstance: {
    collection(name: string): ReturnType<FirestoreAdminOtpChallengeStore['getCollection']>;
  },
  otpSecret?: string
): OtpService {
  const store = new FirestoreAdminOtpChallengeStore(firestoreInstance);
  return new OtpService(
    store,
    otpSecret || process.env.OTP_HASH_SECRET || crypto.randomBytes(32).toString('hex')
  );
}
