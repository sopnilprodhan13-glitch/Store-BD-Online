# Payment Methods & Manual Verification Setup (`PAYMENT_SETUP.md`)

**Store BD Online** supports the three primary payment methods used by Bangladesh e-commerce customers:
1. **Cash on Delivery (COD)**
2. **bKash** (Manual Transaction Verification)
3. **Nagad** (Manual Transaction Verification)

---

## 1. Safe Default Configuration

Out of the box, the store is configured with safe placeholders so no real customer funds are sent to an unverified number before setup:
- **bKash Number**: `Not configured`
- **Nagad Number**: `Not configured`

When a payment number is set to `"Not configured"`, the checkout page displays a clear amber notice instructing the customer to select **Cash on Delivery** or contact WhatsApp support until the store owner configures the merchant/personal number.

---

## 2. Configuring bKash & Nagad Numbers in Admin

1. Sign in as the Owner Admin (`sopnilprodhan13@gmail.com`).
2. Navigate to **Admin Dashboard → 🎨 Website Branding & Customization → D. Payment Methods & Manual Verification Settings**.
3. Update:
   - **bKash Number** (e.g. `017XXXXXXXX`)
   - **Nagad Number** (e.g. `018XXXXXXXX`)
   - **Payment Account Type** (`Personal` or `Merchant`)
   - **Checkout Payment Instructions**
   - Enable/Disable checkboxes for **Cash on Delivery**, **bKash**, and **Nagad**.
4. Click **Save & Publish Branding Changes**.

---

## 3. Customer Checkout & Manual Verification Workflow

1. When a customer selects **bKash** or **Nagad** at checkout, they are required to enter:
   - **Sender Mobile Number** (validated 11-digit BD mobile number `01XXXXXXXXX`)
   - **Transaction ID (`TrxID`)** (validated alphanumeric code)
2. The order is created with:
   - `orderStatus`: `"Order Placed"`
   - `paymentStatus`: `"Pending Verification"`
3. **Security Enforcement**: Customers can never set `paymentStatus` to `"Paid"` or `"Verified"` from the browser. `firestore.rules` enforces `paymentStatus == "Pending Verification"` on creation.
4. **Owner Verification**: In **Admin Dashboard → 🧾 Order Management**, the Owner Admin inspects the customer's Sender Number and `TrxID` against their bKash/Nagad statement and updates the payment status to **Paid / Verified** (or **Rejected**) and advances the order status (`Order Confirmed` → `Processing` → `Packed` → `Shipped` → `Delivered`).
