# AGENTS.md — Architectural & Security Invariants for Store BD Online

This document defines the engineering rules, file layout, and security invariants that human developers and coding agents must preserve when maintaining **Store BD Online**.

---

## 1. Product Positioning

- **Single-Store E-Commerce Platform**: Store BD Online is a complete single-store e-commerce application designed for one store owner's business and brand.
- **No Multi-Tenant / Reseller Framing**: Never add multi-vendor marketplace, SaaS subscription billing, or reseller kit UI.

---

## 2. Mandatory Security Invariants

1. **Zero Client-Side Password Storage**:
   - Never store plaintext passwords or password hashes in `localStorage`, `sessionStorage`, or Firestore documents.
   - All customer authentication is handled by **Firebase Authentication**.
2. **Registration Before Login**:
   - Login (`signInWithEmailAndPassword`) must never auto-create a user account.
   - Unregistered login attempts must return `"Account not found. Please create an account first."`
3. **Server-Backed 6-Digit Email OTP Password Reset**:
   - OTP codes must be generated on the server using `crypto.randomInt(100000, 1000000)`.
   - Only a keyed `HMAC-SHA256` digest (`otpHmac`) may be stored in `/passwordResetChallenges` or memory.
   - Enforce: 10-minute expiration, 60-second resend cooldown, max 5 failed verification attempts, single-use replay prevention, and constant-time comparison (`crypto.timingSafeEqual`).
   - Never log OTP codes to stdout/stderr or return OTP codes in HTTP responses.
   - If the email provider (`RESEND_API_KEY` or `SMTP_RELAY_URL`) is not configured, return `503 EMAIL_PROVIDER_NOT_CONFIGURED` honestly — never fake email delivery.
4. **Owner Admin Access Control**:
   - Only `sopnilprodhan13@gmail.com` with `email_verified == true` is granted Owner Admin access.
   - Both `firestore.rules` and `storage.rules` enforce this check on every privileged write.

---

## 3. Codebase Structure

- `index.html`: Responsive storefront, customer account portal, 5-step OTP modal, and Owner Admin Dashboard.
- `server.ts`: Express server providing `/api/health`, `/api/auth/otp/request`, `/api/auth/otp/verify`, `/api/auth/otp/reset-password`, and `/api/orders/validate`.
- `src/services/otpService.ts`: Cryptographic 6-digit OTP generation, HMAC hashing, rate limiting, cooldowns, and lockout logic.
- `src/services/emailProvider.ts`: Resend and SMTP relay email adapter with branded HTML template.
- `src/admin/brandingService.ts`: Logo file validation (`PNG`, `JPG`, `JPEG`, `WebP`, `<= 5MB`), transparent PNG support, and WhatsApp link builder.
- `src/orders/orderService.ts` & `src/payments/paymentService.ts`: Authoritative order total calculation, coupon validation, and manual payment status rules.
- `tests/storebd.test.ts`: Automated test suite verifying auth, OTP lifecycle, branding validation, order math, and security rules.
