import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword,
  updateProfile,
  signOut
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  initializeFirestore,
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  writeBatch,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js';

// =========================================================================
// 7. STOREFRONT RENDERING (HEADER, HERO, CATEGORIES, PRODUCTS)
// =========================================================================
function formatBrandHtml(name) {
  const safe = escapeHtml(name || 'STORE BD ONLINE');
  return safe.replace(/\bBD\b/g, '<span class="bd-accent">BD</span>');
}

function getWhatsAppUrl(customMsg = '') {
  const rawCountry = (state.settings.whatsappCountryCode || '+880').replace(/[^0-9]/g, '');
  const rawNum = (state.settings.whatsappNumber || DEFAULT_SETTINGS.whatsappNumber || '').replace(/[^0-9]/g, '');
  let phone = rawNum || '8801700000000';
  if (rawCountry && !phone.startsWith(rawCountry) && phone.startsWith('0')) {
    phone = rawCountry + phone.slice(1);
  }
  const msg = customMsg || state.settings.whatsappDefaultMessage || DEFAULT_SETTINGS.whatsappDefaultMessage;
  return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
}

function applySettingsToUI() {
  const s = state.settings;
  const siteName = s.siteName || DEFAULT_SETTINGS.siteName;
  const tagline = s.tagline || DEFAULT_SETTINGS.tagline;

  document.title = s.seoTitle || `${siteName} — ${tagline}`;
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc && s.seoDescription) metaDesc.setAttribute('content', s.seoDescription);
  const ogTitle = document.querySelector('meta[property="og:title"]');
  if (ogTitle) ogTitle.setAttribute('content', s.seoTitle || `${siteName} — ${tagline}`);
  const ogDesc = document.querySelector('meta[property="og:description"]');
  if (ogDesc && s.seoDescription) ogDesc.setAttribute('content', s.seoDescription);

  const promoBrand = document.getElementById('promoBarBrand');
  if (promoBrand) promoBrand.textContent = siteName;
  document.getElementById('promoBarText').textContent = s.promoBarText || DEFAULT_SETTINGS.promoBarText;

  ['headerSiteName', 'footerSiteName', 'drawerSiteName'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = formatBrandHtml(siteName);
  });
  ['headerTagline', 'footerTagline', 'drawerTagline'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = tagline;
  });

  document.getElementById('footerAboutText').textContent = s.footerAbout || DEFAULT_SETTINGS.footerAbout;
  document.getElementById('footerEmail').textContent = s.supportEmail || DEFAULT_SETTINGS.supportEmail;
  document.getElementById('footerWhatsapp').textContent = s.whatsappNumber || s.contactPhone || DEFAULT_SETTINGS.whatsappNumber;
  document.getElementById('footerAddress').textContent = s.address || DEFAULT_SETTINGS.address;

  const copyEl = document.getElementById('footerCopyrightText');
  if (copyEl) copyEl.textContent = s.copyrightText || `${siteName}. All Rights Reserved.`;

  const delivSub = document.getElementById('trustDeliverySubtext');
  if (delivSub && s.estimatedDeliveryMessage) delivSub.textContent = s.estimatedDeliveryMessage;

  // Dynamic CSS Colors
  const root = document.documentElement;
  if (s.primaryColor) root.style.setProperty('--brand-red', s.primaryColor);
  if (s.secondaryColor) root.style.setProperty('--brand-yellow', s.secondaryColor);
  if (s.buttonColor) root.style.setProperty('--brand-btn', s.buttonColor);
  if (s.headerBgColor) {
    const hdr = document.getElementById('siteHeaderEl');
    if (hdr) hdr.style.background = s.headerBgColor;
  }
  if (s.footerBgColor) {
    const ftr = document.getElementById('siteFooterEl');
    if (ftr) ftr.style.background = s.footerBgColor;
  }

  // Dynamic Logo & Favicon across all 9 locations (supports Transparent PNG without forced box)
  const activeLogo = s.logoUrl === 'NONE'
    ? ''
    : (s.logoUrl && s.logoUrl !== DEFAULT_SETTINGS.logoUrl ? s.logoUrl : (state.transparentLogoDataUrl || DEFAULT_SETTINGS.logoUrl));
  document.querySelectorAll('.brand-logo-img').forEach(img => {
    if (!activeLogo) {
      img.style.display = 'none';
      if (img.parentElement?.classList.contains('brand-logo-wrap')) {
        img.parentElement.style.display = 'none';
      }
    } else {
      img.style.display = 'block';
      img.src = activeLogo;
      if (img.parentElement?.classList.contains('brand-logo-wrap')) {
        img.parentElement.style.display = 'flex';
        img.parentElement.style.background = 'transparent';
      }
    }
  });

  const favHref = s.faviconUrl || (activeLogo || DEFAULT_SETTINGS.faviconUrl);
  if (favHref) {
    let fav = document.querySelector('link[rel="icon"]');
    if (!fav) {
      fav = document.createElement('link');
      fav.rel = 'icon';
      document.head.appendChild(fav);
    }
    fav.href = favHref;
  }

  // Facebook & WhatsApp buttons
  const fb = document.getElementById('footerFbLink');
  if (fb) {
    fb.href = s.facebookUrl || DEFAULT_SETTINGS.facebookUrl;
    fb.textContent = s.facebookPageName || 'Facebook';
    fb.style.display = s.enableFacebookButton === false ? 'none' : 'inline-flex';
  }
  const wa = document.getElementById('footerWaLink');
  if (wa) {
    wa.href = getWhatsAppUrl();
  }
  const floatWa = document.getElementById('floatingWhatsappBtn');
  if (floatWa) {
    floatWa.href = getWhatsAppUrl();
    floatWa.style.display = s.enableFloatingWhatsapp === false ? 'none' : 'inline-flex';
  }
}

function updateCountersUI() {
  const totalCartQty = state.cart.reduce((sum, item) => sum + item.qty, 0);
  document.getElementById('cartCountBadge').textContent = totalCartQty;
  document.getElementById('drawerCartCount').textContent = totalCartQty;

  const wishCount = state.wishlist.length;
  document.getElementById('wishlistCountBadge').textContent = wishCount;
  document.getElementById('desktopWishlistCount').textContent = wishCount;

  const unreadNotifs = state.notifications.filter(n => !n.read).length;
  document.getElementById('notifCountBadge').textContent = unreadNotifs;
}

function renderHeroSlider() {
  const heroBanners = state.banners.filter(b => b.type === 'hero' && b.active !== false);
  const slidesContainer = document.getElementById('heroSlidesContainer');
  const dotsContainer = document.getElementById('heroDotsContainer');
  if (!slidesContainer || !dotsContainer) return;

  if (heroBanners.length === 0) {
    slidesContainer.innerHTML = '';
    dotsContainer.innerHTML = '';
    return;
  }

  if (state.heroIndex >= heroBanners.length) state.heroIndex = 0;

  slidesContainer.innerHTML = heroBanners.map((b, idx) => `
    <div class="hero-slide ${idx === state.heroIndex ? 'active' : ''}" data-slide-index="${idx}">
      <div class="hero-content">
        <div class="hero-kicker">${escapeHtml(b.badge || 'TRENDING GADGETS')}</div>
        <h2 class="hero-heading">
          ${escapeHtml(b.heading)}
          <span class="highlight">${escapeHtml(b.highlight || '')}</span>
        </h2>
        <p class="hero-desc">${escapeHtml(b.description || '')}</p>
        <div class="hero-btn-group">
          <button type="button" class="btn-primary-pill" data-nav="deals">
            <span>EXPLORE DEALS</span>
            <span class="arrow-circle">→</span>
          </button>
          <button type="button" class="btn-yellow-pill" data-nav="shop">
            <span>SHOP NOW</span>
          </button>
        </div>
      </div>
      <div class="hero-media">
        <img src="${escapeHtml(b.image)}" alt="${escapeHtml(b.heading)}" referrerpolicy="no-referrer" loading="eager" />
      </div>
    </div>
  `).join('');

  dotsContainer.innerHTML = heroBanners.map((_, idx) => `
    <button type="button" class="hero-dot ${idx === state.heroIndex ? 'active' : ''}" data-hero-dot="${idx}" aria-label="Slide ${idx + 1}"></button>
  `).join('');

  if (state.heroTimer) clearInterval(state.heroTimer);
  state.heroTimer = setInterval(() => {
    const count = heroBanners.length;
    if (count > 1) {
      state.heroIndex = (state.heroIndex + 1) % count;
      updateActiveHeroSlide();
    }
  }, 5000);
}

function updateActiveHeroSlide() {
  document.querySelectorAll('#heroSlidesContainer .hero-slide').forEach((el, idx) => {
    el.classList.toggle('active', idx === state.heroIndex);
  });
  document.querySelectorAll('#heroDotsContainer .hero-dot').forEach((el, idx) => {
    el.classList.toggle('active', idx === state.heroIndex);
  });
}

function renderPromoBanner() {
  const promoSec = document.getElementById('promoBannerSection');
  if (!promoSec) return;
  const promo = state.banners.find(b => b.type === 'promo' && b.active !== false) || DEFAULT_BANNERS[2];
  promoSec.innerHTML = `
    <div class="promo-banner-card">
      <div>
        <div class="promo-kicker">${escapeHtml(promo.badge || 'LIMITED TIME OFFER')}</div>
        <h2 class="promo-heading">
          ${escapeHtml(promo.heading)}
        </h2>
        <p class="promo-desc">${escapeHtml(promo.description || '')}</p>
        <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
          <button type="button" class="btn-primary-pill" data-nav="${escapeHtml(promo.buttonDest || 'deals')}">
            <span>${escapeHtml(promo.buttonText || 'EXPLORE DEALS')}</span>
            <span class="arrow-circle">→</span>
          </button>
          <div class="promo-save-badge">
            <span>SAVE</span>
            <span>BIG</span>
          </div>
        </div>
      </div>
      <div class="hero-media">
        <img src="${escapeHtml(promo.image)}" alt="${escapeHtml(promo.heading)}" referrerpolicy="no-referrer" loading="lazy" />
      </div>
    </div>
  `;
}

function renderCategoriesUI() {
  const activeCats = state.categories.filter(c => c.active !== false);
  const strip = document.getElementById('homeCategoriesStrip');
  if (strip) {
    strip.innerHTML = activeCats.map(c => `
      <button type="button" class="category-circle-item ${state.selectedCategory === c.name ? 'active' : ''}" data-category-filter="${escapeHtml(c.name)}">
        <div class="category-circle-icon">
          ${c.image
            ? `<img src="${escapeHtml(c.image)}" alt="${escapeHtml(c.name)}" style="width:32px;height:32px;object-fit:contain;" referrerpolicy="no-referrer" />`
            : `<i data-lucide="${escapeHtml(c.icon || 'box')}" style="width:24px;height:24px;"></i>`
          }
        </div>
        <span class="category-circle-label">${escapeHtml(c.name)}</span>
      </button>
    `).join('');
  }

  const shopSelect = document.getElementById('shopCategorySelect');
  if (shopSelect) {
    shopSelect.innerHTML = `<option value="all">All Categories</option>` +
      activeCats.map(c => `<option value="${escapeHtml(c.name)}" ${state.selectedCategory === c.name ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('');
  }

  const drawerCats = document.getElementById('mobileDrawerCategories');
  if (drawerCats) {
    drawerCats.innerHTML = activeCats.map(c => `
      <button type="button" class="admin-nav-btn" style="color:var(--text-primary);font-size:13px;" data-category-filter="${escapeHtml(c.name)}">
        • ${escapeHtml(c.name)}
      </button>
    `).join('');
  }
  refreshIcons();
}

function createProductCardHTML(p) {
  const inWish = state.wishlist.includes(p.id);
  const price = p.discountPrice && p.discountPrice < p.regularPrice ? p.discountPrice : p.regularPrice;
  const hasDiscount = p.discountPrice && p.discountPrice < p.regularPrice;
  const badgeType = p.bestseller ? 'bestseller' : (p.trending ? 'trending' : 'popular');
  const badgeLabel = p.bestseller ? 'BESTSELLER' : (p.trending ? 'TRENDING' : 'POPULAR');
  const imgUrl = (Array.isArray(p.images) && p.images[0]) ? p.images[0] : '/assets/images/prod_charging_station_1794737029320.jpg';

  return `
    <article class="product-card" data-product-card="${escapeHtml(p.id)}">
      <div class="product-card-top" data-open-product="${escapeHtml(p.id)}">
        <span class="product-tag ${badgeType}">${badgeLabel}</span>
        <button type="button" class="wishlist-icon-btn ${inWish ? 'active' : ''}" data-toggle-wishlist="${escapeHtml(p.id)}" aria-label="Toggle wishlist">
          <i data-lucide="heart" style="width:16px;height:16px;${inWish ? 'fill:currentColor;' : ''}"></i>
        </button>
        <img src="${escapeHtml(imgUrl)}" alt="${escapeHtml(p.name)}" loading="lazy" referrerpolicy="no-referrer" />
      </div>
      <h3 class="product-card-title" data-open-product="${escapeHtml(p.id)}">${escapeHtml(p.name)}</h3>
      <div class="product-rating-row">
        <span style="color:#F59E0B;">★</span>
        <span class="tabular-nums" style="font-weight:700;color:var(--text-primary);">${Number(p.rating || 4.8).toFixed(1)}</span>
        <span class="tabular-nums">(${Number(p.reviewCount || 42)}+)</span>
      </div>
      <div class="product-price-Action-row">
        <div class="price-stack">
          <span class="price-current">${formatPrice(price)}</span>
          ${hasDiscount ? `<span class="price-old">${formatPrice(p.regularPrice)}</span>` : ''}
        </div>
        <button type="button" class="cart-fab-btn" data-add-cart="${escapeHtml(p.id)}" aria-label="Add ${escapeHtml(p.name)} to cart" ${p.stock <= 0 ? 'disabled title="Out of Stock"' : ''}>
          <i data-lucide="shopping-cart" style="width:17px;height:17px;"></i>
        </button>
      </div>
    </article>
  `;
}

function renderAllProductGrids() {
  const activeProducts = state.products.filter(p => p.active !== false);

  // 1. Trending Grid
  const trendingGrid = document.getElementById('trendingProductsGrid');
  if (trendingGrid) {
    const trendingList = activeProducts.filter(p => p.trending || p.bestseller).slice(0, 4);
    trendingGrid.innerHTML = (trendingList.length ? trendingList : activeProducts.slice(0, 4))
      .map(createProductCardHTML)
      .join('');
  }

  // 2. Featured Collection Tabs Grid
  renderFeaturedCollectionTabGrid();

  // 3. Recently Viewed Grid
  const recentBlock = document.getElementById('recentlyViewedBlock');
  const recentGrid = document.getElementById('recentlyViewedGrid');
  if (recentBlock && recentGrid) {
    const recentItems = state.recentlyViewed
      .map(id => activeProducts.find(p => p.id === id))
      .filter(Boolean)
      .slice(0, 4);
    if (recentItems.length > 0) {
      recentBlock.style.display = 'block';
      recentGrid.innerHTML = recentItems.map(createProductCardHTML).join('');
    } else {
      recentBlock.style.display = 'none';
    }
  }

  // 4. Shop View Grid
  renderShopGrid();

  // 5. Wishlist Grid
  renderWishlistGrid();

  refreshIcons();
}

function renderFeaturedCollectionTabGrid() {
  const grid = document.getElementById('featuredProductsGrid');
  if (!grid) return;
  const activeProducts = state.products.filter(p => p.active !== false);
  let list = [...activeProducts];
  if (state.selectedCollectionTab === 'bestseller') {
    list = activeProducts.filter(p => p.bestseller);
  } else if (state.selectedCollectionTab === 'new') {
    list = [...activeProducts].reverse();
  } else if (state.selectedCollectionTab === 'popular') {
    list = [...activeProducts].sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
  } else if (state.selectedCollectionTab === 'recommended') {
    list = activeProducts.filter(p => p.featured);
  } else if (state.selectedCollectionTab === 'offers') {
    list = activeProducts.filter(p => p.discountPrice < p.regularPrice);
  }
  if (list.length === 0) list = activeProducts;
  grid.innerHTML = list.slice(0, 4).map(createProductCardHTML).join('');
  refreshIcons();
}

function renderShopGrid() {
  const grid = document.getElementById('shopProductsGrid');
  const heading = document.getElementById('shopViewHeading');
  const countText = document.getElementById('shopResultCountText');
  if (!grid) return;

  let list = state.products.filter(p => p.active !== false);

  if (state.selectedCategory && state.selectedCategory !== 'all') {
    list = list.filter(p => p.category.toLowerCase() === state.selectedCategory.toLowerCase());
  }

  if (state.searchQuery.trim()) {
    const q = state.searchQuery.trim().toLowerCase();
    list = list.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      (p.brand || '').toLowerCase().includes(q) ||
      (p.description || '').toLowerCase().includes(q)
    );
  }

  if (state.sortBy === 'price-asc') {
    list.sort((a, b) => (a.discountPrice || a.regularPrice) - (b.discountPrice || b.regularPrice));
  } else if (state.sortBy === 'price-desc') {
    list.sort((a, b) => (b.discountPrice || b.regularPrice) - (a.discountPrice || a.regularPrice));
  } else if (state.sortBy === 'rating') {
    list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  }

  if (heading) {
    heading.textContent = state.searchQuery.trim()
      ? `Search Results for "${state.searchQuery.trim()}"`
      : (state.selectedCategory !== 'all' ? state.selectedCategory : 'All Products');
  }
  if (countText) {
    countText.textContent = `Showing ${list.length} product${list.length === 1 ? '' : 's'}`;
  }

  if (list.length === 0) {
    grid.innerHTML = `
      <div style="grid-column:1/-1;background:var(--bg-white);padding:36px;border-radius:var(--radius-md);text-align:center;border:1px solid var(--border-light);">
        <p style="font-weight:700;font-size:16px;margin-bottom:6px;">No matching products found</p>
        <p style="font-size:13px;color:var(--text-secondary);margin-bottom:14px;">Try clearing your search filter or exploring all categories.</p>
        <button type="button" class="btn btn-red" id="resetShopFiltersBtn">Reset Filters</button>
      </div>
    `;
  } else {
    grid.innerHTML = list.map(createProductCardHTML).join('');
  }
  refreshIcons();
}

function renderWishlistGrid() {
  const grid = document.getElementById('wishlistProductsGrid');
  if (!grid) return;
  const items = state.products.filter(p => state.wishlist.includes(p.id));
  if (items.length === 0) {
    grid.innerHTML = `
      <div style="grid-column:1/-1;background:var(--bg-white);padding:36px;border-radius:var(--radius-md);text-align:center;border:1px solid var(--border-light);">
        <p style="font-weight:700;font-size:16px;margin-bottom:6px;">Your wishlist is empty</p>
        <p style="font-size:13px;color:var(--text-secondary);margin-bottom:14px;">Tap the heart icon on any gadget to save it here for later.</p>
        <button type="button" class="btn btn-red" data-nav="shop">Browse Gadgets</button>
      </div>
    `;
  } else {
    grid.innerHTML = items.map(createProductCardHTML).join('');
  }
  refreshIcons();
}

// =========================================================================
// 8. PRODUCT DETAILS VIEW (Gallery, Zoom, Reviews, Related Products)
// =========================================================================
function openProductDetail(productId) {
  state.activeProductId = productId;
  state.recentlyViewed = [productId, ...state.recentlyViewed.filter(id => id !== productId)].slice(0, 8);
  localStorage.setItem('sbd_recent', JSON.stringify(state.recentlyViewed));
  renderProductDetailView(productId);
  switchView('product');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderProductDetailView(productId) {
  const container = document.getElementById('productDetailContainer');
  const p = state.products.find(item => item.id === productId);
  if (!container || !p) return;

  const images = Array.isArray(p.images) && p.images.length > 0
    ? p.images
    : ['/assets/images/prod_charging_station_1794737029320.jpg'];
  const price = p.discountPrice && p.discountPrice < p.regularPrice ? p.discountPrice : p.regularPrice;
  const saveAmount = p.regularPrice - price;
  const inWish = state.wishlist.includes(p.id);
  const prodReviews = state.reviews.filter(r => r.productId === p.id && r.status === 'approved');
  const related = state.products.filter(item => item.id !== p.id && item.category === p.category).slice(0, 4);

  container.innerHTML = `
    <div style="margin-bottom:14px;">
      <button type="button" class="btn btn-outline" data-nav="shop" style="padding:7px 14px;font-size:12.5px;">← Back to Catalog</button>
    </div>
    <div style="display:grid;grid-template-columns:1fr;gap:24px;background:var(--bg-white);padding:20px;border-radius:var(--radius-lg);border:1px solid var(--border-light);" class="pdp-split-grid">
      <div>
        <div style="position:relative;border-radius:var(--radius-md);overflow:hidden;background:#F9FAFB;aspect-ratio:1/1;border:1px solid var(--border-subtle);">
          <img id="pdpMainImage" src="${escapeHtml(images[0])}" alt="${escapeHtml(p.name)}" style="width:100%;height:100%;object-fit:contain;transition:transform 250ms ease;cursor:zoom-in;" referrerpolicy="no-referrer" />
        </div>
        <div style="display:flex;gap:10px;margin-top:12px;overflow-x:auto;">
          ${images.map((img, i) => `
            <button type="button" class="pdp-thumb-btn" data-pdp-thumb="${escapeHtml(img)}" style="width:64px;height:64px;border-radius:8px;overflow:hidden;border:2px solid ${i === 0 ? 'var(--brand-red)' : 'var(--border-light)'};flex-shrink:0;">
              <img src="${escapeHtml(img)}" alt="Thumbnail ${i + 1}" style="width:100%;height:100%;object-fit:cover;" referrerpolicy="no-referrer" />
            </button>
          `).join('')}
        </div>
      </div>

      <div style="display:flex;flex-direction:column;">
        <div style="font-size:12px;font-weight:700;color:var(--brand-red);text-transform:uppercase;letter-spacing:0.06em;">
          ${escapeHtml(p.category)} · SKU: ${escapeHtml(p.sku || 'SBD-01')}
        </div>
        <h1 style="font-size:clamp(1.3rem,2.6vw,1.85rem);font-weight:800;margin:6px 0 8px;line-height:1.25;">${escapeHtml(p.name)}</h1>

        <div style="display:flex;align-items:center;gap:12px;font-size:13px;color:var(--text-secondary);margin-bottom:14px;">
          <span><strong style="color:#F59E0B;">★ ${Number(p.rating || 4.8).toFixed(1)}</strong> (${Number(p.reviewCount || 40)} reviews)</span>
          <span>·</span>
          <span style="font-weight:700;color:${p.stock > 0 ? 'var(--success)' : 'var(--danger)'};">
            ${p.stock > 0 ? `In Stock (${p.stock} available)` : 'Out of Stock'}
          </span>
        </div>

        <div style="background:var(--bg-light);padding:14px 16px;border-radius:var(--radius-md);display:flex;align-items:baseline;gap:12px;margin-bottom:16px;">
          <span style="font-size:26px;font-weight:800;color:var(--brand-red);" class="tabular-nums">${formatPrice(price)}</span>
          ${saveAmount > 0 ? `
            <span style="font-size:15px;color:var(--text-muted);text-decoration:line-through;" class="tabular-nums">${formatPrice(p.regularPrice)}</span>
            <span style="font-size:12px;font-weight:700;background:var(--brand-yellow);color:var(--brand-black);padding:3px 8px;border-radius:6px;">Save ${formatPrice(saveAmount)}</span>
          ` : ''}
        </div>

        <p style="font-size:14px;color:var(--text-secondary);margin-bottom:16px;">${escapeHtml(p.shortDescription || p.description || '')}</p>

        ${p.specs ? `
          <div style="margin-bottom:18px;padding:12px;border-radius:var(--radius-sm);border:1px solid var(--border-light);font-size:13px;">
            <div style="font-weight:700;margin-bottom:4px;">Technical Specifications:</div>
            <div style="color:var(--text-secondary);">${escapeHtml(p.specs)}</div>
          </div>
        ` : ''}

        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
          <div style="display:inline-flex;align-items:center;border:1.5px solid var(--border-light);border-radius:var(--radius-sm);">
            <button type="button" id="pdpQtyMinus" style="width:38px;height:42px;font-weight:800;">−</button>
            <input type="number" id="pdpQtyInput" value="1" min="1" max="${Math.max(1, p.stock)}" style="width:48px;height:42px;text-align:center;border:none;font-weight:700;" class="tabular-nums" />
            <button type="button" id="pdpQtyPlus" style="width:38px;height:42px;font-weight:800;">+</button>
          </div>
          <button type="button" class="btn btn-red" id="pdpAddToCartBtn" style="flex:1;min-width:140px;height:44px;" ${p.stock <= 0 ? 'disabled' : ''}>
            Add to Cart
          </button>
          <button type="button" class="btn btn-black" id="pdpBuyNowBtn" style="flex:1;min-width:140px;height:44px;" ${p.stock <= 0 ? 'disabled' : ''}>
            Buy Now
          </button>
          <button type="button" class="btn btn-outline" data-toggle-wishlist="${escapeHtml(p.id)}" style="height:44px;">
            ${inWish ? '♥ Saved' : '♡ Wishlist'}
          </button>
        </div>

        <div style="margin-bottom:14px;">
          <a href="${escapeHtml(getWhatsAppUrl(`Hello ${state.settings.siteName || 'STORE BD ONLINE'}, I would like to ask about "${p.name}" (SKU: ${p.sku || 'SBD-01'}, Price: ${formatPrice(price)}).`))}" target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="width:100%;border-color:#25D366;color:#128C7E;font-weight:700;">
            💬 Ask About Product on WhatsApp (${escapeHtml(state.settings.whatsappSupportStatus || 'Online')})
          </a>
        </div>

        <div style="font-size:12.5px;color:var(--text-secondary);border-top:1px solid var(--border-light);padding-top:12px;display:flex;flex-direction:column;gap:4px;">
          <div>✓ Delivery Inside City: ${formatPrice(state.settings.insideDhakaFee)} · Outside City: ${formatPrice(state.settings.outsideDhakaFee)}</div>
          <div>✓ Free Delivery on Orders Over: ${formatPrice(state.settings.freeDeliveryThreshold)}</div>
          <div>✓ Estimated Delivery: ${escapeHtml(state.settings.estimatedDeliveryMessage || 'Inside City: 24–48 Hours • Outside City: 2–4 Days')}</div>
          <div>✓ Payment: Cash on Delivery, bKash (${escapeHtml(state.settings.bkashNumber)}), Nagad (${escapeHtml(state.settings.nagadNumber)})</div>
        </div>
      </div>
    </div>

    <!-- Product Description & Verified Customer Reviews -->
    <div style="display:grid;grid-template-columns:1fr;gap:20px;margin-top:24px;">
      <div style="background:var(--bg-white);padding:20px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h3 style="font-size:16px;font-weight:800;margin-bottom:8px;">Product Overview</h3>
        <p style="font-size:14px;color:var(--text-secondary);line-height:1.65;">${escapeHtml(p.description || p.shortDescription || '')}</p>
      </div>

      <div style="background:var(--bg-white);padding:20px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:14px;">
          <h3 style="font-size:16px;font-weight:800;">Customer Reviews (${prodReviews.length})</h3>
          <button type="button" class="btn btn-outline" id="openWriteReviewBtn" data-review-product="${escapeHtml(p.id)}">Write a Review</button>
        </div>
        <div id="pdpReviewsList" style="display:flex;flex-direction:column;gap:12px;">
          ${prodReviews.length === 0 ? `
            <p style="font-size:13.5px;color:var(--text-secondary);">No written reviews yet. Be the first verified customer to review this product!</p>
          ` : prodReviews.map(r => `
            <div style="padding:12px;border-radius:var(--radius-sm);background:var(--bg-light);">
              <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:4px;">
                <div>
                  <strong style="font-size:13.5px;">${escapeHtml(r.userName)}</strong>
                  ${r.verifiedPurchase ? `<span style="font-size:11px;color:var(--success);font-weight:700;margin-left:6px;">✓ Verified Purchase</span>` : ''}
                </div>
                <span style="color:#F59E0B;font-weight:700;">${'★'.repeat(Math.min(5, Math.max(1, r.rating || 5)))}</span>
              </div>
              <p style="font-size:13px;color:var(--text-secondary);">${escapeHtml(r.comment)}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </div>

    ${related.length > 0 ? `
      <div style="margin-top:28px;">
        <h3 class="section-title" style="margin-bottom:14px;">Related Products</h3>
        <div class="product-grid">${related.map(createProductCardHTML).join('')}</div>
      </div>
    ` : ''}
  `;

  // Responsive 2-column PDP styling
  const splitGrid = container.querySelector('.pdp-split-grid');
  if (splitGrid && window.innerWidth >= 768) {
    splitGrid.style.gridTemplateColumns = '1fr 1.15fr';
  }

  // Wire image zoom & thumbnails
  const mainImg = document.getElementById('pdpMainImage');
  if (mainImg) {
    mainImg.addEventListener('click', () => {
      mainImg.style.transform = mainImg.style.transform === 'scale(1.5)' ? 'scale(1)' : 'scale(1.5)';
    });
  }
  container.querySelectorAll('[data-pdp-thumb]').forEach(btn => {
    btn.addEventListener('click', () => {
      if (mainImg) mainImg.src = btn.getAttribute('data-pdp-thumb');
    });
  });

  // Quantity steppers
  const qtyInput = document.getElementById('pdpQtyInput');
  document.getElementById('pdpQtyMinus')?.addEventListener('click', () => {
    qtyInput.value = Math.max(1, (parseInt(qtyInput.value, 10) || 1) - 1);
  });
  document.getElementById('pdpQtyPlus')?.addEventListener('click', () => {
    qtyInput.value = Math.min(Math.max(1, p.stock), (parseInt(qtyInput.value, 10) || 1) + 1);
  });

  document.getElementById('pdpAddToCartBtn')?.addEventListener('click', () => {
    const q = Math.max(1, parseInt(qtyInput.value, 10) || 1);
    addToCart(p.id, q);
  });
  document.getElementById('pdpBuyNowBtn')?.addEventListener('click', () => {
    const q = Math.max(1, parseInt(qtyInput.value, 10) || 1);
    addToCart(p.id, q, false);
    if (!state.currentUser) {
      showToast('Please sign in or create an account to order.');
      openAuthModal('login');
      return;
    }
    switchView('checkout');
  });
  document.getElementById('openWriteReviewBtn')?.addEventListener('click', () => {
    openReviewModal(p);
  });

  refreshIcons();
}
// =========================================================================
// 9. WISHLIST & VERIFIED-PURCHASE REVIEWS
// =========================================================================
async function toggleWishlist(productId) {
  const idx = state.wishlist.indexOf(productId);
  if (idx >= 0) {
    state.wishlist.splice(idx, 1);
    showToast('Removed from Wishlist');
  } else {
    state.wishlist.push(productId);
    showToast('Added to Wishlist ♥');
  }
  localStorage.setItem('sbd_wishlist', JSON.stringify(state.wishlist));
  updateCountersUI();
  renderAllProductGrids();
  if (state.currentView === 'product' && state.activeProductId === productId) {
    renderProductDetailView(productId);
  }

  if (state.currentUser && state.userProfile) {
    try {
      await updateDoc(doc(db, 'users', state.currentUser.uid), {
        wishlist: state.wishlist.slice(0, 50),
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      console.warn('Wishlist cloud sync skipped:', err);
    }
  }
}

function openReviewModal(product) {
  if (!state.currentUser) {
    showToast('Please sign in to submit a verified review.');
    openAuthModal('login');
    return;
  }
  const hasPurchased = state.orders.some(o =>
    o.userId === state.currentUser.uid &&
    (o.itemsSummary || '').toLowerCase().includes(product.name.toLowerCase())
  );

  openDynamicModal(`Review: ${product.name}`, `
    <form id="submitReviewForm">
      <div style="margin-bottom:12px;font-size:12.5px;color:${hasPurchased ? 'var(--success)' : 'var(--text-secondary)'};font-weight:600;">
        ${hasPurchased ? '✓ Eligible for Verified Purchase Badge' : 'Note: Submitting as registered customer review'}
      </div>
      <div class="form-group">
        <label class="form-label">Rating (1 to 5 Stars)</label>
        <select id="reviewRatingInput" class="form-control" required>
          <option value="5">★★★★★ (5 - Excellent)</option>
          <option value="4">★★★★☆ (4 - Very Good)</option>
          <option value="3">★★★☆☆ (3 - Good)</option>
          <option value="2">★★☆☆☆ (2 - Fair)</option>
          <option value="1">★☆☆☆☆ (1 - Poor)</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Your Written Review</label>
        <textarea id="reviewCommentInput" class="form-control" rows="4" minlength="2" maxlength="1400" placeholder="Share your experience with build quality, battery life, and delivery..." required></textarea>
      </div>
      <button type="submit" class="btn btn-red" style="width:100%;">Submit Review</button>
    </form>
  `);

  document.getElementById('submitReviewForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const rating = Number(document.getElementById('reviewRatingInput').value) || 5;
    const comment = document.getElementById('reviewCommentInput').value.trim().slice(0, 1400);
    if (comment.length < 2) return;

    const reviewId = `rev_${Date.now()}`;
    const reviewDoc = {
      id: reviewId,
      productId: product.id,
      userId: state.currentUser.uid,
      userName: (state.userProfile?.name || state.currentUser.displayName || state.currentUser.email || 'Customer').slice(0, 110),
      rating,
      comment,
      verifiedPurchase: Boolean(hasPurchased),
      status: 'approved',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    try {
      if (auth.currentUser && !state.currentUser?.isLocalEmailAuth) {
        await setDoc(doc(db, 'reviews', reviewId), reviewDoc);
      } else {
        const localRevs = JSON.parse(localStorage.getItem('sbd_local_reviews') || '[]');
        const localRevDoc = { ...reviewDoc, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
        localRevs.unshift(localRevDoc);
        localStorage.setItem('sbd_local_reviews', JSON.stringify(localRevs));
        state.reviews = [localRevDoc, ...state.reviews.filter(r => r.id !== reviewId)];
        if (state.currentView === 'product' && state.activeProductId === product.id) {
          renderProductDetailView(product.id);
        }
      }
      closeDynamicModal();
      showToast('Thank you! Your review has been published.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `reviews/${reviewId}`);
    }
  });
}


export {
  formatBrandHtml,
  getWhatsAppUrl,
  applySettingsToUI,
  updateCountersUI,
  renderHeroSlider,
  updateActiveHeroSlide,
  renderPromoBanner,
  renderCategoriesUI,
  createProductCardHTML,
  renderAllProductGrids,
  renderFeaturedCollectionTabGrid,
  renderShopGrid,
  renderWishlistGrid,
  openProductDetail,
  renderProductDetailView,
  toggleWishlist,
  openReviewModal
};
