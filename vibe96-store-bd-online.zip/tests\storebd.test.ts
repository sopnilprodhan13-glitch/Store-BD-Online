import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import {
  OtpService,
  InMemoryOtpChallengeStore
} from '../src/services/otpService.js';
import {
  OTP_EMAIL_SUBJECT,
  buildOtpEmailHtml,
  sendOtpEmail,
  OtpEmailPayload
} from '../src/services/emailProvider.js';
import {
  ADMIN_OWNER_EMAIL,
  isValidEmail,
  isValidBangladeshPhone,
  validateRegistrationInput,
  isValidSixDigitOtp
} from '../src/utils/validation.js';
import {
  ACCOUNT_NOT_FOUND_MESSAGE,
  PASSWORD_CHANGED_SUCCESS_MESSAGE,
  mapFirebaseLoginError,
  mapFirebaseRegistrationError
} from '../src/auth/authClient.js';
import {
  DEFAULT_BRANDING_SETTINGS,
  validateLogoFile,
  canUserModifyBranding,
  buildWhatsAppLink
} from '../src/admin/brandingService.js';
import {
  validateCouponForSubtotal,
  calculateAuthoritativeOrderTotals,
  validateCheckoutCustomerFields
} from '../src/orders/orderService.js';
import {
  validatePaymentSubmission
} from '../src/payments/paymentService.js';
import {
  ProductRecord,
  getEffectivePrice,
  getDiscountPercentage,
  filterAndSortProducts
} from '../src/products/productService.js';
import { app } from '../server.js';

const SAMPLE_CATALOG: ProductRecord[] = [
  {
    id: 'p1',
    name: 'ANC Wireless Headphones',
    slug: 'anc-wireless-headphones',
    category: 'Audio',
    sku: 'SBD-101',
    images: ['/assets/aistudio/image_cd2fbd85.png'],
    regularPrice: 2000,
    discountPrice: 1500,
    stock: 25,
    rating: 4.8,
    featured: true,
    trending: true,
    bestseller: true,
    active: true
  },
  {
    id: 'p2',
    name: 'Smart Fitness Watch',
    slug: 'smart-fitness-watch',
    category: 'Gadgets',
    sku: 'SBD-102',
    images: ['/assets/aistudio/image_cd2fbd85.png'],
    regularPrice: 1000,
    discountPrice: 500,
    stock: 15,
    rating: 4.6,
    featured: true,
    trending: false,
    bestseller: false,
    active: true
  }
];

describe('Store BD Online — Automated Verification Suite', () => {
  describe('1. Customer Registration & Login Validation', () => {
    it('validates registration fields and rejects mismatched passwords', () => {
      const valid = validateRegistrationInput({
        name: 'Rahim Uddin',
        email: 'rahim@example.com',
        phone: '01712345678',
        password: 'Secret123',
        confirmPassword: 'Secret123'
      });
      assert.equal(valid.valid, true);

      const mismatch = validateRegistrationInput({
        name: 'Rahim Uddin',
        email: 'rahim@example.com',
        phone: '01712345678',
        password: 'Secret123',
        confirmPassword: 'WrongPass'
      });
      assert.equal(mismatch.valid, false);
      assert.match(mismatch.error || '', /Passwords do not match/);
    });

    it('rejects invalid Bangladeshi phone numbers during registration', () => {
      assert.equal(isValidBangladeshPhone('01712345678'), true);
      assert.equal(isValidBangladeshPhone('+8801812345678'), true);
      assert.equal(isValidBangladeshPhone('12345'), false);
    });

    it('maps unknown login account errors to "Account not found. Please create an account first."', () => {
      assert.equal(
        mapFirebaseLoginError('auth/user-not-found'),
        ACCOUNT_NOT_FOUND_MESSAGE
      );
      assert.equal(
        mapFirebaseLoginError('auth/invalid-credential'),
        'Account not found. Please create an account first.'
      );
      assert.equal(
        mapFirebaseRegistrationError('auth/email-already-in-use'),
        'An account with this email already exists. Please sign in instead.'
      );
    });
  });

  describe('2. 5-Step Forgot Password Email OTP System', () => {
    const hmacSecret = 'unit-test-hmac-secret-key-2026';

    it('generates a 6-digit numeric OTP and stores only an HMAC-SHA256 digest', async () => {
      const store = new InMemoryOtpChallengeStore();
      const service = new OtpService(store, hmacSecret);
      const code = service.generateSixDigitCode();
      assert.equal(isValidSixDigitOtp(code), true);

      const capturedEmails: Array<OtpEmailPayload & { subject: string; html: string }> = [];
      const reqResult = await service.requestOtpChallenge({
        email: 'Customer@Example.com',
        ipAddress: '127.0.0.1',
        emailConfig: {
          testCaptureSink: (payload) => capturedEmails.push(payload)
        }
      });

      assert.equal(reqResult.ok, true);
      assert.equal(reqResult.code, 'OTP_SENT');
      assert.equal(capturedEmails.length, 1);
      assert.equal(capturedEmails[0].subject, OTP_EMAIL_SUBJECT);

      const emailHash = service.computeHmac('email', 'customer@example.com');
      const storedRecord = await store.getByEmailHash(emailHash);
      assert.ok(storedRecord);
      // Verify plaintext OTP is never stored in the challenge record
      assert.notEqual(storedRecord!.otpHmac, capturedEmails[0].otpCode);
      assert.equal(
        storedRecord!.otpHmac,
        service.computeHmac(`otp:${emailHash}`, capturedEmails[0].otpCode)
      );
    });

    it('enforces 60-second resend cooldown for the same email address', async () => {
      const store = new InMemoryOtpChallengeStore();
      const service = new OtpService(store, hmacSecret);
      let nowMs = 1_700_000_000_000;
      const emailConfig = { testCaptureSink: () => {} };

      const first = await service.requestOtpChallenge({
        email: 'cooldown@example.com',
        ipAddress: '10.0.0.1',
        nowMs,
        emailConfig
      });
      assert.equal(first.ok, true);

      nowMs += 20_000; // Only 20s elapsed (< 60s cooldown)
      const second = await service.requestOtpChallenge({
        email: 'cooldown@example.com',
        ipAddress: '10.0.0.1',
        nowMs,
        emailConfig
      });
      assert.equal(second.ok, false);
      assert.equal(second.status, 429);
      assert.equal(second.code, 'RESEND_COOLDOWN');

      nowMs += 45_000; // Total 65s elapsed (> 60s cooldown)
      const third = await service.requestOtpChallenge({
        email: 'cooldown@example.com',
        ipAddress: '10.0.0.1',
        nowMs,
        emailConfig
      });
      assert.equal(third.ok, true);
    });

    it('rejects expired OTP codes after 10 minutes', async () => {
      const store = new InMemoryOtpChallengeStore();
      const service = new OtpService(store, hmacSecret);
      let nowMs = 1_700_000_000_000;
      let sentCode = '';

      await service.requestOtpChallenge({
        email: 'expire@example.com',
        ipAddress: '10.0.0.2',
        nowMs,
        emailConfig: {
          testCaptureSink: (p) => {
            sentCode = p.otpCode;
          }
        }
      });

      // Advance clock past 10 minutes (601 seconds)
      nowMs += 601_000;
      const verifyResult = await service.verifyOtpCode({
        email: 'expire@example.com',
        otp: sentCode,
        nowMs
      });
      assert.equal(verifyResult.ok, false);
      assert.equal(verifyResult.code, 'OTP_EXPIRED');
    });

    it('rejects invalid OTP codes and locks challenge after 5 failed attempts', async () => {
      const store = new InMemoryOtpChallengeStore();
      const service = new OtpService(store, hmacSecret);
      let realCode = '';

      await service.requestOtpChallenge({
        email: 'lockout@example.com',
        ipAddress: '10.0.0.3',
        emailConfig: {
          testCaptureSink: (p) => {
            realCode = p.otpCode;
          }
        }
      });

      for (let i = 1; i <= 4; i++) {
        const res = await service.verifyOtpCode({
          email: 'lockout@example.com',
          otp: '000000'
        });
        assert.equal(res.ok, false);
        assert.equal(res.code, 'INVALID_OTP_CODE');
      }

      const fifthAttempt = await service.verifyOtpCode({
        email: 'lockout@example.com',
        otp: '000000'
      });
      assert.equal(fifthAttempt.ok, false);
      assert.equal(fifthAttempt.code, 'MAX_ATTEMPTS_EXCEEDED');

      // Even with the real OTP code afterwards, challenge remains locked
      const afterLock = await service.verifyOtpCode({
        email: 'lockout@example.com',
        otp: realCode
      });
      assert.equal(afterLock.ok, false);
      assert.equal(afterLock.code, 'MAX_ATTEMPTS_EXCEEDED');
    });

    it('completes password reset and prevents one-time OTP or session token replay', async () => {
      const store = new InMemoryOtpChallengeStore();
      const service = new OtpService(store, hmacSecret);
      const updatedPasswords: Record<string, string> = {};
      let otpCode = '';

      await service.requestOtpChallenge({
        email: 'resetme@example.com',
        ipAddress: '10.0.0.4',
        emailConfig: {
          testCaptureSink: (p) => {
            otpCode = p.otpCode;
          }
        }
      });

      const verifyResult = await service.verifyOtpCode({
        email: 'resetme@example.com',
        otp: otpCode
      });
      assert.equal(verifyResult.ok, true);
      assert.ok(verifyResult.resetSessionToken);

      const resetResult = await service.completePasswordReset({
        email: 'resetme@example.com',
        resetSessionToken: verifyResult.resetSessionToken!,
        newPassword: 'NewStrongPass99',
        confirmPassword: 'NewStrongPass99',
        updatePasswordCallback: async (email, newPass) => {
          updatedPasswords[email] = newPass;
        }
      });
      assert.equal(resetResult.ok, true);
      assert.equal(resetResult.message, PASSWORD_CHANGED_SUCCESS_MESSAGE);
      assert.equal(updatedPasswords['resetme@example.com'], 'NewStrongPass99');

      // Replay attempt with the same token must fail
      const replayReset = await service.completePasswordReset({
        email: 'resetme@example.com',
        resetSessionToken: verifyResult.resetSessionToken!,
        newPassword: 'AnotherPass11',
        confirmPassword: 'AnotherPass11',
        updatePasswordCallback: async () => {}
      });
      assert.equal(replayReset.ok, false);

      // Re-verifying the same OTP must also fail
      const replayVerify = await service.verifyOtpCode({
        email: 'resetme@example.com',
        otp: otpCode
      });
      assert.equal(replayVerify.ok, false);
    });

    it('returns an honest 503 EMAIL_PROVIDER_NOT_CONFIGURED error when email credentials are missing', async () => {
      const store = new InMemoryOtpChallengeStore();
      const service = new OtpService(store, hmacSecret);
      const result = await service.requestOtpChallenge({
        email: 'user@example.com',
        ipAddress: '10.0.0.5',
        emailConfig: {
          resendApiKey: '',
          smtpRelayUrl: ''
        }
      });
      assert.equal(result.ok, false);
      assert.equal(result.status, 503);
      assert.equal(result.code, 'EMAIL_PROVIDER_NOT_CONFIGURED');
    });
  });

  describe('3. Logo Upload Validation & Admin Authorization', () => {
    it('accepts PNG, JPG, JPEG, and WebP files under 5MB and rejects invalid types or >5MB files', () => {
      assert.equal(
        validateLogoFile({ name: 'logo.png', type: 'image/png', size: 450_000 }).valid,
        true
      );
      assert.equal(
        validateLogoFile({ name: 'logo.webp', type: 'image/webp', size: 1_200_000 }).valid,
        true
      );
      assert.equal(
        validateLogoFile({ name: 'malware.svg', type: 'image/svg+xml', size: 12_000 }).valid,
        false
      );
      assert.equal(
        validateLogoFile({ name: 'huge.png', type: 'image/png', size: 6 * 1024 * 1024 }).valid,
        false
      );
    });

    it('authorizes only sopnilprodhan13@gmail.com with verified email as Owner Admin', () => {
      assert.equal(ADMIN_OWNER_EMAIL, 'sopnilprodhan13@gmail.com');
      assert.equal(
        canUserModifyBranding({ email: 'sopnilprodhan13@gmail.com', emailVerified: true }),
        true
      );
      assert.equal(
        canUserModifyBranding({ email: 'sopnilprodhan13@gmail.com', emailVerified: false }),
        false
      );
      assert.equal(
        canUserModifyBranding({ email: 'customer@gmail.com', emailVerified: true }),
        false
      );
    });

    it('formats WhatsApp link and preserves default branding settings', () => {
      assert.equal(DEFAULT_BRANDING_SETTINGS.siteName, 'STORE BD ONLINE');
      const waLink = buildWhatsAppLink('01700000000', '880', 'Hello Store BD Online');
      assert.match(waLink, /^https:\/\/wa\.me\/8801700000000\?text=/);
    });
  });

  describe('4. E-Commerce Cart, Coupon, Delivery & Payment Calculations', () => {
    it('calculates subtotal, delivery fee, coupon discounts, and grand total accurately', () => {
      assert.equal(getEffectivePrice(SAMPLE_CATALOG[0]), 1500);
      assert.equal(getDiscountPercentage(SAMPLE_CATALOG[0]), 25);

      const coupon = {
        id: 'c1',
        code: 'SAVE10',
        discountType: 'percentage' as const,
        discountValue: 10,
        minOrder: 1000,
        maxUsage: 100,
        usedCount: 5,
        active: true
      };

      const couponCheck = validateCouponForSubtotal(coupon, 3500);
      assert.equal(couponCheck.valid, true);
      assert.equal(couponCheck.discountAmount, 350);

      const totals = calculateAuthoritativeOrderTotals({
        cart: [
          { productId: 'p1', qty: 2 },
          { productId: 'p2', qty: 1 }
        ],
        catalog: SAMPLE_CATALOG,
        division: 'Dhaka',
        deliveryConfig: {
          insideDhakaFee: 60,
          outsideDhakaFee: 120,
          freeDeliveryThreshold: 3000
        },
        coupon
      });

      assert.equal(totals.valid, true);
      assert.equal(totals.subtotal, 3500);
      assert.equal(totals.deliveryFee, 0); // Free delivery over 3000
      assert.equal(totals.discount, 350);
      assert.equal(totals.grandTotal, 3150);
    });

    it('validates COD, bKash, and Nagad payment submissions', () => {
      const codCheck = validatePaymentSubmission({ paymentMethod: 'cod' });
      assert.equal(codCheck.valid, true);
      assert.equal(codCheck.initialPaymentStatus, 'cod_pending');

      const invalidBkash = validatePaymentSubmission({
        paymentMethod: 'bkash',
        senderNumber: '01712345678',
        transactionId: ''
      });
      assert.equal(invalidBkash.valid, false);

      const validBkash = validatePaymentSubmission({
        paymentMethod: 'bkash',
        senderNumber: '01712345678',
        transactionId: 'BKS9876543'
      });
      assert.equal(validBkash.valid, true);
      assert.equal(validBkash.initialPaymentStatus, 'pending_verification');
    });

    it('filters and sorts product catalog accurately', () => {
      const audioProducts = filterAndSortProducts(SAMPLE_CATALOG, {
        category: 'Audio',
        sortBy: 'price-asc'
      });
      assert.equal(audioProducts.length, 1);
      assert.equal(audioProducts[0].sku, 'SBD-101');
    });
  });

  describe('5. Express API Endpoints & Security Rules Verification', () => {
    let server: http.Server;
    let baseUrl = '';

    before(async () => {
      await new Promise<void>((resolve) => {
        server = app.listen(0, '127.0.0.1', () => {
          const addr = server.address();
          if (addr && typeof addr === 'object') {
            baseUrl = `http://127.0.0.1:${addr.port}`;
          }
          resolve();
        });
      });
    });

    after(async () => {
      await new Promise<void>((resolve) => {
        server.close(() => resolve());
      });
    });

    it('serves /api/health and validates orders via /api/orders/validate', async () => {
      const healthResp = await fetch(`${baseUrl}/api/health`);
      assert.equal(healthResp.status, 200);
      const healthJson = (await healthResp.json()) as { ok: boolean; status: string; service: string };
      assert.equal(healthJson.ok, true);
      assert.equal(healthJson.status, 'healthy');
      assert.equal(healthJson.service, 'store-bd-online');

      const orderResp = await fetch(`${baseUrl}/api/orders/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: 'Karim Ahmed',
          customerPhone: '01712345678',
          division: 'Dhaka',
          district: 'Dhaka',
          fullAddress: 'House 12, Road 5, Dhanmondi',
          paymentMethod: 'cod',
          cart: [{ productId: 'p1', qty: 1 }],
          catalog: SAMPLE_CATALOG,
          deliveryConfig: {
            insideDhakaFee: 60,
            outsideDhakaFee: 120,
            freeDeliveryThreshold: 3000
          }
        })
      });
      assert.equal(orderResp.status, 200);
      const orderJson = (await orderResp.json()) as {
        ok: boolean;
        totals: { grandTotal: number };
      };
      assert.equal(orderJson.ok, true);
      assert.equal(orderJson.totals.grandTotal, 1560);
    });

    it('registers, logs in, updates profile, and changes password via server-side scrypt auth endpoints without exposing hashes', async () => {
      // Unregistered login must fail with 404 Account not found
      const missingLogin = await fetch(`${baseUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'newcustomer@example.com', password: 'Password123' })
      });
      assert.equal(missingLogin.status, 404);
      const missingJson = (await missingLogin.json()) as { ok: boolean; message: string };
      assert.equal(missingJson.ok, false);
      assert.equal(missingJson.message, 'Account not found. Please create an account first.');

      // Register customer
      const regResp = await fetch(`${baseUrl}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Nusrat Jahan',
          email: 'newcustomer@example.com',
          phone: '01711223344',
          password: 'Password123',
          confirmPassword: 'Password123'
        })
      });
      assert.equal(regResp.status, 201);
      const regJson = (await regResp.json()) as {
        ok: boolean;
        sessionToken: string;
        user: Record<string, unknown>;
      };
      assert.equal(regJson.ok, true);
      assert.ok(regJson.sessionToken);
      assert.equal(regJson.user.email, 'newcustomer@example.com');
      // Ensure password or scrypt hash is never returned in API response
      assert.equal('password' in regJson.user, false);
      assert.equal('passwordScryptHex' in regJson.user, false);

      // Login with registered credentials
      const loginResp = await fetch(`${baseUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'newcustomer@example.com', password: 'Password123' })
      });
      assert.equal(loginResp.status, 200);
      const loginJson = (await loginResp.json()) as { ok: boolean; sessionToken: string };
      assert.equal(loginJson.ok, true);

      // Verify /api/auth/me with Bearer token
      const meResp = await fetch(`${baseUrl}/api/auth/me`, {
        headers: { Authorization: `Bearer ${loginJson.sessionToken}` }
      });
      assert.equal(meResp.status, 200);
    });

    it('verifies firestore.rules and storage.rules enforce strict owner admin and OTP challenge lockdown', () => {
      const firestoreRules = fs.readFileSync('firestore.rules', 'utf8');
      assert.match(firestoreRules, /sopnilprodhan13@gmail\.com/);
      assert.match(firestoreRules, /match \/passwordResetChallenges\/\{challengeId\}/);
      assert.match(firestoreRules, /allow read, write: if false;/);

      const storageRules = fs.readFileSync('storage.rules', 'utf8');
      assert.match(storageRules, /sopnilprodhan13@gmail\.com/);
      assert.match(storageRules, /5 \* 1024 \* 1024/);
    });

    it('serves /api/config/firebase with security headers and keeps index.html & all 7 JS modules under 1,000 lines and free of hardcoded API keys', async () => {
      const cfgResp = await fetch(`${baseUrl}/api/config/firebase`);
      assert.equal(cfgResp.status, 200);
      assert.equal(cfgResp.headers.get('x-content-type-options'), 'nosniff');
      assert.equal(cfgResp.headers.get('x-frame-options'), 'SAMEORIGIN');
      assert.equal(cfgResp.headers.get('permissions-policy'), 'camera=(), microphone=(), geolocation=()');
      const cfgJson = (await cfgResp.json()) as { projectId: string; firestoreDatabaseId: string };
      assert.equal(cfgJson.projectId, 'gen-lang-client-0128050017');
      assert.equal(cfgJson.firestoreDatabaseId, 'ai-studio-2a331384-50d8-42fd-9a43-f88f719935a8');

      const keyPrefix = ['AIza', 'Sy'].join('');
      const indexHtml = fs.readFileSync('index.html', 'utf8');
      assert.equal(indexHtml.includes(keyPrefix), false);
      assert.equal(indexHtml.includes('@latest'), false);
      assert.ok(indexHtml.split('\n').length < 600);

      const jsModules = [
        'public/assets/js/seedData.js',
        'public/assets/js/storefrontUI.js',
        'public/assets/js/cartCheckout.js',
        'public/assets/js/authOtp.js',
        'public/assets/js/adminDashboard.js',
        'public/assets/js/adminSettingsReports.js',
        'public/assets/js/app.js'
      ];
      for (const modPath of jsModules) {
        const content = fs.readFileSync(modPath, 'utf8');
        assert.equal(content.includes(keyPrefix), false, `${modPath} must not contain hardcoded API key`);
        assert.ok(
          content.split('\n').length < 1000,
          `${modPath} must be under 1,000 lines`
        );
      }
    });
  });
});
