/**
 * Store BD Online — Cart, Coupon, Delivery & Order Validation Service
 *
 * Ensures all price and quantity calculations are computed from authoritative
 * catalog records rather than trusting browser-submitted prices.
 */

import { ProductRecord, getEffectivePrice } from '../products/productService';
import { isValidBangladeshPhone } from '../utils/validation';

export interface CartItemInput {
  productId: string;
  qty: number;
}

export interface CouponRecord {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrder: number;
  maxUsage: number;
  usedCount: number;
  expiresAt?: string;
  active: boolean;
}

export interface DeliveryConfig {
  insideDhakaFee: number;
  outsideDhakaFee: number;
  freeDeliveryThreshold: number;
}

export interface OrderCalculationResult {
  valid: boolean;
  error?: string;
  detailedItems: Array<{
    productId: string;
    name: string;
    unitPrice: number;
    qty: number;
    lineTotal: number;
  }>;
  totalQty: number;
  subtotal: number;
  discount: number;
  deliveryFee: number;
  grandTotal: number;
}

export const ORDER_STATUS_FLOW = [
  'Order Placed',
  'Confirmed',
  'Processing',
  'Packed',
  'Shipped',
  'Out for Delivery',
  'Delivered',
] as const;

export const SPECIAL_ORDER_STATUSES = ['Cancelled', 'Returned', 'Refunded'] as const;

/**
 * Validates whether a coupon is active, not expired, within usage limits, and meets minimum order.
 */
export function validateCouponForSubtotal(
  coupon: CouponRecord | null | undefined,
  subtotal: number,
  nowMs = Date.now()
): { valid: boolean; discountAmount: number; error?: string } {
  if (!coupon) {
    return { valid: false, discountAmount: 0, error: 'Invalid coupon code.' };
  }
  if (!coupon.active) {
    return { valid: false, discountAmount: 0, error: 'This coupon code is inactive.' };
  }
  if (coupon.expiresAt) {
    const expTime = Date.parse(coupon.expiresAt);
    if (!Number.isNaN(expTime) && nowMs > expTime) {
      return { valid: false, discountAmount: 0, error: 'This coupon code has expired.' };
    }
  }
  if (coupon.usedCount >= coupon.maxUsage) {
    return { valid: false, discountAmount: 0, error: 'This coupon has reached its usage limit.' };
  }
  if (subtotal < coupon.minOrder) {
    return {
      valid: false,
      discountAmount: 0,
      error: `Minimum order of ৳${coupon.minOrder} is required for coupon ${coupon.code}.`,
    };
  }

  let discount = 0;
  if (coupon.discountType === 'percentage') {
    discount = Math.round((subtotal * Number(coupon.discountValue)) / 100);
  } else {
    discount = Math.round(Number(coupon.discountValue));
  }
  discount = Math.max(0, Math.min(discount, subtotal));

  return { valid: true, discountAmount: discount };
}

/**
 * Computes authoritative order totals from catalog products, cart quantities, coupon, and division.
 */
export function calculateAuthoritativeOrderTotals(params: {
  cart: CartItemInput[];
  catalog: ProductRecord[];
  division: string;
  deliveryConfig: DeliveryConfig;
  coupon?: CouponRecord | null;
  nowMs?: number;
}): OrderCalculationResult {
  const detailedItems: OrderCalculationResult['detailedItems'] = [];
  let subtotal = 0;
  let totalQty = 0;

  for (const item of params.cart || []) {
    const qty = Math.floor(Number(item.qty) || 0);
    if (qty <= 0) continue;

    const product = params.catalog.find((p) => p.id === item.productId && p.active !== false);
    if (!product) {
      return {
        valid: false,
        error: `Product (${item.productId}) is unavailable or no longer active.`,
        detailedItems: [],
        totalQty: 0,
        subtotal: 0,
        discount: 0,
        deliveryFee: 0,
        grandTotal: 0,
      };
    }

    if (qty > product.stock) {
      return {
        valid: false,
        error: `Insufficient stock for "${product.name}" (available: ${product.stock}).`,
        detailedItems: [],
        totalQty: 0,
        subtotal: 0,
        discount: 0,
        deliveryFee: 0,
        grandTotal: 0,
      };
    }

    const unitPrice = getEffectivePrice(product);
    const lineTotal = unitPrice * qty;
    subtotal += lineTotal;
    totalQty += qty;

    detailedItems.push({
      productId: product.id,
      name: product.name,
      unitPrice,
      qty,
      lineTotal,
    });
  }

  if (detailedItems.length === 0) {
    return {
      valid: false,
      error: 'Your shopping cart is empty.',
      detailedItems: [],
      totalQty: 0,
      subtotal: 0,
      discount: 0,
      deliveryFee: 0,
      grandTotal: 0,
    };
  }

  let discount = 0;
  if (params.coupon) {
    const couponCheck = validateCouponForSubtotal(params.coupon, subtotal, params.nowMs);
    if (!couponCheck.valid) {
      return {
        valid: false,
        error: couponCheck.error,
        detailedItems,
        totalQty,
        subtotal,
        discount: 0,
        deliveryFee: 0,
        grandTotal: subtotal,
      };
    }
    discount = couponCheck.discountAmount;
  }

  const isInsideDhaka = String(params.division || '').trim().toLowerCase() === 'dhaka';
  const baseFee = isInsideDhaka
    ? Number(params.deliveryConfig.insideDhakaFee) || 0
    : Number(params.deliveryConfig.outsideDhakaFee) || 0;

  const freeThreshold = Number(params.deliveryConfig.freeDeliveryThreshold) || 0;
  const deliveryFee = freeThreshold > 0 && subtotal >= freeThreshold ? 0 : baseFee;
  const grandTotal = Math.max(0, subtotal - discount + deliveryFee);

  return {
    valid: true,
    detailedItems,
    totalQty,
    subtotal,
    discount,
    deliveryFee,
    grandTotal,
  };
}

/**
 * Validates customer delivery address and phone fields during checkout.
 */
export function validateCheckoutCustomerFields(input: {
  customerName: string;
  customerPhone: string;
  division: string;
  district: string;
  fullAddress: string;
}): { valid: boolean; error?: string } {
  if (!input.customerName || input.customerName.trim().length < 2) {
    return { valid: false, error: 'Please provide the recipient full name.' };
  }
  if (!isValidBangladeshPhone(input.customerPhone)) {
    return {
      valid: false,
      error: 'Please enter a valid 11-digit Bangladeshi mobile number (e.g. 017XXXXXXXX).',
    };
  }
  if (!input.division || !input.district) {
    return { valid: false, error: 'Please select both Division and District.' };
  }
  if (!input.fullAddress || input.fullAddress.trim().length < 4) {
    return { valid: false, error: 'Please enter a complete delivery street address.' };
  }
  return { valid: true };
}
