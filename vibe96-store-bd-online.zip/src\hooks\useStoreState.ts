/**
 * Store BD Online — Persistent Cart & Wishlist State Hook Utilities
 */

import { CartItemInput } from '../orders/orderService';

const CART_STORAGE_KEY = 'sbd_cart';
const WISHLIST_STORAGE_KEY = 'sbd_wishlist';
const RECENT_STORAGE_KEY = 'sbd_recent';

export function loadPersistedCart(storageObj?: Pick<Storage, 'getItem'>): CartItemInput[] {
  try {
    const raw = (storageObj || localStorage).getItem(CART_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((item) => item && typeof item.productId === 'string' && Number(item.qty) > 0)
      .map((item) => ({
        productId: String(item.productId),
        qty: Math.max(1, Math.min(99, Math.floor(Number(item.qty)))),
      }));
  } catch {
    return [];
  }
}

export function savePersistedCart(
  cart: CartItemInput[],
  storageObj?: Pick<Storage, 'setItem'>
): void {
  try {
    (storageObj || localStorage).setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadPersistedWishlist(storageObj?: Pick<Storage, 'getItem'>): string[] {
  try {
    const raw = (storageObj || localStorage).getItem(WISHLIST_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((id) => typeof id === 'string' && id.length > 0).slice(0, 50);
  } catch {
    return [];
  }
}

export function toggleWishlistItem(list: string[], productId: string): {
  updated: string[];
  added: boolean;
} {
  const existing = list.includes(productId);
  if (existing) {
    return {
      updated: list.filter((id) => id !== productId),
      added: false,
    };
  }
  return {
    updated: [...list, productId].slice(0, 50),
    added: true,
  };
}

export function loadRecentlyViewed(storageObj?: Pick<Storage, 'getItem'>): string[] {
  try {
    const raw = (storageObj || localStorage).getItem(RECENT_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === 'string').slice(0, 12) : [];
  } catch {
    return [];
  }
}
