# How To Set Up Store BD Online

This guide walks you through setting up **Store BD Online** from a clean checkout to a live production store.

---

## 1. Prerequisites

- **Node.js**: v22.x LTS (or v20+)
- **npm**: v10+
- **Firebase Project**: A Google Firebase project with **Authentication** (Email/Password + Google), **Cloud Firestore**, and **Firebase Storage** enabled.
- **Transactional Email Account** (for 6-digit Forgot Password Email OTP): [Resend](https://resend.com) API key or an HTTP/SMTP relay endpoint.

---

## 2. Install Dependencies

From the project root directory, run:

```bash
npm install
```

---

## 3. Environment Variables Setup

Copy the template file `.env.example` to `.env`:

```bash
cp .env.example .env
```

Edit `.env` and fill in your credentials:

| Variable | Purpose |
| :--- | :--- |
| `PORT` | HTTP port (default `3000`) |
| `ADMIN_OWNER_EMAIL` | Owner administrator email (`sopnilprodhan13@gmail.com`) |
| `FIREBASE_PROJECT_ID` | Firebase Project ID (`gen-lang-client-0128050017`) |
| `OTP_HASH_SECRET` | 64-character random hex secret for HMAC-SHA256 OTP hashing |
| `RESEND_API_KEY` | Resend API key for sending 6-digit OTP password reset emails |
| `MAIL_FROM` | Verified sender address (e.g. `Store BD Online <no-reply@yourdomain.com>`) |
| `FIREBASE_ADMIN_BEARER_TOKEN` | Google Cloud / Firebase Admin OAuth2 bearer token for server-side password updates |

---

## 4. Firebase Console Configuration

1. **Enable Sign-In Providers**:
   - Open **Firebase Console → Authentication → Sign-in method**.
   - Enable **Email/Password** and **Google** sign-in providers.
2. **Deploy Firestore & Storage Security Rules**:
   - Deploy `firestore.rules`, `firestore.indexes.json`, and `storage.rules` using the Firebase CLI:
     ```bash
     firebase deploy --only firestore:rules,firestore:indexes,storage
     ```
3. **Seed Initial Store Catalog**:
   - Sign in on the storefront using the Owner Admin email (`sopnilprodhan13@gmail.com`).
   - Open the **Admin Dashboard** (or click **Sync Default Catalog** in the sidebar) to populate default categories, sample products, banners, coupons, and `/settings/store`.

---

## 5. Verify Your Setup

Run the automated test suite and security rules linter:

```bash
npm test
npx eslint firestore.rules
```

Start the development server:

```bash
npm run dev
```

Visit `http://localhost:3000` in your browser and verify `http://localhost:3000/api/health` returns `"status": "healthy"`.

---

## 6. Troubleshooting: `auth/api-key-not-valid`

If you see `Firebase: Error (auth/api-key-not-valid.-please-pass-a-valid-api-key.)`:

1. In `.env` / your hosting environment variables, make sure `VITE_FIREBASE_API_KEY` is either **a real key** or **not set at all** (the server then uses `apiKey` from `firebase-applet-config.json`). Placeholder text such as `YOUR_FIREBASE_WEB_API_KEY` is ignored by the server, but a wrong real-looking key is not.
2. Open `http://localhost:3000/api/config/firebase` and confirm `apiKey` starts with `AIza` and is 39 characters long.
3. In Google Cloud Console → APIs & Services → Credentials, open the browser key and check:
   - **Application restrictions** (HTTP referrers) include your domain and `localhost`.
   - **API restrictions** include *Identity Toolkit API* and *Token Service API* (or are set to "Don't restrict key").
4. In Firebase Console → Authentication → Settings → **Authorized domains**, add your deployed domain.
5. Restart the server (`npm run dev`) and hard-refresh the browser.

