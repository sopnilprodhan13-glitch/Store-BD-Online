/**
 * Store BD Online — Configurable Email Provider Adapter for 6-Digit Password Reset OTP
 *
 * Supports:
 * 1. Resend HTTP API (`RESEND_API_KEY` + `MAIL_FROM`)
 * 2. Custom Webhook / SMTP Relay HTTP endpoint (`SMTP_RELAY_URL` + `SMTP_RELAY_KEY`)
 * 3. Controlled Test Capture Adapter (ONLY in isolated automated unit tests when explicitly injected)
 *
 * Security & Honesty Guarantee:
 * - Never logs the plaintext OTP to console or disk.
 * - Never pretends an email was sent if no real email provider is configured in production/dev.
 */

import { escapeHtml } from '../utils/validation';

export interface OtpEmailPayload {
  to: string;
  otpCode: string;
  storeName: string;
  tagline: string;
  logoUrl?: string;
  expiresInMinutes: number;
}

export interface EmailSendResult {
  sent: boolean;
  provider: 'resend' | 'smtp_relay' | 'test_memory' | 'unconfigured';
  messageId?: string;
  errorCode?: 'EMAIL_PROVIDER_NOT_CONFIGURED' | 'EMAIL_DELIVERY_FAILED';
  errorMessage?: string;
}

export interface EmailProviderConfig {
  resendApiKey?: string;
  mailFrom?: string;
  appBaseUrl?: string;
  smtpRelayUrl?: string;
  smtpRelayKey?: string;
  /** Used exclusively by automated unit tests to verify outbound OTP payloads without external network calls */
  testCaptureSink?: (payload: OtpEmailPayload & { subject: string; html: string }) => void;
}

export const OTP_EMAIL_SUBJECT = 'Your Store BD Online Password Reset Code';

/**
 * Builds the responsive, mobile-friendly HTML email template with Store BD Online branding,
 * 6-digit verification code, 10-minute expiration notice, and security warning.
 */
export function buildOtpEmailHtml(payload: OtpEmailPayload, appBaseUrl = ''): string {
  const safeStore = escapeHtml(payload.storeName || 'Store BD Online');
  const safeTagline = escapeHtml(payload.tagline || 'Shop Smart • Save More');
  const safeCode = escapeHtml(payload.otpCode);
  const safeMins = Number(payload.expiresInMinutes) || 10;

  let publicLogoUrl = payload.logoUrl || '';
  if (publicLogoUrl.startsWith('/') && appBaseUrl) {
    publicLogoUrl = `${appBaseUrl.replace(/\/$/, '')}${publicLogoUrl}`;
  }
  const hasPublicLogo = /^https?:\/\//i.test(publicLogoUrl);

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${OTP_EMAIL_SUBJECT}</title>
</head>
<body style="margin:0;padding:0;background-color:#F7F7F8;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#080808;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#F7F7F8;padding:28px 12px;">
    <tr>
      <td align="center">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:520px;background-color:#FFFFFF;border-radius:16px;overflow:hidden;border:1px solid #E5E7EB;box-shadow:0 8px 24px rgba(0,0,0,0.06);">
          <tr>
            <td style="background-color:#080808;padding:24px 24px 20px;text-align:center;border-bottom:3px solid #E50914;">
              ${
                hasPublicLogo
                  ? `<img src="${escapeHtml(publicLogoUrl)}" alt="${safeStore}" style="max-height:56px;width:auto;display:block;margin:0 auto 10px;object-fit:contain;" />`
                  : ''
              }
              <div style="font-size:20px;font-weight:800;color:#FFFFFF;letter-spacing:0.04em;">${safeStore}</div>
              <div style="font-size:11px;font-weight:700;color:#FFD500;letter-spacing:0.12em;text-transform:uppercase;margin-top:4px;">${safeTagline}</div>
            </td>
          </tr>
          <tr>
            <td style="padding:28px 24px;">
              <h1 style="margin:0 0 12px;font-size:19px;font-weight:800;color:#080808;">Password Reset Verification Code</h1>
              <p style="margin:0 0 18px;font-size:14px;line-height:1.6;color:#333333;">
                We received a request to reset the password for your <strong>${safeStore}</strong> account. Enter the six-digit verification code below to verify your identity and set a new password:
              </p>
              <div style="background-color:#FFFBEB;border:2px dashed #E50914;border-radius:12px;padding:18px 16px;text-align:center;margin:0 0 20px;">
                <div style="font-size:11px;font-weight:700;color:#8A5700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;">6-Digit Verification Code</div>
                <div style="font-size:32px;font-weight:800;letter-spacing:0.28em;color:#E50914;font-family:monospace;">${safeCode}</div>
              </div>
              <p style="margin:0 0 12px;font-size:13px;line-height:1.5;color:#111111;">
                <strong>Expiration Notice:</strong> This verification code will expire in <strong>${safeMins} minutes</strong> and can only be used once.
              </p>
              <div style="background-color:#FEF2F2;border-left:4px solid #E50914;padding:12px 14px;border-radius:6px;font-size:12.5px;line-height:1.5;color:#991B1B;">
                <strong>Security Warning:</strong> Never share this verification code with anyone. ${safeStore} staff or support will never ask you for this code. If you did not request a password reset, you can safely ignore this email.
              </div>
            </td>
          </tr>
          <tr>
            <td style="background-color:#080808;padding:16px 24px;text-align:center;font-size:11.5px;color:#9CA3AF;">
              &copy; ${new Date().getFullYear()} ${safeStore}. All rights reserved.
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

/**
 * Sends a 6-digit OTP email through the configured server-side email provider.
 */
export async function sendOtpEmail(
  payload: OtpEmailPayload,
  config?: EmailProviderConfig
): Promise<EmailSendResult> {
  const resendApiKey = (config?.resendApiKey ?? process.env.RESEND_API_KEY ?? '').trim();
  const mailFrom = (
    config?.mailFrom ??
    process.env.MAIL_FROM ??
    'Store BD Online <no-reply@storebdonline.com>'
  ).trim();
  const appBaseUrl = (config?.appBaseUrl ?? process.env.APP_BASE_URL ?? process.env.APP_URL ?? '').trim();
  const smtpRelayUrl = (config?.smtpRelayUrl ?? process.env.SMTP_RELAY_URL ?? '').trim();
  const smtpRelayKey = (config?.smtpRelayKey ?? process.env.SMTP_RELAY_KEY ?? '').trim();

  const html = buildOtpEmailHtml(payload, appBaseUrl);

  // 1. Isolated test sink (only when explicitly injected in automated tests)
  if (config?.testCaptureSink) {
    config.testCaptureSink({
      ...payload,
      subject: OTP_EMAIL_SUBJECT,
      html,
    });
    return {
      sent: true,
      provider: 'test_memory',
      messageId: `test_msg_${Date.now()}`,
    };
  }

  // 2. Resend HTTP API
  if (resendApiKey && resendApiKey !== 'YOUR_RESEND_API_KEY' && !resendApiKey.startsWith('MY_')) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: mailFrom,
          to: [payload.to],
          subject: OTP_EMAIL_SUBJECT,
          html,
        }),
      });
      const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
      if (!response.ok) {
        return {
          sent: false,
          provider: 'resend',
          errorCode: 'EMAIL_DELIVERY_FAILED',
          errorMessage:
            typeof data.message === 'string'
              ? data.message
              : `Email provider returned HTTP ${response.status}. Verify RESEND_API_KEY and sender domain in EMAIL_OTP_SETUP.md.`,
        };
      }
      return {
        sent: true,
        provider: 'resend',
        messageId: typeof data.id === 'string' ? data.id : undefined,
      };
    } catch (err) {
      return {
        sent: false,
        provider: 'resend',
        errorCode: 'EMAIL_DELIVERY_FAILED',
        errorMessage: err instanceof Error ? err.message : 'Failed to connect to Resend API.',
      };
    }
  }

  // 3. Custom SMTP Relay Webhook
  if (smtpRelayUrl && /^https?:\/\//i.test(smtpRelayUrl)) {
    try {
      const response = await fetch(smtpRelayUrl, {
        method: 'POST',
        headers: {
          ...(smtpRelayKey ? { Authorization: `Bearer ${smtpRelayKey}` } : {}),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: mailFrom,
          to: payload.to,
          subject: OTP_EMAIL_SUBJECT,
          html,
        }),
      });
      if (!response.ok) {
        return {
          sent: false,
          provider: 'smtp_relay',
          errorCode: 'EMAIL_DELIVERY_FAILED',
          errorMessage: `SMTP relay returned HTTP ${response.status}.`,
        };
      }
      return {
        sent: true,
        provider: 'smtp_relay',
      };
    } catch (err) {
      return {
        sent: false,
        provider: 'smtp_relay',
        errorCode: 'EMAIL_DELIVERY_FAILED',
        errorMessage: err instanceof Error ? err.message : 'Failed to connect to SMTP relay.',
      };
    }
  }

  // 4. Not configured — return honest setup-required status (never fake delivery)
  return {
    sent: false,
    provider: 'unconfigured',
    errorCode: 'EMAIL_PROVIDER_NOT_CONFIGURED',
    errorMessage:
      'Email OTP service is not configured yet. Please set RESEND_API_KEY and MAIL_FROM in server environment variables (see EMAIL_OTP_SETUP.md).',
  };
}
