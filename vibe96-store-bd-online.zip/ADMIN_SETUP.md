# Owner Admin Setup & Access Control (`ADMIN_SETUP.md`)

The **Store BD Online** Admin Dashboard is a private administration portal restricted exclusively to the store owner.

---

## 1. Authorized Owner Administrator Identity

- **Authorized Email**: `sopnilprodhan13@gmail.com`
- **Verification Requirement**: `email_verified == true` in Firebase Authentication.

No other user account can access the Admin Dashboard or perform administrative writes to Firestore or Firebase Storage.

---

## 2. Signing In as Owner Administrator

1. Open the Store BD Online storefront.
2. Click **Account** (or **Sign In**).
3. Click **Continue with Google (Instant Sign-In)** and select `sopnilprodhan13@gmail.com` (Google accounts automatically satisfy `email_verified == true`), **or** sign in with your verified `sopnilprodhan13@gmail.com` Email & Password.
4. Once authenticated as `sopnilprodhan13@gmail.com`:
   - The **Admin Portal** link automatically appears in the top utility bar, mobile navigation drawer, and **My Account** page.
   - Click **Admin Portal** / **Open Admin Dashboard** to access all 10 management modules.

---

## 3. Non-Admin Behavior

- For anonymous visitors and standard customer accounts, Admin links are completely hidden from the navigation bar and mobile drawer.
- If a non-admin user navigates directly to the Admin view, the application displays:
  `Access Denied — Administrator Only`
- Any direct API or browser console attempt by a non-admin user to write to `/settings/store`, `/products`, `/categories`, `/banners`, `/coupons`, or `/branding/*` is rejected by `firestore.rules` and `storage.rules`.

---

## 4. Provisioning Custom Claims (Optional Cloud Function)

The repository includes `/functions/src/provisionOwnerAdmin.ts` (`syncOwnerAdminClaim`), which can set the custom claim `{ role: "owner_admin", admin: true }` on the `sopnilprodhan13@gmail.com` Firebase Auth user record while preserving existing `request.auth.token.email == "sopnilprodhan13@gmail.com"` rule enforcement.
