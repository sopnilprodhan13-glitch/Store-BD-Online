import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword,
  updateProfile,
  signOut
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  writeBatch,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js';


// =========================================================================
// 13. USER AUTHENTICATION, ACCOUNT SYSTEM & 5-STEP EMAIL OTP PASSWORD RESET
// =========================================================================
let otpTimerInterval = null;
function clearOtpTimer() {
  if (otpTimerInterval) {
    clearInterval(otpTimerInterval);
    otpTimerInterval = null;
  }
}

function openForgotPasswordOtpFlow(prefillEmail = '') {
  clearOtpTimer();
  const logoSrc = state.settings.logoUrl && state.settings.logoUrl !== DEFAULT_SETTINGS.logoUrl
    ? state.settings.logoUrl
    : (state.transparentLogoDataUrl || DEFAULT_SETTINGS.logoUrl);
  const siteTitle = state.settings.siteName || 'STORE BD ONLINE';

  const otpState = {
    step: 1, // 1: Request Email, 3: Enter 6-digit OTP, 4: Set New Password, 5: Success
    email: prefillEmail,
    challengeId: '',
    resetSessionToken: '',
    resendCooldownSec: 0,
    expiresSec: 600
  };

  function renderOtpModalStep() {
    clearOtpTimer();
    let stepBodyHtml = '';

    if (otpState.step === 1) {
      stepBodyHtml = `
        <p style="font-size:13px;color:var(--text-secondary);margin-bottom:14px;text-align:center;">
          Enter your registered email address to receive a 6-digit verification code.
        </p>
        <form id="otpStep1Form">
          <div class="form-group">
            <label class="form-label">Registered Email Address *</label>
            <input type="email" id="otpEmailInput" class="form-control" required maxlength="240" value="${escapeHtml(otpState.email)}" placeholder="you@example.com" />
          </div>
          <button type="submit" class="btn btn-red" id="otpSendCodeBtn" style="width:100%;height:44px;">
            Send Verification Code
          </button>
        </form>
        <div style="text-align:center;margin-top:14px;">
          <button type="button" id="otpBackToLoginBtn" style="color:var(--brand-red);font-weight:700;font-size:13px;">
            ← Back to Login
          </button>
        </div>
      `;
    } else if (otpState.step === 3) {
      stepBodyHtml = `
        <div style="padding:10px 12px;border-radius:var(--radius-sm);background:#F8FAFC;border:1px solid var(--border-light);margin-bottom:14px;font-size:12.5px;color:var(--text-secondary);text-align:center;">
          We sent a 6-digit verification code to <strong>${escapeHtml(otpState.email)}</strong>.<br/>
          Code expires in <strong id="otpExpiryCountdown" class="tabular-nums" style="color:var(--brand-red);">10:00</strong>
        </div>
        <form id="otpStep3Form">
          <div class="form-group">
            <label class="form-label" style="text-align:center;display:block;">6-Digit Verification Code *</label>
            <input
              type="text"
              id="otpCodeInput"
              inputmode="numeric"
              autocomplete="one-time-code"
              pattern="[0-9]{6}"
              maxlength="6"
              class="form-control tabular-nums"
              required
              placeholder="000000"
              style="text-align:center;font-size:22px;font-weight:800;letter-spacing:8px;height:52px;"
            />
          </div>
          <button type="submit" class="btn btn-red" id="otpVerifyBtn" style="width:100%;height:44px;">
            Verify Code
          </button>
        </form>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;font-size:12.5px;">
          <button type="button" id="otpResendBtn" style="font-weight:700;color:var(--brand-red);" ${otpState.resendCooldownSec > 0 ? 'disabled' : ''}>
            ${otpState.resendCooldownSec > 0 ? `Resend Code (${otpState.resendCooldownSec}s)` : 'Resend Code'}
          </button>
          <button type="button" id="otpBackToLoginBtn" style="color:var(--text-secondary);">
            Back to Login
          </button>
        </div>
      `;
    } else if (otpState.step === 4) {
      stepBodyHtml = `
        <p style="font-size:13px;color:var(--text-secondary);margin-bottom:14px;text-align:center;">
          Verification complete for <strong>${escapeHtml(otpState.email)}</strong>. Set your new password below.
        </p>
        <form id="otpStep4Form">
          <div class="form-group">
            <label class="form-label">New Password (min 6 characters) *</label>
            <input type="password" id="otpNewPassInput" class="form-control" required minlength="6" placeholder="••••••••" />
          </div>
          <div class="form-group">
            <label class="form-label">Confirm New Password *</label>
            <input type="password" id="otpConfirmPassInput" class="form-control" required minlength="6" placeholder="••••••••" />
          </div>
          <button type="submit" class="btn btn-red" id="otpUpdatePassBtn" style="width:100%;height:44px;">
            Update Password
          </button>
        </form>
      `;
    } else if (otpState.step === 5) {
      stepBodyHtml = `
        <div style="text-align:center;padding:12px 0;">
          <div style="width:52px;height:52px;border-radius:50%;background:#DCFCE7;color:#15803D;display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:800;margin:0 auto 12px;">
            ✓
          </div>
          <h4 style="font-size:16px;font-weight:800;color:var(--text-primary);margin-bottom:8px;">
            Your password has been successfully changed.
          </h4>
          <p style="font-size:13px;color:var(--text-secondary);margin-bottom:18px;">
            You can now sign in to your ${escapeHtml(siteTitle)} account using your new password.
          </p>
          <button type="button" class="btn btn-red" id="otpReturnLoginBtn" style="width:100%;height:44px;">
            Return to Login
          </button>
        </div>
      `;
    }

    openDynamicModal('Forgot Password — Email OTP Verification', `
      <div style="text-align:center;margin-bottom:14px;">
        <div class="brand-logo-wrap" style="margin:0 auto 8px;width:50px;height:50px;">
          <img src="${logoSrc}" alt="${escapeHtml(siteTitle)}" class="brand-logo-img" />
        </div>
        <div style="font-size:11.5px;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.6px;">
          Step ${otpState.step === 1 ? '1 of 4' : otpState.step === 3 ? '2 of 4' : otpState.step === 4 ? '3 of 4' : '4 of 4'}
        </div>
      </div>
      <div id="otpErrorBanner" style="display:none;margin-bottom:12px;padding:10px 12px;border-radius:var(--radius-sm);background:#FEF2F2;color:#991B1B;font-size:12.5px;font-weight:600;"></div>
      ${stepBodyHtml}
    `);

    const showOtpError = (msg) => {
      const banner = document.getElementById('otpErrorBanner');
      if (banner) {
        banner.textContent = msg;
        banner.style.display = 'block';
      }
      showToast(msg);
    };

    document.getElementById('otpBackToLoginBtn')?.addEventListener('click', () => {
      clearOtpTimer();
      openAuthModal('login');
    });
    document.getElementById('otpReturnLoginBtn')?.addEventListener('click', () => {
      clearOtpTimer();
      openAuthModal('login');
    });

    if (otpState.step === 1) {
      document.getElementById('otpStep1Form')?.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const emailVal = document.getElementById('otpEmailInput').value.trim().toLowerCase();
        if (!emailVal) {
          showOtpError('Please enter your registered email address.');
          return;
        }
        const btn = document.getElementById('otpSendCodeBtn');
        if (btn) {
          btn.disabled = true;
          btn.textContent = 'Sending 6-Digit Code...';
        }
        try {
          const resp = await fetch('/api/auth/otp/request', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: emailVal })
          });
          const data = await resp.json();
          if (!resp.ok || !data.ok) {
            showOtpError(data.message || 'Unable to send verification code. Please check your email configuration.');
            if (btn) {
              btn.disabled = false;
              btn.textContent = 'Send Verification Code';
            }
            return;
          }
          otpState.email = emailVal;
          otpState.challengeId = data.challengeId;
          otpState.resendCooldownSec = data.resendCooldownSeconds || 60;
          otpState.expiresSec = data.expiresInSeconds || 600;
          otpState.step = 3;
          showToast('6-digit verification code sent to your email.');
          renderOtpModalStep();
        } catch (err) {
          showOtpError(err.message || 'Network error while requesting verification code.');
          if (btn) {
            btn.disabled = false;
            btn.textContent = 'Send Verification Code';
          }
        }
      });
    } else if (otpState.step === 3) {
      const codeInput = document.getElementById('otpCodeInput');
      codeInput?.addEventListener('input', () => {
        codeInput.value = codeInput.value.replace(/[^0-9]/g, '').slice(0, 6);
      });
      codeInput?.addEventListener('paste', (ev) => {
        const pasted = (ev.clipboardData || window.clipboardData)?.getData('text') || '';
        const digits = pasted.replace(/[^0-9]/g, '').slice(0, 6);
        if (digits) {
          ev.preventDefault();
          codeInput.value = digits;
        }
      });

      otpTimerInterval = setInterval(() => {
        if (otpState.expiresSec > 0) {
          otpState.expiresSec -= 1;
          const expEl = document.getElementById('otpExpiryCountdown');
          if (expEl) {
            const m = String(Math.floor(otpState.expiresSec / 60)).padStart(2, '0');
            const s = String(otpState.expiresSec % 60).padStart(2, '0');
            expEl.textContent = `${m}:${s}`;
          }
        }
        if (otpState.resendCooldownSec > 0) {
          otpState.resendCooldownSec -= 1;
          const resendBtn = document.getElementById('otpResendBtn');
          if (resendBtn) {
            if (otpState.resendCooldownSec > 0) {
              resendBtn.disabled = true;
              resendBtn.textContent = `Resend Code (${otpState.resendCooldownSec}s)`;
            } else {
              resendBtn.disabled = false;
              resendBtn.textContent = 'Resend Code';
            }
          }
        }
      }, 1000);

      document.getElementById('otpResendBtn')?.addEventListener('click', async () => {
        if (otpState.resendCooldownSec > 0) return;
        try {
          const resp = await fetch('/api/auth/otp/request', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: otpState.email })
          });
          const data = await resp.json();
          if (!resp.ok || !data.ok) {
            showOtpError(data.message || 'Please wait before requesting another code.');
            return;
          }
          otpState.challengeId = data.challengeId;
          otpState.resendCooldownSec = data.resendCooldownSeconds || 60;
          otpState.expiresSec = data.expiresInSeconds || 600;
          showToast('A new 6-digit verification code has been sent.');
          renderOtpModalStep();
        } catch (err) {
          showOtpError(err.message || 'Unable to resend code.');
        }
      });

      document.getElementById('otpStep3Form')?.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const codeVal = (document.getElementById('otpCodeInput').value || '').replace(/[^0-9]/g, '');
        if (codeVal.length !== 6) {
          showOtpError('Please enter a valid 6-digit numeric verification code.');
          return;
        }
        const btn = document.getElementById('otpVerifyBtn');
        if (btn) {
          btn.disabled = true;
          btn.textContent = 'Verifying...';
        }
        try {
          const resp = await fetch('/api/auth/otp/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: otpState.email,
              challengeId: otpState.challengeId,
              code: codeVal
            })
          });
          const data = await resp.json();
          if (!resp.ok || !data.ok) {
            showOtpError(data.message || 'Invalid or expired verification code.');
            if (btn) {
              btn.disabled = false;
              btn.textContent = 'Verify Code';
            }
            return;
          }
          otpState.resetSessionToken = data.resetSessionToken;
          otpState.step = 4;
          renderOtpModalStep();
        } catch (err) {
          showOtpError(err.message || 'Verification failed. Please try again.');
          if (btn) {
            btn.disabled = false;
            btn.textContent = 'Verify Code';
          }
        }
      });
    } else if (otpState.step === 4) {
      document.getElementById('otpStep4Form')?.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const newPassword = document.getElementById('otpNewPassInput').value;
        const confirmPassword = document.getElementById('otpConfirmPassInput').value;
        if (newPassword.length < 6) {
          showOtpError('Password must be at least 6 characters.');
          return;
        }
        if (newPassword !== confirmPassword) {
          showOtpError('Passwords do not match. Please confirm your new password.');
          return;
        }
        const btn = document.getElementById('otpUpdatePassBtn');
        if (btn) {
          btn.disabled = true;
          btn.textContent = 'Updating Password...';
        }
        try {
          const resp = await fetch('/api/auth/otp/reset-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: otpState.email,
              challengeId: otpState.challengeId,
              resetSessionToken: otpState.resetSessionToken,
              newPassword,
              confirmPassword
            })
          });
          const data = await resp.json();
          if (!resp.ok || !data.ok) {
            showOtpError(data.message || 'Failed to update password.');
            if (btn) {
              btn.disabled = false;
              btn.textContent = 'Update Password';
            }
            return;
          }
          otpState.step = 5;
          renderOtpModalStep();
        } catch (err) {
          showOtpError(err.message || 'Network error while updating password.');
          if (btn) {
            btn.disabled = false;
            btn.textContent = 'Update Password';
          }
        }
      });
    }
  }

  renderOtpModalStep();
}

function activateServerCustomerSession(user, sessionToken) {
  if (!user) return;
  if (sessionToken) {
    sessionStorage.setItem('sbd_server_session_token', sessionToken);
  }
  const isOwner = Boolean(
    user.isAdmin ||
    (user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase())
  );
  state.currentUser = {
    uid: user.uid,
    email: user.email,
    displayName: user.name,
    emailVerified: true,
    isServerSession: true
  };
  state.userProfile = {
    uid: user.uid,
    name: user.name,
    email: user.email,
    phone: user.phone || '',
    division: user.division || 'Dhaka',
    district: user.district || 'Dhaka',
    upazila: user.upazila || '',
    address: user.address || '',
    status: user.status || 'active',
    wishlist: state.wishlist.slice(0, 50)
  };
  state.isAdmin = isOwner;

  const topAdminBtn = document.getElementById('topAdminBtn');
  const topAdminSep = document.getElementById('topAdminSep');
  const mobileAdminBtn = document.getElementById('mobileDrawerAdminBtn');
  if (topAdminBtn) topAdminBtn.style.display = isOwner ? 'inline-block' : 'none';
  if (topAdminSep) topAdminSep.style.display = isOwner ? 'inline' : 'none';
  if (mobileAdminBtn) mobileAdminBtn.style.display = isOwner ? 'flex' : 'none';

  if (isOwner) {
    switchView('admin');
  } else {
    switchView('account');
  }
}

function openAuthModal(mode = 'login', prefillEmail = '') {
  if (mode === 'reset') {
    openForgotPasswordOtpFlow(prefillEmail);
    return;
  }

  const logoSrc = state.settings.logoUrl && state.settings.logoUrl !== DEFAULT_SETTINGS.logoUrl
    ? state.settings.logoUrl
    : (state.transparentLogoDataUrl || DEFAULT_SETTINGS.logoUrl);
  const siteTitle = state.settings.siteName || 'STORE BD ONLINE';
  openDynamicModal(mode === 'register' ? `Create ${siteTitle} Account` : `Sign In to ${siteTitle}`, `
    <div style="text-align:center;margin-bottom:16px;">
      <div class="brand-logo-wrap" style="margin:0 auto 8px;width:54px;height:54px;">
        <img src="${logoSrc}" alt="${escapeHtml(siteTitle)}" class="brand-logo-img" />
      </div>
      <div style="font-size:12.5px;color:var(--text-secondary);">${escapeHtml(state.settings.tagline || 'Shop Smart • Save More')}</div>
    </div>

    <div id="authModalErrorBanner" style="display:none;margin-bottom:12px;padding:10px 12px;border-radius:var(--radius-sm);background:#FEF2F2;color:#991B1B;font-size:12.5px;font-weight:600;"></div>

    <form id="authModalForm">
      ${mode === 'register' ? `
        <div class="form-group">
          <label class="form-label">Full Name *</label>
          <input type="text" id="authNameInput" class="form-control" required maxlength="110" placeholder="Your Full Name" />
        </div>
        <div class="form-group">
          <label class="form-label">Mobile Number (BD) *</label>
          <input type="tel" id="authPhoneInput" class="form-control" required maxlength="16" placeholder="017XXXXXXXX" />
        </div>
      ` : ''}
      <div class="form-group">
        <label class="form-label">Email Address *</label>
        <input type="email" id="authEmailInput" class="form-control" required maxlength="240" value="${escapeHtml(prefillEmail)}" placeholder="you@example.com" />
      </div>
      <div class="form-group">
        <label class="form-label">Password *</label>
        <input type="password" id="authPassInput" class="form-control" required minlength="6" placeholder="••••••••" />
      </div>
      ${mode === 'register' ? `
        <div class="form-group">
          <label class="form-label">Confirm Password *</label>
          <input type="password" id="authConfirmPassInput" class="form-control" required minlength="6" placeholder="••••••••" />
        </div>
      ` : ''}
      <button type="submit" class="btn btn-red" style="width:100%;height:44px;">
        ${mode === 'register' ? 'Create Account' : 'Sign In'}
      </button>
    </form>

    <div style="display:flex;justify-content:space-between;margin-top:14px;font-size:12.5px;">
      ${mode !== 'login' ? `<button type="button" id="switchAuthLogin" style="color:var(--brand-red);font-weight:700;">Sign In Instead</button>` : `<button type="button" id="switchAuthReg" style="color:var(--brand-red);font-weight:700;">Create New Account</button>`}
      <button type="button" id="switchAuthReset" style="color:var(--text-secondary);font-weight:600;">Forgot Password?</button>
    </div>
  `);

  const showErr = (msg) => {
    const box = document.getElementById('authModalErrorBanner');
    if (box) {
      box.textContent = msg;
      box.style.display = 'block';
    }
    showToast(msg);
  };

  document.getElementById('switchAuthLogin')?.addEventListener('click', () => openAuthModal('login'));
  document.getElementById('switchAuthReg')?.addEventListener('click', () => openAuthModal('register'));
  document.getElementById('switchAuthReset')?.addEventListener('click', () => {
    const prefill = document.getElementById('authEmailInput')?.value?.trim() || '';
    openForgotPasswordOtpFlow(prefill);
  });

  document.getElementById('authModalForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('authEmailInput').value.trim();
    const emailLower = email.toLowerCase();
    const pass = document.getElementById('authPassInput')?.value || '';
    const confirmPass = document.getElementById('authConfirmPassInput')?.value || '';

    if (mode === 'register') {
      if (pass.length < 6) {
        showErr('Password must be at least 6 characters.');
        return;
      }
      if (pass !== confirmPass) {
        showErr('Passwords do not match. Please confirm your password.');
        return;
      }
    }

    let name = '';
    let phone = '';
    if (mode === 'register') {
      name = document.getElementById('authNameInput').value.trim();
      phone = document.getElementById('authPhoneInput').value.trim();
      const bdPhoneRegex = /^(?:\+?880|0)1[3-9]\d{8}$/;
      if (!bdPhoneRegex.test(phone.replace(/[\s-]/g, ''))) {
        showErr('Please enter a valid 11-digit Bangladeshi mobile number (e.g. 017XXXXXXXX).');
        return;
      }
    }

    try {
      if (mode === 'register') {
        const regResp = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, phone, password: pass, confirmPassword: confirmPass })
        });
        const regData = await regResp.json();
        if (!regResp.ok || !regData.ok) {
          showErr(regData.message || 'Registration failed. Please check your details.');
          return;
        }
        if (auth) {
          try {
            const cred = await createUserWithEmailAndPassword(auth, email, pass);
            await updateProfile(cred.user, { displayName: name });
            await ensureUserProfileDoc(cred.user, { name, phone });
          } catch (_) {}
        }
        activateServerCustomerSession(regData.user, regData.sessionToken);
        closeDynamicModal();
        showToast('Account created successfully!');
        return;
      } else {
        // Login mode
        const loginResp = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password: pass })
        });
        const loginData = await loginResp.json();
        if (loginResp.ok && loginData.ok && loginData.user) {
          if (auth && !emailLower.includes(ADMIN_EMAIL.toLowerCase())) {
            try {
              const cred = await signInWithEmailAndPassword(auth, email, pass);
              await ensureUserProfileDoc(cred.user);
            } catch (_) {}
          }
          activateServerCustomerSession(loginData.user, loginData.sessionToken);
          closeDynamicModal();
          if (loginData.user.isAdmin || emailLower === ADMIN_EMAIL.toLowerCase()) {
            showToast(`Signed in as Owner Administrator (${loginData.user.email})!`);
          } else {
            showToast(`Welcome, ${loginData.user.name || loginData.user.email}!`);
          }
          return;
        }

        showErr(loginData.message || (loginResp.status === 404 ? 'Account not found. Please create an account first.' : 'Incorrect password. Please try again.'));
        return;
      }
    } catch (err) {
      showErr(err.message || 'Authentication error. Please try again.');
    }
  });
}

async function ensureUserProfileDoc(user, extra = {}) {
  if (!user) return;
  const userRef = doc(db, 'users', user.uid);
  try {
    const snap = await getDoc(userRef);
    if (!snap.exists()) {
      await setDoc(userRef, {
        uid: user.uid,
        name: (extra.name || user.displayName || user.email?.split('@')[0] || 'Customer').slice(0, 115),
        email: (user.email || 'guest@storebdonline.com').slice(0, 250),
        phone: (extra.phone || '').slice(0, 18),
        division: 'Dhaka',
        district: 'Dhaka',
        upazila: '',
        address: '',
        status: 'active',
        wishlist: state.wishlist.slice(0, 50),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }
  } catch (err) {
    console.warn('User profile init:', err);
  }
}

function renderAccountView() {
  const container = document.getElementById('userAccountContainer');
  if (!container) return;

  if (!state.currentUser) {
    container.innerHTML = `
      <div style="max-width:520px;margin:0 auto;background:var(--bg-white);padding:32px;border-radius:var(--radius-lg);border:1px solid var(--border-light);text-align:center;">
        <h1 class="section-title" style="margin-bottom:8px;">My Account</h1>
        <p style="font-size:13.5px;color:var(--text-secondary);margin-bottom:18px;">Sign in to manage your profile, saved Bangladesh delivery addresses, wishlist, and order history.</p>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
          <button type="button" class="btn btn-red" id="accLoginBtn">Sign In</button>
          <button type="button" class="btn btn-outline" id="accRegisterBtn">Create Account</button>
          <button type="button" class="btn btn-outline" id="accForgotOtpBtn">Forgot Password (OTP)</button>
        </div>
      </div>
    `;
    document.getElementById('accLoginBtn')?.addEventListener('click', () => openAuthModal('login'));
    document.getElementById('accRegisterBtn')?.addEventListener('click', () => openAuthModal('register'));
    document.getElementById('accForgotOtpBtn')?.addEventListener('click', () => openForgotPasswordOtpFlow());
    return;
  }

  const p = state.userProfile || {};
  const myOrders = state.orders.filter(o => o.userId === state.currentUser.uid);

  container.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:20px;">
      <div>
        <h1 class="section-title">Welcome, ${escapeHtml(p.name || state.currentUser.displayName || state.currentUser.email)}</h1>
        <p style="font-size:13px;color:var(--text-secondary);">${escapeHtml(state.currentUser.email)} ${state.isAdmin ? '· <strong style="color:var(--brand-red);">Owner Administrator</strong>' : ''}</p>
      </div>
      <div style="display:flex;gap:10px;">
        ${state.isAdmin ? `<button type="button" class="btn btn-black" data-nav="admin">Open Admin Dashboard</button>` : ''}
        <button type="button" class="btn btn-outline" id="logoutUserBtn">Logout</button>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr;gap:20px;" class="account-grid-2col">
      <!-- Profile & Address Book -->
      <div style="background:var(--bg-white);padding:20px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h2 style="font-size:16px;font-weight:800;margin-bottom:12px;">Edit Profile & Default Delivery Address</h2>
        <form id="updateProfileForm">
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input type="text" id="profName" class="form-control" required maxlength="115" value="${escapeHtml(p.name || state.currentUser.displayName || '')}" />
          </div>
          <div class="form-group">
            <label class="form-label">Mobile Number</label>
            <input type="tel" id="profPhone" class="form-control" maxlength="18" value="${escapeHtml(p.phone || '')}" placeholder="017XXXXXXXX" />
          </div>
          <div class="form-grid-2">
            <div class="form-group">
              <label class="form-label">Division</label>
              <input type="text" id="profDiv" class="form-control" maxlength="55" value="${escapeHtml(p.division || 'Dhaka')}" />
            </div>
            <div class="form-group">
              <label class="form-label">District</label>
              <input type="text" id="profDist" class="form-control" maxlength="55" value="${escapeHtml(p.district || 'Dhaka')}" />
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Upazila / Thana</label>
            <input type="text" id="profUpa" class="form-control" maxlength="55" value="${escapeHtml(p.upazila || '')}" />
          </div>
          <div class="form-group">
            <label class="form-label">Full Street Address</label>
            <textarea id="profAddr" class="form-control" rows="2" maxlength="480">${escapeHtml(p.address || '')}</textarea>
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button type="submit" class="btn btn-red">Save Profile & Address</button>
            <button type="button" class="btn btn-outline" id="changePasswordBtn">Change Password</button>
          </div>
        </form>
      </div>

      <!-- My Orders List -->
      <div style="background:var(--bg-white);padding:20px;border-radius:var(--radius-md);border:1px solid var(--border-light);">
        <h2 style="font-size:16px;font-weight:800;margin-bottom:12px;">My Orders (${myOrders.length})</h2>
        ${myOrders.length === 0 ? `
          <p style="font-size:13.5px;color:var(--text-secondary);">You haven't placed any orders yet.</p>
        ` : `
          <div style="display:flex;flex-direction:column;gap:10px;max-height:420px;overflow-y:auto;">
            ${myOrders.map(o => `
              <div style="padding:12px;border-radius:var(--radius-sm);border:1px solid var(--border-light);background:var(--bg-light);">
                <div style="display:flex;justify-content:space-between;font-weight:700;font-size:13.5px;">
                  <span>${escapeHtml(o.orderNumber)} (<code>${escapeHtml(o.id)}</code>)</span>
                  <span style="color:var(--brand-red);">${formatPrice(o.grandTotal)}</span>
                </div>
                <div style="font-size:12px;color:var(--text-secondary);margin:4px 0;">${escapeHtml(o.itemsSummary)}</div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:6px;font-size:12px;">
                  <span>Status: <strong>${escapeHtml(o.orderStatus)}</strong> · Payment: ${escapeHtml(o.paymentStatus)}</span>
                  ${o.orderStatus === 'Order Placed' ? `<button type="button" class="btn btn-outline" data-cancel-own-order="${escapeHtml(o.id)}" style="padding:4px 10px;font-size:11px;color:var(--danger);">Cancel Order</button>` : ''}
                </div>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    </div>
  `;

  const grid2 = container.querySelector('.account-grid-2col');
  if (grid2 && window.innerWidth >= 860) {
    grid2.style.gridTemplateColumns = '1fr 1.15fr';
  }

  document.getElementById('logoutUserBtn')?.addEventListener('click', async () => {
    sessionStorage.removeItem('sbd_server_session_token');
    state.currentUser = null;
    state.userProfile = null;
    state.isAdmin = false;
    try { await signOut(auth); } catch (_) {}
    renderAccountView();
    showToast('Logged out successfully.');
  });

  document.getElementById('updateProfileForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const updatedFields = {
      name: document.getElementById('profName').value.trim().slice(0, 115),
      phone: document.getElementById('profPhone').value.trim().slice(0, 18),
      division: document.getElementById('profDiv').value.trim().slice(0, 55),
      district: document.getElementById('profDist').value.trim().slice(0, 55),
      upazila: document.getElementById('profUpa').value.trim().slice(0, 55),
      address: document.getElementById('profAddr').value.trim().slice(0, 480)
    };

    if (auth.currentUser && !state.currentUser?.isServerSession) {
      try {
        await updateDoc(doc(db, 'users', state.currentUser.uid), {
          ...updatedFields,
          updatedAt: serverTimestamp()
        });
        showToast('Profile & Address saved!');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${state.currentUser.uid}`);
      }
    } else {
      const token = sessionStorage.getItem('sbd_server_session_token') || '';
      try {
        const resp = await fetch('/api/auth/profile', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify(updatedFields)
        });
        const data = await resp.json();
        if (resp.ok && data.ok) {
          activateServerCustomerSession(data.user, token);
          showToast('Profile & Address saved!');
        } else {
          showToast(data.message || 'Could not update profile.');
        }
      } catch (_) {
        showToast('Network error while saving profile.');
      }
    }
  });

  document.getElementById('changePasswordBtn')?.addEventListener('click', () => {
    openDynamicModal('Change Password', `
      <form id="newPassForm">
        <div class="form-group">
          <label class="form-label">New Password (min 6 characters) *</label>
          <input type="password" id="newPassVal" class="form-control" required minlength="6" />
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password *</label>
          <input type="password" id="confirmNewPassVal" class="form-control" required minlength="6" />
        </div>
        <button type="submit" class="btn btn-red" style="width:100%;">Update Password</button>
      </form>
    `);
    document.getElementById('newPassForm')?.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const p1 = document.getElementById('newPassVal').value;
      const p2 = document.getElementById('confirmNewPassVal').value;
      if (p1 !== p2) {
        showToast('Passwords do not match. Please confirm your new password.');
        return;
      }
      if (auth.currentUser && !state.currentUser?.isServerSession) {
        try {
          await updatePassword(auth.currentUser, p1);
          closeDynamicModal();
          showToast('Password updated successfully!');
        } catch (err) {
          showToast(err.message || 'Please re-login or use Forgot Password (OTP) to change your password.');
        }
      } else {
        const token = sessionStorage.getItem('sbd_server_session_token') || '';
        try {
          const resp = await fetch('/api/auth/change-password', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`
            },
            body: JSON.stringify({ newPassword: p1, confirmPassword: p2 })
          });
          const data = await resp.json();
          if (resp.ok && data.ok) {
            closeDynamicModal();
            showToast(data.message || 'Password updated successfully!');
          } else {
            showToast(data.message || 'Failed to update password.');
          }
        } catch (_) {
          showToast('Network error while updating password.');
        }
      }
    });
  });

  container.querySelectorAll('[data-cancel-own-order]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const oid = btn.getAttribute('data-cancel-own-order');
      if (auth.currentUser) {
        try {
          const batch = writeBatch(db);
          batch.update(doc(db, 'orders', oid), { orderStatus: 'Cancelled', updatedAt: serverTimestamp() });
          batch.update(doc(db, 'orderTracking', oid), { orderStatus: 'Cancelled', updatedAt: serverTimestamp() });
          await batch.commit();
          showToast('Order cancelled.');
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `orders/${oid}`);
        }
      }
    });
  });
}

export {
  clearOtpTimer,
  openForgotPasswordOtpFlow,
  activateServerCustomerSession,
  openAuthModal,
  ensureUserProfileDoc,
  renderAccountView
};
