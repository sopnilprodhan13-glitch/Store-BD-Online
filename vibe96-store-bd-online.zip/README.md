# STORE BD ONLINE — Complete E-Commerce Store & Private Owner Admin Platform

**Tagline:** *Shop Smart • Save More*

**Store BD Online** is a full-stack, mobile-first Bangladesh e-commerce web application built for a single store owner's business and brand. It combines a fast, responsive customer storefront with Firebase Authentication, a server-backed 5-step 6-digit Email OTP password recovery workflow, Firestore real-time catalog and order synchronization, manual bKash/Nagad/Cash-on-Delivery checkout verification, and a private Owner Admin Dashboard with live Logo & Brand Customization.

---

## Key Features

### 1. Customer Storefront & Shopping Experience
- **Responsive Mobile-First UI**: Engineered for 320px–1920px viewports with zero horizontal overflow, sticky navigation, bottom mobile action bar, and high-contrast typography.
- **Dynamic Product Catalog**: Search, category filtering (`Gadgets`, `Audio`, `Smart Home`, `Gaming`, `Accessories`, `Travel Tech`), price range filter, sorting (`Popular`, `Price: Low to High`, `Price: High to Low`, `Top Rated`), quick view modal, and full product detail view.
- **Cart, Wishlist & Coupons**: Persistent cart and wishlist, real-time stock checks, percentage and fixed-amount discount coupons, and automated Inside/Outside Dhaka delivery charge calculation with free-shipping thresholds.
- **Checkout & Order Tracking**: Supports **Cash on Delivery (COD)**, **bKash**, and **Nagad** manual verification (`Pending Verification` status until verified by the store owner), printable customer invoice, and public Order ID + Mobile Number tracking.

### 2. Customer Authentication & 5-Step Email OTP Password Recovery
- **Registration Before Login**: Customers register with Full Name, Email, BD Mobile Number (`01XXXXXXXXX`), Password, and Confirm Password. Login never auto-creates accounts and displays `"Account not found. Please create an account first."` for unregistered emails.
- **5-Step Forgot Password Email OTP System**:
  1. **Step 1**: Enter Registered Email Address and click `Send Verification Code` (or `Back to Login`).
  2. **Step 2**: Server generates a cryptographically random 6-digit numeric OTP, stores only its keyed `HMAC-SHA256` digest, and sends a branded HTML email (`"Your Store BD Online Password Reset Code"`).
  3. **Step 3**: Enter the 6-digit OTP (numeric filter, paste support, mobile numeric keypad, 10-minute expiration timer, and 60-second resend cooldown).
  4. **Step 4**: Enter `New Password` and `Confirm New Password` and click `Update Password`.
  5. **Step 5**: Confirmation screen (`"Your password has been successfully changed."`) and `Return to Login`.

### 3. Private Owner Admin Dashboard (`sopnilprodhan13@gmail.com`)
- **Strict Owner Access Control**: Admin UI and Firestore/Storage write rules are locked to `sopnilprodhan13@gmail.com` with `email_verified == true`.
- **Complete Logo & Brand Customization**:
  - Upload a new logo from desktop or mobile (`PNG`, `JPG`, `JPEG`, `WebP`, `Transparent PNG` up to `5MB`).
  - Live logo preview, Replace Existing Logo, Remove Current Logo, Reset to Default Logo, and Separate Favicon upload.
  - Customize Store Name, Tagline, Brand Colors, Header/Footer colors, SEO Title/Description, Contact details, WhatsApp country code & number, Facebook Page & Messenger links, Payment numbers, and Delivery fees across all 9 storefront locations.
- **Full Store Operations**: Product CRUD, Category CRUD, Order & Payment Verification, Customer Management, Banner Management, Coupon Management, Review Moderation, and CSV Reports.

---

## Project Architecture

```text
/
├── index.html                  # Storefront & Admin UI entry point
├── server.ts                   # Express + Vite backend server (OTP & Order Validation APIs)
├── firebase-blueprint.json     # Canonical Firestore schema blueprint
├── firestore.rules             # Production Firestore security rules
├── storage.rules               # Production Firebase Storage security rules
├── firestore.indexes.json      # Composite Firestore indexes
├── Dockerfile                  # Multi-stage production container image
├── docker-compose.yml          # Single-command VPS deployment
├── cloudbuild.yaml             # Google Cloud Run CI/CD pipeline
├── src/
│   ├── admin/brandingService.ts
│   ├── auth/authClient.ts
│   ├── components/OtpModalSteps.ts
│   ├── hooks/useStoreState.ts
│   ├── orders/orderService.ts
│   ├── pages/StoreApp.ts
│   ├── payments/paymentService.ts
│   ├── products/productService.ts
│   ├── services/
│   │   ├── emailProvider.ts    # Resend & SMTP Relay email delivery adapter
│   │   ├── firebaseConfig.ts   # Environment-driven Firebase configuration
│   │   └── otpService.ts       # Cryptographic 6-digit OTP challenge service
│   ├── styles/theme.ts
│   └── utils/validation.ts
├── functions/                  # Firebase Cloud Functions (OTP & Owner Admin custom claims)
│   └── src/
│       ├── index.ts
│       └── provisionOwnerAdmin.ts
└── tests/
    └── storebd.test.ts         # 17 automated unit & integration tests
```

---

## Quick Start

1. **Install dependencies**:
   ```bash
   npm install
   ```
2. **Configure environment**:
   ```bash
   cp .env.example .env
   ```
3. **Run development server (Port 3000)**:
   ```bash
   npm run dev
   ```
4. **Run automated test suite & security rules linter**:
   ```bash
   npm test
   npx eslint firestore.rules
   ```
5. **Build for production**:
   ```bash
   npm run build
   npm start
   ```

---

## Documentation Index

- [`HowToSetup.md`](./HowToSetup.md) — Complete step-by-step setup guide
- [`AGENTS.md`](./AGENTS.md) — Architecture, invariants & engineering conventions
- [`DATABASE_SCHEMA.md`](./DATABASE_SCHEMA.md) — Firestore collections, fields & indexes
- [`SECURITY.md`](./SECURITY.md) — Authentication, RBAC, OTP & Storage security model
- [`EMAIL_OTP_SETUP.md`](./EMAIL_OTP_SETUP.md) — Configuring Resend / SMTP for 6-digit Email OTP
- [`ADMIN_SETUP.md`](./ADMIN_SETUP.md) — Owner Admin (`sopnilprodhan13@gmail.com`) setup & claims
- [`BRANDING_GUIDE.md`](./BRANDING_GUIDE.md) — Logo upload, transparent PNG & brand customization guide
- [`PAYMENT_SETUP.md`](./PAYMENT_SETUP.md) — Cash on Delivery, bKash & Nagad manual verification setup
- [`DEPLOYMENT.md`](./DEPLOYMENT.md) — Deploying to Google Cloud Run & Docker on a VPS
- [`CHANGELOG.md`](./CHANGELOG.md) — Release history
- [`AUDIT_REPORT.md`](./AUDIT_REPORT.md) — Technical & security audit report
- [`RELEASE_READINESS.md`](./RELEASE_READINESS.md) — Final release verification checklist
