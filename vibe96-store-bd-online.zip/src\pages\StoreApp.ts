/**
 * Store BD Online — Storefront Application Navigation & View Registry
 */

export const STORE_VIEWS = [
  'home',
  'shop',
  'product',
  'wishlist',
  'checkout',
  'confirmation',
  'tracking',
  'account',
  'admin',
  'info',
] as const;

export type StoreViewId = (typeof STORE_VIEWS)[number];

export const ADMIN_TABS = [
  { id: 'overview', label: '📊 Dashboard Overview' },
  { id: 'branding', label: '🎨 Website Branding & Logo' },
  { id: 'products', label: '📦 Product Management' },
  { id: 'categories', label: '🗂️ Category Management' },
  { id: 'orders', label: '🧾 Order Management' },
  { id: 'customers', label: '👥 Customer Management' },
  { id: 'banners', label: '🖼️ Banner Management' },
  { id: 'coupons', label: '🎟️ Coupon Management' },
  { id: 'reviews', label: '⭐ Review Moderation' },
  { id: 'settings', label: '⚙️ Payment, Delivery & Social' },
  { id: 'reports', label: '📈 Reports & CSV Export' },
] as const;
