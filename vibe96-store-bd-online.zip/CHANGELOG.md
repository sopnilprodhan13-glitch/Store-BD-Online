# Changelog (`CHANGELOG.md`)

All notable changes to **Store BD Online** are documented in this file.

---

## [1.0.0] — 2026-11-15 (Final Marketplace Release)

### Added
- **5-Step Forgot Password Email OTP System**:
  - Server-side CSPRNG 6-digit OTP generator (`src/services/otpService.ts`), keyed `HMAC-SHA256` storage, 10-minute expiration, 60-second resend cooldown, 5-attempt brute-force lockout, single-use replay prevention, and constant-time verification.
  - Configurable transactional email adapter (`src/services/emailProvider.ts`) supporting Resend (`RESEND_API_KEY`, `MAIL_FROM`) and custom SMTP/HTTP relay (`SMTP_RELAY_URL`) with branded HTML email template (`"Your Store BD Online Password Reset Code"`).
  - Interactive 5-step Forgot Password modal in `index.html` with numeric filter, clipboard paste support, live expiration timer, and resend cooldown timer.
- **Complete Admin Logo & Branding Customization**:
  - Dedicated `WEBSITE BRANDING & CUSTOMIZATION` module (`🎨 Website Branding & Customization`) in the Owner Admin Dashboard.
  - Desktop & mobile file picker supporting `PNG`, `JPG`, `JPEG`, `WebP`, and `Transparent PNG` (up to `5MB`), live transparency preview, Replace Logo, Remove Logo, Reset to Default Logo, Separate Favicon upload, and automatic synchronization across all 9 storefront locations.
- **Modular Full-Stack Architecture**:
  - Added modular TypeScript services (`src/admin`, `src/auth`, `src/components`, `src/hooks`, `src/orders`, `src/pages`, `src/payments`, `src/products`, `src/services`, `src/styles`, `src/utils`), Express API server (`server.ts`), and Firebase Cloud Functions (`functions/`).
- **Security Rules & Indexes**:
  - Hardened `firestore.rules` (with `/passwordResetChallenges/{challengeId}` locked `allow read, write: if false;` to clients), `storage.rules`, and `firestore.indexes.json`.
- **Automated Verification & Deployment**:
  - Added 17 unit & integration tests in `tests/storebd.test.ts`.
  - Added `Dockerfile`, `.dockerignore`, `docker-compose.yml`, and `cloudbuild.yaml`.
  - Added complete 14-document documentation suite and 5 high-resolution (`1920x1080`) application screenshots.

### Security Fixes
- Removed all client-side `localStorage` password hash fallbacks so passwords are never stored in browser storage or Firestore.
- Enforced strict login check (`"Account not found. Please create an account first."`) so login never auto-creates accounts.
