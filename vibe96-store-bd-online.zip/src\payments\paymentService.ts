/**
 * Store BD Online — Payment Validation & Verification Service
 *
 * Supports:
 * - Cash on Delivery (`cod`)
 * - bKash Manual Verification (`bkash`)
 * - Nagad Manual Verification (`nagad`)
 *
 * Security Invariants:
 * - Manual payments (`bkash`, `nagad`) always start with `paymentStatus = 'pending_verification'`.
 * - Never marks a manual payment as `'verified'` until the authorized owner verifies the TrxID.
 * - Never collects raw credit/debit card numbers.
 */

import { isValidBangladeshPhone } from '../utils/validation';

export type PaymentMethodType = 'cod' | 'bkash' | 'nagad';
export type PaymentStatusType =
  | 'cod_pending'
  | 'pending_verification'
  | 'verified'
  | 'rejected'
  | 'refunded';

export interface PaymentSubmissionInput {
  paymentMethod: PaymentMethodType;
  senderNumber?: string;
  transactionId?: string;
  enableCod?: boolean;
  enableBkash?: boolean;
  enableNagad?: boolean;
}

export interface PaymentValidationResult {
  valid: boolean;
  initialPaymentStatus?: PaymentStatusType;
  error?: string;
}

export function validatePaymentSubmission(
  input: PaymentSubmissionInput
): PaymentValidationResult {
  const method = input.paymentMethod;
  if (!['cod', 'bkash', 'nagad'].includes(method)) {
    return { valid: false, error: 'Unsupported payment method selected.' };
  }

  if (method === 'cod' && input.enableCod === false) {
    return { valid: false, error: 'Cash on Delivery is currently disabled by the store administrator.' };
  }
  if (method === 'bkash' && input.enableBkash === false) {
    return { valid: false, error: 'bKash payment is currently disabled by the store administrator.' };
  }
  if (method === 'nagad' && input.enableNagad === false) {
    return { valid: false, error: 'Nagad payment is currently disabled by the store administrator.' };
  }

  if (method === 'cod') {
    return {
      valid: true,
      initialPaymentStatus: 'cod_pending',
    };
  }

  const sender = String(input.senderNumber || '').trim();
  const trxId = String(input.transactionId || '').trim();

  if (!isValidBangladeshPhone(sender)) {
    return {
      valid: false,
      error: `Please enter the valid 11-digit ${method === 'bkash' ? 'bKash' : 'Nagad'} sender mobile number.`,
    };
  }

  if (trxId.length < 4 || trxId.length > 60 || !/^[a-zA-Z0-9_-]+$/.test(trxId)) {
    return {
      valid: false,
      error: 'Please enter a valid alphanumeric Transaction ID (TrxID) for manual verification.',
    };
  }

  // Manual payments MUST remain pending until owner verification
  return {
    valid: true,
    initialPaymentStatus: 'pending_verification',
  };
}
