/**
 * Store BD Online — Authentication & 5-Step Email OTP Client Module
 *
 * Enforces:
 * - Registration before login (login never auto-creates an account).
 * - Non-existent login attempts return: "Account not found. Please create an account first."
 * - No plaintext or localStorage passwords.
 * - Real 5-step server-backed 6-digit Email OTP password reset flow.
 */

import { isValidEmail, isValidSixDigitOtp, validateRegistrationInput } from '../utils/validation';

export const ACCOUNT_NOT_FOUND_MESSAGE = 'Account not found. Please create an account first.';
export const PASSWORD_CHANGED_SUCCESS_MESSAGE = 'Your password has been successfully changed.';

/**
 * Maps Firebase Auth error codes on login to user-facing messages.
 * Ensures login never creates an account and returns the required message when unregistered.
 */
export function mapFirebaseLoginError(errorCode: string, fallbackMessage?: string): string {
  switch (errorCode) {
    case 'auth/user-not-found':
    case 'auth/invalid-credential':
    case 'auth/invalid-login-credentials':
      return ACCOUNT_NOT_FOUND_MESSAGE;
    case 'auth/wrong-password':
      return 'Incorrect password. Please try again or reset your password.';
    case 'auth/too-many-requests':
      return 'Too many failed sign-in attempts. Please wait a few minutes or reset your password.';
    case 'auth/user-disabled':
      return 'This account has been suspended. Please contact customer support.';
    default:
      return fallbackMessage || 'Unable to sign in. Please verify your email and password.';
  }
}

/**
 * Maps Firebase Auth error codes on registration to user-facing messages.
 */
export function mapFirebaseRegistrationError(errorCode: string, fallbackMessage?: string): string {
  switch (errorCode) {
    case 'auth/email-already-in-use':
      return 'An account with this email already exists. Please sign in instead.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters long.';
    default:
      return fallbackMessage || 'Unable to create account. Please check your details and try again.';
  }
}

/**
 * Client API calls for the 5-step Forgot Password Email OTP flow.
 */
export async function requestEmailOtpCode(params: {
  email: string;
  storeName?: string;
  tagline?: string;
  logoUrl?: string;
}): Promise<{
  ok: boolean;
  code: string;
  message: string;
  cooldownSeconds?: number;
  expiresInSeconds?: number;
}> {
  if (!isValidEmail(params.email)) {
    return {
      ok: false,
      code: 'INVALID_EMAIL',
      message: 'Please enter a valid registered email address.',
    };
  }

  const res = await fetch('/api/auth/otp/request', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return await res.json();
}

export async function verifyEmailOtpCode(params: {
  email: string;
  otp: string;
}): Promise<{
  ok: boolean;
  code: string;
  message: string;
  resetSessionToken?: string;
  remainingAttempts?: number;
}> {
  const cleanOtp = String(params.otp || '').replace(/\D/g, '').slice(0, 6);
  if (!isValidSixDigitOtp(cleanOtp)) {
    return {
      ok: false,
      code: 'INVALID_OTP_FORMAT',
      message: 'Please enter a valid 6-digit numeric verification code.',
    };
  }

  const res = await fetch('/api/auth/otp/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: params.email, otp: cleanOtp }),
  });
  return await res.json();
}

export async function resetPasswordWithOtpToken(params: {
  email: string;
  resetSessionToken: string;
  newPassword: string;
  confirmPassword: string;
}): Promise<{
  ok: boolean;
  code: string;
  message: string;
}> {
  const res = await fetch('/api/auth/otp/reset-password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return await res.json();
}

export { validateRegistrationInput };
