# 5-Step Forgot Password Email OTP Setup Guide (`EMAIL_OTP_SETUP.md`)

**Store BD Online** includes a real, server-backed 5-step Forgot Password Email OTP system (`POST /api/auth/otp/request`, `POST /api/auth/otp/verify`, `POST /api/auth/otp/reset-password`).

---

## 1. How the 5-Step Email OTP Flow Works

1. **Step 1 — Request Reset**: The customer clicks **Forgot Password?**, enters their registered email address, and clicks **Send Verification Code**.
2. **Step 2 — Branded Email Delivery**: The server generates a 6-digit numeric OTP, stores its `HMAC-SHA256` digest, and sends an HTML email with subject:
   `Your Store BD Online Password Reset Code`
3. **Step 3 — 6-Digit OTP Verification**: The customer enters the 6-digit code in the modal (supports numeric keypad, paste, 10-minute expiration countdown, and 60-second resend cooldown).
4. **Step 4 — Set New Password**: Upon verification, the server issues a single-use `resetSessionToken`. The customer enters `New Password` and `Confirm New Password` and clicks **Update Password**.
5. **Step 5 — Confirmation**: The server updates the user's password in Firebase Authentication, invalidates the challenge, and displays:
   `"Your password has been successfully changed."`

---

## 2. Configuring Resend (Recommended Email Provider)

1. Create a free or production account at [https://resend.com](https://resend.com).
2. Verify your sending domain (e.g. `yourdomain.com`) in the Resend dashboard.
3. Generate an API key (`re_...`).
4. Set the following variables in `.env` (or Cloud Run / Docker environment):
   ```env
   OTP_HASH_SECRET="generate_a_64_char_random_hex_string_here"
   RESEND_API_KEY="re_your_actual_resend_api_key"
   MAIL_FROM="Store BD Online <no-reply@yourdomain.com>"
   ```

---

## 3. Alternative: Custom SMTP / HTTP Relay Webhook

If you prefer to send emails via your own SMTP microservice or webhook relay instead of Resend, configure:

```env
OTP_HASH_SECRET="generate_a_64_char_random_hex_string_here"
SMTP_RELAY_URL="https://your-mail-relay.example.com/send"
SMTP_RELAY_KEY="your_relay_bearer_token"
MAIL_FROM="Store BD Online <no-reply@yourdomain.com>"
```

The server will `POST` JSON `{ from, to, subject, html }` to `SMTP_RELAY_URL`.

---

## 4. Configuring Server-Side Firebase Admin Password Updates

To allow `POST /api/auth/otp/reset-password` to update a user's Firebase Authentication password after OTP verification:

1. In Google Cloud / Firebase Console, generate an Admin OAuth2 access token or service account with Identity Toolkit Admin permissions (`roles/firebaseauth.admin`).
2. Provide `FIREBASE_ADMIN_BEARER_TOKEN` and `FIREBASE_PROJECT_ID="gen-lang-client-0128050017"` in your server environment.
3. Alternatively, deploy the included Firebase Cloud Functions in `/functions` (`firebase deploy --only functions`), which automatically use `firebase-admin` default service account credentials (`admin.auth().updateUser(uid, { password })`).

---

## 5. Honest Unconfigured State

If neither `RESEND_API_KEY` nor `SMTP_RELAY_URL` is configured on the server, `/api/auth/otp/request` returns HTTP `503` (`EMAIL_PROVIDER_NOT_CONFIGURED`) with a clear setup message. It never fakes email delivery or exposes OTP codes in browser responses or logs.
