# Website Branding & Logo Customization Guide (`BRANDING_GUIDE.md`)

**Store BD Online** provides a dedicated **WEBSITE BRANDING & CUSTOMIZATION** (`🎨 Website Branding & Customization`) module inside the Owner Admin Dashboard so you can update your store logo, favicon, colors, and identity from desktop or mobile without editing code.

---

## 1. Logo Management Features

Inside **Admin Dashboard → 🎨 Website Branding & Customization → LOGO MANAGEMENT**:

- **Upload New Logo / Select From Device**: Opens the native desktop or mobile file picker.
- **Supported Image Formats**:
  - `PNG` (`image/png`)
  - `JPG` / `JPEG` (`image/jpeg`)
  - `WebP` (`image/webp`)
  - `Transparent PNG` (alpha channel is preserved cleanly; never forced onto a black or white rectangular background).
- **File Size Limit**: Up to `5 MB` per image.
- **Live Logo Preview**: Preview your selected logo on a transparency checkerboard before publishing.
- **Replace Existing Logo**: Upload a new logo file to replace the active store logo.
- **Remove Current Logo**: Hide the logo image across the storefront (`logoUrl = "NONE"`) while keeping your text brand name active.
- **Reset to Default Logo**: One-click restore to the default Store BD Online logo (`/assets/aistudio/image_cd2fbd85.png`).
- **Separate Favicon Upload**: Use the main logo as your browser favicon or upload a dedicated icon.

---

## 2. 9 Storefront Locations Updated Automatically

When you click **Live Preview** or **Save & Publish Branding Changes**, the logo and brand settings immediately update all 9 storefront locations:

1. **Desktop Header** (`#headerSiteName`, `#headerTagline`, `.brand-logo-img`)
2. **Mobile Header**
3. **Mobile Navigation Drawer** (`#drawerSiteName`, `#drawerTagline`)
4. **Footer Brand Block** (`#footerSiteName`, `#footerTagline`, `#footerAboutText`, `#footerCopyrightText`)
5. **Authentication & 5-Step OTP Modals**
6. **Checkout & Order Confirmation View**
7. **Printable Order Invoice**
8. **Owner Admin Dashboard Sidebar Header**
9. **Browser Tab Title, Meta Description & Favicon** (`document.title`, `<link rel="icon">`, OpenGraph meta tags)

---

## 3. Full Brand Identity & Color Customization

You can also customize and persist in `/settings/store`:
- **Store / Website Name** & **Tagline / Slogan**
- **Primary Brand Color**, **Secondary Accent Color**, **Button Color**, **Header Background Color**, and **Footer Background Color**
- **Announcement Bar Text** & **Store Description**
- **Contact Email**, **Contact Phone**, **WhatsApp Country Code & Number**, **Facebook Page & Messenger URLs**, and **Business Address**
- **SEO Title** & **SEO Description**
