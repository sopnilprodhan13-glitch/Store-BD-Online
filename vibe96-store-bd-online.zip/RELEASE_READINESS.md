# Final Release Readiness Checklist (`RELEASE_READINESS.md`)

**Product Name:** Store BD Online (`STORE BD ONLINE — Shop Smart • Save More`)  
**Release Version:** `1.0.0`  
**Owner Administrator:** `sopnilprodhan13@gmail.com`

---

## 1. Mandatory Feature Verification

- [x] **Single-Store E-Commerce Positioning**: Framed strictly as a complete single-store e-commerce application for one store owner's business and brand.
- [x] **Customer Registration & Login**:
  - [x] Registration requires Full Name, Email, BD Mobile Number (`01XXXXXXXXX`), Password, and Confirm Password.
  - [x] Login never auto-creates accounts and returns `"Account not found. Please create an account first."` for unregistered emails.
  - [x] Zero passwords or password hashes stored in `localStorage` or Firestore.
- [x] **5-Step Forgot Password Email OTP System**:
  - [x] Step 1: Registered Email Address input, `Send Verification Code` button, `Back to Login` link.
  - [x] Step 2: Branded HTML email (`"Your Store BD Online Password Reset Code"`) via Resend or SMTP relay, or honest `503 EMAIL_PROVIDER_NOT_CONFIGURED` setup message when unconfigured.
  - [x] Step 3: 6-digit numeric OTP input (paste support, mobile numeric keypad, 10-minute expiration countdown, 60-second resend cooldown, max 5 failed attempts lockout).
  - [x] Step 4: `New Password` + `Confirm New Password` + `Update Password` button.
  - [x] Step 5: `"Your password has been successfully changed."` + `Return to Login` button.
- [x] **Admin Logo & Brand Customization (`WEBSITE BRANDING & CUSTOMIZATION`)**:
  - [x] Upload New Logo / Select From Device (desktop & mobile file picker).
  - [x] Validates `PNG`, `JPG`, `JPEG`, `WebP`, and `Transparent PNG` up to `5MB`.
  - [x] Live Logo Preview, Replace Existing Logo, Remove Current Logo, Reset to Default Logo, Separate Favicon upload, and Save/Publish Changes across all 9 storefront locations.
- [x] **Owner Admin Security**:
  - [x] Restricted exclusively to `sopnilprodhan13@gmail.com` (`email_verified == true`) in UI, `firestore.rules`, and `storage.rules`.
  - [x] Non-admin visitors see no Admin links and receive `"Access Denied — Administrator Only"` if navigating to the Admin view.

---

## 2. Deliverables Inventory

- [x] **Source Code**: `index.html`, `server.ts`, `src/**`, `functions/**`, `tests/storebd.test.ts`
- [x] **Security Rules & Indexes**: `firestore.rules`, `storage.rules`, `firestore.indexes.json`, `firebase-blueprint.json`
- [x] **Deployment Configs**: `Dockerfile`, `.dockerignore`, `docker-compose.yml`, `cloudbuild.yaml`, `.env.example`
- [x] **14 Documentation Files**: `README.md`, `HowToSetup.md`, `AGENTS.md`, `DATABASE_SCHEMA.md`, `SECURITY.md`, `EMAIL_OTP_SETUP.md`, `ADMIN_SETUP.md`, `BRANDING_GUIDE.md`, `PAYMENT_SETUP.md`, `DEPLOYMENT.md`, `CHANGELOG.md`, `AUDIT_REPORT.md`, `RELEASE_READINESS.md`, `.env.example`
- [x] **5 Real 1920×1080 Application Screenshots**:
  - `public/assets/screenshots/01-homepage-desktop.png`
  - `public/assets/screenshots/02-product-listing-category.png`
  - `public/assets/screenshots/03-product-detail-page.png`
  - `public/assets/screenshots/04-shopping-cart-checkout.png`
  - `public/assets/screenshots/05-owner-admin-branding.png`
- [x] **Clean Release Archive**: `public/store-bd-online-release.zip`
