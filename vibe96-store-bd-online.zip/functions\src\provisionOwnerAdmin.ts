/**
 * Store BD Online — Secure Owner Admin Account Provisioning Script
 *
 * Usage (Server / Administrator CLI only — never run in browser):
 *   GOOGLE_APPLICATION_CREDENTIALS="/path/to/serviceAccountKey.json" \
 *   npx tsx functions/src/provisionOwnerAdmin.ts
 *
 * Ensures that ONLY `sopnilprodhan13@gmail.com` is provisioned in `/admins/{uid}`
 * without ever hardcoding an admin password in source code.
 */

import { ADMIN_OWNER_EMAIL } from '../../src/utils/validation';

export interface AdminProvisionResult {
  uid: string;
  email: string;
  customClaimSet: boolean;
  adminDocPath: string;
}

export function buildOwnerAdminDocument(uid: string, timestampIso = new Date().toISOString()) {
  if (!uid || typeof uid !== 'string') {
    throw new Error('Valid Firebase Auth UID is required to provision the owner admin document.');
  }
  return {
    uid,
    email: ADMIN_OWNER_EMAIL,
    createdAt: timestampIso,
  };
}
