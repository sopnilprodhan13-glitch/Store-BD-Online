import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword,
  updateProfile,
  signOut
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  initializeFirestore,
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  writeBatch,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js';

// =========================================================================
// 10. SHOPPING CART & COUPON ENGINE
// =========================================================================
function saveCart() {
  localStorage.setItem('sbd_cart', JSON.stringify(state.cart));
  updateCountersUI();
  renderCartDrawer();
  if (state.currentView === 'checkout') renderCheckoutView();
}

function addToCart(productId, qty = 1, openDrawer = true) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  if (product.stock <= 0) {
    showToast('Sorry, this product is currently out of stock.');
    return;
  }

  const existing = state.cart.find(item => item.productId === productId);
  const currentQty = existing ? existing.qty : 0;
  if (currentQty + qty > product.stock) {
    showToast(`Maximum available stock (${product.stock}) reached.`);
    return;
  }

  if (existing) {
    existing.qty += qty;
  } else {
    state.cart.push({ productId, qty });
  }
  saveCart();
  showToast(`Added "${product.name}" to cart`);
  if (openDrawer) toggleCartDrawer(true);
}

function updateCartQty(productId, delta) {
  const item = state.cart.find(c => c.productId === productId);
  const product = state.products.find(p => p.id === productId);
  if (!item || !product) return;

  const nextQty = item.qty + delta;
  if (nextQty <= 0) {
    state.cart = state.cart.filter(c => c.productId !== productId);
  } else if (nextQty > product.stock) {
    showToast(`Only ${product.stock} units available in stock.`);
    return;
  } else {
    item.qty = nextQty;
  }
  saveCart();
}

function calculateCartTotals(division = 'Dhaka') {
  let subtotal = 0;
  let totalQty = 0;
  const detailedItems = [];

  for (const item of state.cart) {
    const p = state.products.find(prod => prod.id === item.productId);
    if (!p) continue;
    const unitPrice = p.discountPrice && p.discountPrice < p.regularPrice ? p.discountPrice : p.regularPrice;
    const lineTotal = unitPrice * item.qty;
    subtotal += lineTotal;
    totalQty += item.qty;
    detailedItems.push({
      ...p,
      qty: item.qty,
      unitPrice,
      lineTotal
    });
  }

  let discount = 0;
  if (state.appliedCoupon) {
    const c = state.appliedCoupon;
    if (subtotal >= (c.minOrder || 0)) {
      discount = c.discountType === 'percentage'
        ? Math.round((subtotal * c.discountValue) / 100)
        : Math.round(c.discountValue);
      discount = Math.min(discount, subtotal);
    }
  }

  const afterDiscount = Math.max(0, subtotal - discount);
  const baseFee = division === 'Dhaka'
    ? Number(state.settings.insideDhakaFee ?? 60)
    : Number(state.settings.outsideDhakaFee ?? 120);
  const freeThreshold = Number(state.settings.freeDeliveryThreshold ?? 3000);
  const deliveryFee = detailedItems.length === 0
    ? 0
    : (afterDiscount >= freeThreshold ? 0 : baseFee);

  const grandTotal = afterDiscount + deliveryFee;
  return { detailedItems, totalQty, subtotal, discount, deliveryFee, grandTotal };
}

function renderCartDrawer() {
  const listEl = document.getElementById('cartItemsList');
  const footerEl = document.getElementById('cartDrawerFooter');
  if (!listEl || !footerEl) return;

  const { detailedItems, subtotal, discount, deliveryFee, grandTotal } = calculateCartTotals('Dhaka');

  if (detailedItems.length === 0) {
    listEl.innerHTML = `
      <div style="text-align:center;padding:48px 16px;">
        <p style="font-weight:700;font-size:16px;margin-bottom:6px;">Your shopping cart is empty</p>
        <p style="font-size:13px;color:var(--text-secondary);margin-bottom:16px;">Explore our latest smart gadgets and deals to start shopping.</p>
        <button type="button" class="btn btn-red" id="emptyCartShopBtn">Start Shopping</button>
      </div>
    `;
    footerEl.innerHTML = '';
    document.getElementById('emptyCartShopBtn')?.addEventListener('click', () => {
      toggleCartDrawer(false);
      switchView('shop');
    });
    return;
  }

  listEl.innerHTML = detailedItems.map(item => `
    <div style="display:flex;gap:12px;padding:12px 0;border-bottom:1px solid var(--border-subtle);">
      <img src="${escapeHtml(item.images?.[0] || '')}" alt="${escapeHtml(item.name)}" style="width:64px;height:64px;border-radius:8px;object-fit:cover;background:#F3F4F6;flex-shrink:0;" referrerpolicy="no-referrer" />
      <div style="flex:1;min-width:0;">
        <div style="font-size:13.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(item.name)}</div>
        <div style="font-size:12px;color:var(--text-secondary);" class="tabular-nums">${formatPrice(item.unitPrice)} × ${item.qty} = <strong style="color:var(--brand-black);">${formatPrice(item.lineTotal)}</strong></div>
        <div style="display:flex;align-items:center;gap:8px;margin-top:6px;">
          <button type="button" data-cart-dec="${escapeHtml(item.id)}" style="width:26px;height:26px;border-radius:6px;border:1px solid var(--border-light);font-weight:800;">−</button>
          <span class="tabular-nums" style="font-size:13px;font-weight:700;">${item.qty}</span>
          <button type="button" data-cart-inc="${escapeHtml(item.id)}" style="width:26px;height:26px;border-radius:6px;border:1px solid var(--border-light);font-weight:800;">+</button>
          <button type="button" data-cart-rem="${escapeHtml(item.id)}" style="margin-left:auto;font-size:12px;color:var(--danger);font-weight:600;">Remove</button>
        </div>
      </div>
    </div>
  `).join('');

  footerEl.innerHTML = `
    <div style="display:flex;gap:8px;margin-bottom:12px;">
      <input type="text" id="drawerCouponInput" class="form-control" placeholder="Coupon code (e.g. SAVE10)" value="${escapeHtml(state.appliedCoupon?.code || '')}" style="padding:8px 12px;font-size:13px;" />
      ${state.appliedCoupon
        ? `<button type="button" class="btn btn-outline" id="removeCouponBtn" style="padding:8px 12px;">Remove</button>`
        : `<button type="button" class="btn btn-black" id="applyCouponBtn" style="padding:8px 14px;">Apply</button>`
      }
    </div>
    <div style="font-size:13px;display:flex;flex-direction:column;gap:4px;margin-bottom:14px;" class="tabular-nums">
      <div style="display:flex;justify-content:space-between;"><span>Subtotal</span><span>${formatPrice(subtotal)}</span></div>
      ${discount > 0 ? `<div style="display:flex;justify-content:space-between;color:var(--success);"><span>Coupon Discount (${escapeHtml(state.appliedCoupon.code)})</span><span>−${formatPrice(discount)}</span></div>` : ''}
      <div style="display:flex;justify-content:space-between;"><span>Estimated Delivery</span><span>${deliveryFee === 0 ? 'FREE' : formatPrice(deliveryFee)}</span></div>
      <div style="display:flex;justify-content:space-between;font-size:16px;font-weight:800;border-top:1px solid var(--border-light);padding-top:8px;margin-top:4px;">
        <span>Total</span><span style="color:var(--brand-red);">${formatPrice(grandTotal)}</span>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
      <button type="button" class="btn btn-outline" id="drawerContinueBtn">Continue</button>
      <button type="button" class="btn btn-red" id="drawerCheckoutBtn">Checkout →</button>
    </div>
  `;

  document.getElementById('applyCouponBtn')?.addEventListener('click', () => {
    const code = (document.getElementById('drawerCouponInput')?.value || '').trim().toUpperCase();
    applyCouponCode(code, subtotal);
  });
  document.getElementById('removeCouponBtn')?.addEventListener('click', () => {
    state.appliedCoupon = null;
    showToast('Coupon removed');
    renderCartDrawer();
    if (state.currentView === 'checkout') renderCheckoutView();
  });
  document.getElementById('drawerContinueBtn')?.addEventListener('click', () => toggleCartDrawer(false));
  document.getElementById('drawerCheckoutBtn')?.addEventListener('click', () => {
    toggleCartDrawer(false);
    if (!state.currentUser) {
      showToast('Please sign in or create an account to place an order.');
      openAuthModal('login');
      return;
    }
    switchView('checkout');
  });
}

function applyCouponCode(code, subtotal) {
  if (!code) return;
  const found = state.coupons.find(c => c.code.toUpperCase() === code && c.active !== false);
  if (!found) {
    showToast('Invalid or inactive coupon code.');
    return;
  }
  if (subtotal < (found.minOrder || 0)) {
    showToast(`Minimum order of ${formatPrice(found.minOrder)} required for ${found.code}.`);
    return;
  }
  if ((found.usedCount || 0) >= (found.maxUsage || 999999)) {
    showToast('This coupon has reached its usage limit.');
    return;
  }
  state.appliedCoupon = found;
  showToast(`Coupon ${found.code} applied!`);
  renderCartDrawer();
  if (state.currentView === 'checkout') renderCheckoutView();
}

// =========================================================================
// 11. BANGLADESH CHECKOUT SYSTEM & ATOMIC ORDER CREATION
// =========================================================================
function renderCheckoutView() {
  const container = document.getElementById('checkoutLayoutGrid');
  if (!container) return;

  const selectedDiv = document.getElementById('chkDivision')?.value || state.userProfile?.division || 'Dhaka';
  const { detailedItems, totalQty, subtotal, discount, deliveryFee, grandTotal } = calculateCartTotals(selectedDiv);

  if (detailedItems.length === 0) {
    container.innerHTML = `
      <div style="background:var(--bg-white);padding:36px;border-radius:var(--radius-md);text-align:center;border:1px solid var(--border-light);">
        <h3 style="font-size:18px;font-weight:800;margin-bottom:8px;">Your cart is empty</h3>
        <p style="font-size:13.5px;color:var(--text-secondary);margin-bottom:16px;">Add products to your cart before proceeding to checkout.</p>
        <button type="button" class="btn btn-red" data-nav="shop">Return to Shop</button>
      </div>
    `;
    return;
  }

  if (!state.currentUser) {
    container.innerHTML = `
      <div style="background:var(--bg-white);padding:42px 24px;border-radius:var(--radius-lg);text-align:center;border:1px solid var(--border-light);max-width:540px;margin:24px auto;">
        <div style="font-size:36px;margin-bottom:12px;">🔒</div>
        <h3 style="font-size:20px;font-weight:800;margin-bottom:8px;">Sign In Required to Order</h3>
        <p style="font-size:14px;color:var(--text-secondary);margin-bottom:20px;">
          অর্ডার কনফার্ম করতে অনুগ্রহ করে প্রথমে সাইন ইন করুন বা একটি অ্যাকাউন্ট তৈরি করুন।
        </p>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
          <button type="button" class="btn btn-red" id="chkSignInPromptBtn" style="min-width:140px;height:44px;">Sign In</button>
          <button type="button" class="btn btn-outline" id="chkRegPromptBtn" style="min-width:140px;height:44px;">Create Account</button>
        </div>
      </div>
    `;
    document.getElementById('chkSignInPromptBtn')?.addEventListener('click', () => openAuthModal('login'));
    document.getElementById('chkRegPromptBtn')?.addEventListener('click', () => openAuthModal('register'));
    return;
  }

  const divisions = Object.keys(BD_DIVISIONS);
  const districts = BD_DIVISIONS[selectedDiv] || BD_DIVISIONS['Dhaka'];

  const s = state.settings;
  const showCod = s.enableCod !== false;
  const showBkash = s.enableBkash !== false;
  const showNagad = s.enableNagad !== false;

  container.innerHTML = `
    <form id="checkoutOrderForm" style="display:grid;grid-template-columns:1fr;gap:24px;" class="checkout-2col">
      <div style="background:var(--bg-white);padding:22px;border-radius:var(--radius-lg);border:1px solid var(--border-light);">
        <h2 style="font-size:17px;font-weight:800;margin-bottom:14px;">1. Delivery Information (Bangladesh)</h2>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label" for="chkName">Full Name *</label>
            <input type="text" id="chkName" class="form-control" required maxlength="110" value="${escapeHtml(state.userProfile?.name || state.currentUser?.displayName || '')}" placeholder="e.g. Tanvir Ahmed" />
          </div>
          <div class="form-group">
            <label class="form-label" for="chkPhone">Mobile Number (BD) *</label>
            <input type="tel" id="chkPhone" class="form-control" required maxlength="16" value="${escapeHtml(state.userProfile?.phone || '')}" placeholder="017XXXXXXXX" />
          </div>
        </div>

        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label" for="chkEmail">Email Address</label>
            <input type="email" id="chkEmail" class="form-control" maxlength="240" value="${escapeHtml(state.userProfile?.email || state.currentUser?.email || '')}" placeholder="you@example.com" />
          </div>
          <div class="form-group">
            <label class="form-label" for="chkDivision">Division *</label>
            <select id="chkDivision" class="form-control" required>
              ${divisions.map(d => `<option value="${escapeHtml(d)}" ${d === selectedDiv ? 'selected' : ''}>${escapeHtml(d)}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label" for="chkDistrict">District *</label>
            <select id="chkDistrict" class="form-control" required>
              ${districts.map(dist => `<option value="${escapeHtml(dist)}" ${dist === state.userProfile?.district ? 'selected' : ''}>${escapeHtml(dist)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" for="chkUpazila">Upazila / Thana *</label>
            <input type="text" id="chkUpazila" class="form-control" required maxlength="55" value="${escapeHtml(state.userProfile?.upazila || '')}" placeholder="e.g. Uttara / Dhanmondi" />
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="chkArea">Delivery Area / Landmark *</label>
          <input type="text" id="chkArea" class="form-control" required maxlength="95" placeholder="e.g. Sector 7, Road 12" />
        </div>

        <div class="form-group">
          <label class="form-label" for="chkAddress">Full Street Address *</label>
          <textarea id="chkAddress" class="form-control" rows="2" required minlength="4" maxlength="550" placeholder="House #, Road #, Flat #, Block">${escapeHtml(state.userProfile?.address || '')}</textarea>
        </div>

        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label" for="chkInstructions">Additional Delivery Instructions (Optional)</label>
          <input type="text" id="chkInstructions" class="form-control" maxlength="450" placeholder="e.g. Call before delivery" />
        </div>

        <hr style="border:none;border-top:1px solid var(--border-light);margin:20px 0;" />

        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:12px;">
          <h2 style="font-size:17px;font-weight:800;">2. Payment Method</h2>
          <span style="font-size:11.5px;font-weight:700;color:#8A5700;background:#FFF8E1;padding:4px 10px;border-radius:6px;border:1px solid #FDE68A;">Demo / Manual Verification Mode</span>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:14px;">
          ${showCod ? `
            <label style="border:2px solid var(--brand-red);border-radius:var(--radius-sm);padding:12px;cursor:pointer;display:flex;flex-direction:column;gap:4px;" id="payLabelCod">
              <input type="radio" name="paymentMethod" value="cod" checked />
              <strong style="font-size:13px;">Cash on Delivery</strong>
              <span style="font-size:11px;color:var(--text-secondary);">Pay when you receive</span>
            </label>
          ` : ''}
          ${showBkash ? `
            <label style="border:1.5px solid var(--border-light);border-radius:var(--radius-sm);padding:12px;cursor:pointer;display:flex;flex-direction:column;gap:4px;" id="payLabelBkash">
              <input type="radio" name="paymentMethod" value="bkash" ${!showCod ? 'checked' : ''} />
              <strong style="font-size:13px;color:#E2136E;">bKash (Manual)</strong>
              <span style="font-size:11px;color:var(--text-secondary);">${escapeHtml(s.bkashNumber || 'Not configured')}</span>
            </label>
          ` : ''}
          ${showNagad ? `
            <label style="border:1.5px solid var(--border-light);border-radius:var(--radius-sm);padding:12px;cursor:pointer;display:flex;flex-direction:column;gap:4px;" id="payLabelNagad">
              <input type="radio" name="paymentMethod" value="nagad" ${(!showCod && !showBkash) ? 'checked' : ''} />
              <strong style="font-size:13px;color:#F7941D;">Nagad (Manual)</strong>
              <span style="font-size:11px;color:var(--text-secondary);">${escapeHtml(s.nagadNumber || 'Not configured')}</span>
            </label>
          ` : ''}
        </div>

        <div id="manualPaymentBox" style="display:${!showCod && (showBkash || showNagad) ? 'block' : 'none'};background:#FFFBEB;border:1px solid #FDE68A;padding:14px;border-radius:var(--radius-sm);">
          <div style="font-size:13px;font-weight:700;margin-bottom:6px;color:#92400E;">
            Manual Mobile Payment (<span id="manualPayProviderName">bKash</span> — ${escapeHtml(s.paymentAccountType || 'Demo Mode')})
          </div>
          <p style="font-size:12.5px;color:#78350F;margin-bottom:10px;">
            1. Send <strong class="tabular-nums">${formatPrice(grandTotal)}</strong> to number: <strong id="manualPayTargetNumber">${escapeHtml(s.bkashNumber || 'Not configured')}</strong>.<br/>
            2. ${escapeHtml(s.paymentInstructions || 'Enter your Sender Mobile Number and Transaction ID (TrxID) below.')}<br/>
            3. Status will be marked as <strong>Pending Verification</strong> until verified by Admin.
          </p>
          <div class="form-grid-2">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label" for="chkSenderNumber">Sender bKash/Nagad Number *</label>
              <input type="tel" id="chkSenderNumber" class="form-control" maxlength="20" placeholder="017XXXXXXXX" />
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label" for="chkTrxId">Transaction ID (TrxID) *</label>
              <input type="text" id="chkTrxId" class="form-control" maxlength="60" placeholder="e.g. BKA8291XYZ" />
            </div>
          </div>
        </div>
      </div>

      <div style="background:var(--bg-white);padding:22px;border-radius:var(--radius-lg);border:1px solid var(--border-light);height:fit-content;">
        <h2 style="font-size:17px;font-weight:800;margin-bottom:14px;">3. Order Summary (${totalQty} items)</h2>
        <div style="max-height:260px;overflow-y:auto;margin-bottom:14px;">
          ${detailedItems.map(item => `
            <div style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--border-subtle);font-size:13px;">
              <span>${escapeHtml(item.name)} <strong>× ${item.qty}</strong></span>
              <span class="tabular-nums" style="font-weight:700;">${formatPrice(item.lineTotal)}</span>
            </div>
          `).join('')}
        </div>

        <div style="display:flex;flex-direction:column;gap:6px;font-size:13.5px;margin-bottom:16px;" class="tabular-nums">
          <div style="display:flex;justify-content:space-between;"><span>Subtotal</span><span>${formatPrice(subtotal)}</span></div>
          <div style="display:flex;justify-content:space-between;color:var(--success);"><span>Discount</span><span>−${formatPrice(discount)}</span></div>
          <div style="display:flex;justify-content:space-between;"><span>Delivery Charge (${escapeHtml(selectedDiv)})</span><span>${deliveryFee === 0 ? 'FREE' : formatPrice(deliveryFee)}</span></div>
          <div style="display:flex;justify-content:space-between;font-size:18px;font-weight:800;border-top:1.5px solid var(--border-light);padding-top:10px;margin-top:4px;">
            <span>Grand Total</span>
            <span style="color:var(--brand-red);">${formatPrice(grandTotal)}</span>
          </div>
        </div>

        <button type="submit" class="btn btn-red" id="submitOrderBtn" style="width:100%;height:48px;font-size:15px;">
          Place Order (${formatPrice(grandTotal)})
        </button>
      </div>
    </form>
  `;

  const formEl = document.getElementById('checkoutOrderForm');
  if (formEl && window.innerWidth >= 960) {
    formEl.style.gridTemplateColumns = '1.35fr 0.9fr';
  }

  document.getElementById('chkDivision')?.addEventListener('change', () => renderCheckoutView());

  formEl?.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const val = e.target.value;
      const manualBox = document.getElementById('manualPaymentBox');
      const providerName = document.getElementById('manualPayProviderName');
      const targetNum = document.getElementById('manualPayTargetNumber');
      const trxInput = document.getElementById('chkTrxId');
      const senderInput = document.getElementById('chkSenderNumber');

      if (val === 'bkash' || val === 'nagad') {
        manualBox.style.display = 'block';
        providerName.textContent = val === 'bkash' ? 'bKash' : 'Nagad';
        targetNum.textContent = val === 'bkash' ? state.settings.bkashNumber : state.settings.nagadNumber;
        trxInput.required = true;
        senderInput.required = true;
      } else {
        manualBox.style.display = 'none';
        trxInput.required = false;
        senderInput.required = false;
      }
    });
  });

  formEl?.addEventListener('submit', handleCheckoutSubmit);
}

async function handleCheckoutSubmit(e) {
  e.preventDefault();
  if (state.isSubmittingOrder) return;

  const phone = document.getElementById('chkPhone').value.trim();
  const bdPhoneRegex = /^(?:\+?880|0)1[3-9]\d{8}$/;
  if (!bdPhoneRegex.test(phone.replace(/[\s-]/g, ''))) {
    showToast('Please enter a valid 11-digit Bangladeshi mobile number (e.g. 017XXXXXXXX).');
    return;
  }

  const division = document.getElementById('chkDivision').value;
  const { detailedItems, totalQty, subtotal, discount, deliveryFee, grandTotal } = calculateCartTotals(division);
  if (detailedItems.length === 0) return;

  const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cod';
  const senderNum = (document.getElementById('chkSenderNumber')?.value || '').trim();
  const trxId = (document.getElementById('chkTrxId')?.value || '').trim();

  if ((paymentMethod === 'bkash' || paymentMethod === 'nagad') && (!senderNum || !trxId)) {
    showToast('Please provide Sender Number and Transaction ID for manual payment verification.');
    return;
  }

  if (!state.currentUser) {
    showToast('Please sign in or create a quick account to save and track your order securely.');
    openAuthModal('login');
    return;
  }

  state.isSubmittingOrder = true;
  const btn = document.getElementById('submitOrderBtn');
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Processing Order...';
  }

  const orderNum = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
  const orderId = `ord_${Date.now()}`;
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const phoneLast4 = cleanPhone.slice(-4);
  const itemsSummary = detailedItems.map(i => `${i.name} (x${i.qty} @ ${formatPrice(i.unitPrice)})`).join(', ').slice(0, 3800);
  const paymentStatus = paymentMethod === 'cod' ? 'cod_pending' : 'pending_verification';

  const orderDoc = {
    id: orderId,
    orderNumber: orderNum,
    userId: state.currentUser.uid,
    customerName: document.getElementById('chkName').value.trim().slice(0, 115),
    customerPhone: cleanPhone.slice(0, 18),
    customerEmail: (document.getElementById('chkEmail').value || '').trim().slice(0, 250),
    division: division.slice(0, 55),
    district: document.getElementById('chkDistrict').value.slice(0, 55),
    upazila: document.getElementById('chkUpazila').value.trim().slice(0, 55),
    deliveryArea: document.getElementById('chkArea').value.trim().slice(0, 95),
    fullAddress: document.getElementById('chkAddress').value.trim().slice(0, 580),
    instructions: (document.getElementById('chkInstructions').value || '').trim().slice(0, 480),
    items: detailedItems.map(i => ({
      id: i.id,
      name: i.name,
      qty: i.qty,
      unitPrice: i.unitPrice,
      subtotal: i.subtotal,
      image: i.image || ''
    })),
    itemsSummary,
    itemCount: totalQty,
    subtotal,
    discount,
    deliveryFee,
    grandTotal,
    couponCode: (state.appliedCoupon?.code || '').slice(0, 35),
    paymentMethod,
    paymentNumber: senderNum.slice(0, 25),
    transactionId: trxId.slice(0, 75),
    paymentStatus,
    orderStatus: 'Order Placed',
    internalNotes: '',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };

  const trackingDoc = {
    id: orderId,
    orderNumber: orderNum,
    userId: state.currentUser.uid,
    phoneLast4,
    orderStatus: 'Order Placed',
    paymentMethod,
    paymentStatus,
    grandTotal,
    itemCount: totalQty,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };

  const isoNow = new Date().toISOString();
  let persistentOrder = {
    ...orderDoc,
    createdAt: isoNow,
    updatedAt: isoNow
  };

  try {
    const sResp = await fetch('/api/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${sessionStorage.getItem('sbd_server_session_token') || ''}`
      },
      body: JSON.stringify(persistentOrder)
    });
    if (sResp.ok) {
      const sData = await sResp.json();
      if (sData.order) persistentOrder = sData.order;
    }
  } catch (srvErr) {
    console.warn('Backend order persistence note:', srvErr);
  }

  const localOrders = JSON.parse(localStorage.getItem('sbd_local_orders') || '[]');
  localOrders.unshift(persistentOrder);
  localStorage.setItem('sbd_local_orders', JSON.stringify(localOrders));
  state.orders = [persistentOrder, ...state.orders.filter(o => o.id !== orderId)];

  try {
    if (auth.currentUser && !state.currentUser?.isLocalEmailAuth) {
      const batch = writeBatch(db);
      batch.set(doc(db, 'orders', orderId), orderDoc);
      batch.set(doc(db, 'orderTracking', orderId), trackingDoc);

      const notifId = `notif_${Date.now()}`;
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        targetUserId: state.currentUser.uid,
        title: `Order Placed: ${orderNum}`,
        message: `Your order of ${formatPrice(grandTotal)} has been placed (${paymentStatus === 'pending_verification' ? 'Payment Pending Verification' : 'Cash on Delivery'}).`,
        type: 'order_placed',
        orderId,
        read: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

      await batch.commit();
    } else {
      const notifId = `notif_${Date.now()}`;
      const localNotif = {
        id: notifId,
        targetUserId: state.currentUser.uid,
        title: `Order Placed: ${orderNum}`,
        message: `Your order of ${formatPrice(grandTotal)} has been placed (${paymentStatus === 'pending_verification' ? 'Payment Pending Verification' : 'Cash on Delivery'}).`,
        type: 'order_placed',
        orderId,
        read: false,
        createdAt: isoNow,
        updatedAt: isoNow
      };
      state.notifications = [localNotif, ...state.notifications];
      updateCountersUI();
    }

    state.cart = [];
    state.appliedCoupon = null;
    saveCart();
    renderOrderConfirmation(persistentOrder);
    switchView('confirmation');
    showToast(`Order ${orderNum} placed successfully!`);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `orders/${orderId}`);
  } finally {
    state.isSubmittingOrder = false;
  }
}

function renderOrderConfirmation(order) {
  const container = document.getElementById('orderConfirmationContainer');
  if (!container) return;
  const waOrderHelpUrl = getWhatsAppUrl(`Hello ${state.settings.siteName || 'STORE BD ONLINE'}, I need assistance with my Order ${order.orderNumber} (ID: ${order.id}, Total: ${formatPrice(order.grandTotal)}).`);
  container.innerHTML = `
    <div style="max-width:680px;margin:0 auto;background:var(--bg-white);padding:28px;border-radius:var(--radius-lg);border:1px solid var(--border-light);text-align:center;">
      <div style="width:60px;height:60px;border-radius:50%;background:rgba(16,185,129,0.12);color:var(--success);display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:800;margin-bottom:12px;">✓</div>
      <h1 class="section-title" style="margin-bottom:6px;">Order Confirmed — Thank You!</h1>
      <p style="font-size:14px;color:var(--text-secondary);margin-bottom:18px;">
        Your order <strong>${escapeHtml(order.orderNumber)}</strong> (Tracking ID: <code>${escapeHtml(order.id)}</code>) has been recorded.
      </p>
      <div style="text-align:left;background:var(--bg-light);padding:16px;border-radius:var(--radius-md);font-size:13.5px;display:flex;flex-direction:column;gap:6px;margin-bottom:20px;">
        <div><strong>Customer:</strong> ${escapeHtml(order.customerName)} (${escapeHtml(order.customerPhone)})</div>
        <div><strong>Delivery Address:</strong> ${escapeHtml(order.fullAddress)}, ${escapeHtml(order.upazila)}, ${escapeHtml(order.district)}, ${escapeHtml(order.division)}</div>
        <div><strong>Items:</strong> ${escapeHtml(order.itemsSummary)}</div>
        <div><strong>Payment Method:</strong> ${escapeHtml(order.paymentMethod.toUpperCase())} (${escapeHtml(order.paymentStatus.replace('_', ' ').toUpperCase())})</div>
        <div style="font-size:16px;font-weight:800;color:var(--brand-red);">Grand Total: ${formatPrice(order.grandTotal)}</div>
      </div>
      <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
        <button type="button" class="btn btn-red" id="trackThisOrderNowBtn">Track Order Progress</button>
        <a href="${escapeHtml(waOrderHelpUrl)}" target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="border-color:#25D366;color:#128C7E;">💬 Order Assistance (WhatsApp)</a>
        <button type="button" class="btn btn-outline" data-nav="shop">Continue Shopping</button>
      </div>
    </div>
  `;
  document.getElementById('trackThisOrderNowBtn')?.addEventListener('click', () => {
    document.getElementById('trackOrderIdInput').value = order.id;
    document.getElementById('trackPhoneInput').value = order.customerPhone;
    switchView('tracking');
    document.getElementById('orderTrackingForm')?.dispatchEvent(new Event('submit'));
  });
}

// =========================================================================
// 12. ORDER TRACKING TIMELINE
// =========================================================================
const ORDER_STATUS_STEPS = [
  'Order Placed',
  'Order Confirmed',
  'Processing',
  'Packed',
  'Shipped',
  'Out for Delivery',
  'Delivered'
];

async function handleOrderTrackingSubmit(e) {
  e.preventDefault();
  const inputId = document.getElementById('trackOrderIdInput').value.trim();
  const inputPhone = document.getElementById('trackPhoneInput').value.replace(/[^0-9]/g, '');
  const resultBox = document.getElementById('orderTrackingResult');
  if (!resultBox) return;

  if (inputPhone.length < 4) {
    showToast('Please enter at least the last 4 digits of the registered phone number.');
    return;
  }

  const last4 = inputPhone.slice(-4);
  let matched = state.orders.find(o =>
    (o.id === inputId || o.orderNumber === inputId) &&
    o.customerPhone.replace(/[^0-9]/g, '').endsWith(last4)
  );

  if (!matched && inputId.startsWith('ord_')) {
    try {
      const snap = await getDoc(doc(db, 'orderTracking', inputId));
      if (snap.exists() && snap.data().phoneLast4 === last4) {
        matched = snap.data();
      }
    } catch (err) {
      console.warn('Tracking lookup notice:', err);
    }
  }

  if (!matched) {
    resultBox.innerHTML = `
      <div style="padding:16px;border-radius:var(--radius-sm);background:#FEF2F2;color:#991B1B;font-size:13.5px;">
        No matching order found for ID <strong>${escapeHtml(inputId)}</strong> and phone ending in <strong>${escapeHtml(last4)}</strong>. Please verify your Order ID (` + `ord_...` + ` or ` + `ORD-...` + `) and phone number.
      </div>
    `;
    return;
  }

  const currentIdx = ORDER_STATUS_STEPS.indexOf(matched.orderStatus);
  const isSpecialStatus = ['Cancelled', 'Returned', 'Refunded'].includes(matched.orderStatus);
  const waTrackHelpUrl = getWhatsAppUrl(`Hello ${state.settings.siteName || 'STORE BD ONLINE'}, I would like an update on Order ${matched.orderNumber} (ID: ${matched.id}, Status: ${matched.orderStatus}).`);

  resultBox.innerHTML = `
    <div style="padding:18px;border-radius:var(--radius-md);background:var(--bg-light);border:1px solid var(--border-light);">
      <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:10px;">
        <div>
          <div style="font-size:15px;font-weight:800;">Order ${escapeHtml(matched.orderNumber)}</div>
          <div style="font-size:12px;color:var(--text-secondary);">Tracking ID: ${escapeHtml(matched.id)} · Items: ${matched.itemCount} · Total: ${formatPrice(matched.grandTotal)}</div>
        </div>
        <div style="font-size:13px;font-weight:800;color:var(--brand-red);">
          Status: ${escapeHtml(matched.orderStatus)} (${escapeHtml(matched.paymentStatus)})
        </div>
      </div>

      ${isSpecialStatus ? `
        <div style="padding:12px;border-radius:var(--radius-sm);background:#FEF2F2;color:#991B1B;font-weight:700;font-size:13px;">
          Order Status: ${escapeHtml(matched.orderStatus)}
        </div>
      ` : `
        <div class="timeline-steps">
          ${ORDER_STATUS_STEPS.map((step, idx) => {
            const stateClass = idx < currentIdx ? 'done' : (idx === currentIdx ? 'current' : '');
            return `
              <div class="timeline-step ${stateClass}">
                <span>${idx <= currentIdx ? '✓' : (idx + 1)}</span>
                <span>${escapeHtml(step)}</span>
              </div>
            `;
          }).join('')}
        </div>
      `}
      <div style="margin-top:14px;display:flex;justify-content:flex-end;">
        <a href="${escapeHtml(waTrackHelpUrl)}" target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="border-color:#25D366;color:#128C7E;padding:7px 12px;font-size:12px;">
          💬 Order Assistance on WhatsApp
        </a>
      </div>
    </div>
  `;
}



export {
  saveCart,
  addToCart,
  updateCartQty,
  calculateCartTotals,
  renderCartDrawer,
  applyCouponCode,
  renderCheckoutView,
  handleCheckoutSubmit,
  renderOrderConfirmation,
  ORDER_STATUS_STEPS,
  handleOrderTrackingSubmit
};
